-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: daren_selection
-- ------------------------------------------------------
-- Server version	5.7.44-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL COMMENT '操作人ID',
  `user_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '操作人姓名',
  `ip` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '来源IP',
  `method` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'HTTP方法',
  `path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '请求路径',
  `target_table` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '目标表',
  `target_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '目标记录ID',
  `action_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '操作类型',
  `before_data` text COLLATE utf8mb4_unicode_ci COMMENT '变更前(JSON)',
  `after_data` text COLLATE utf8mb4_unicode_ci COMMENT '变更后(JSON)',
  `detail` text COLLATE utf8mb4_unicode_ci COMMENT '操作摘要',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_table` (`target_table`),
  KEY `idx_action` (`action_type`)
) ENGINE=InnoDB AUTO_INCREMENT=249 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='操作审计日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-17 15:40:34'),(2,1,'系统管理员','::ffff:127.0.0.1','POST','/api/brands','brands','1','create',NULL,'{\"name\":\"API测试品牌\",\"country\":\"日本\",\"category\":\"美妆\",\"coop_stage\":\"洽谈中\",\"grade\":\"A\"}','POST /api/brands [name,country,category,coop_stage,grade]','2026-08-17 15:40:34'),(3,1,'系统管理员','::ffff:127.0.0.1','POST','/api/products','products','1','create',NULL,'{\"name\":\"API测试商品\",\"sku\":\"API-01\",\"supply_price\":45,\"sale_price\":129,\"stock\":100,\"shelf_status\":\"已上架\"}','POST /api/products [name,sku,supply_price,sale_price,stock,shelf_status]','2026-08-17 15:40:34'),(4,1,'admin','61.186.18.64','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-17 15:40:41'),(5,1,'admin','61.186.18.64','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-17 15:45:20'),(6,1,'admin','61.186.18.64','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-17 15:47:14'),(7,1,'admin','61.186.18.64','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-17 15:49:53'),(8,1,'admin','61.186.27.5','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-17 15:50:02'),(9,1,'admin','61.186.18.64','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-17 15:53:01'),(10,1,'系统管理员','61.186.18.64','POST','/api/brands','brands','2','create',NULL,'{\"name\":\"伊菲丹\",\"logo_url\":\"\",\"country\":\"法国\",\"category\":\"\",\"company\":\"\",\"contact\":\"\",\"contact_info\":\"\",\"coop_stage\":\"挖掘中\",\"grade\":\"C\",\"contract_no\":\"\",\"contract_expiry\":null,\"auth_expiry\":null,\"payment_terms\":\"\",\"remark\":\"\"}','POST /api/brands [name,logo_url,country,category,company,contact,contact_info,coop_stage,grade,contract_no,contract_expiry,auth_expiry,payment_terms,remark]','2026-08-17 15:53:17'),(11,1,'系统管理员','61.186.18.64','DELETE','/api/brands/2','brands',NULL,'delete',NULL,'{}','DELETE /api/brands/2','2026-08-17 15:54:47'),(12,1,'系统管理员','61.186.27.5','POST','/api/brands','brands','3','create',NULL,'{\"name\":\"千颂\",\"logo_url\":\"\",\"country\":\"日本\",\"category\":\"酒\",\"company\":\"\",\"contact\":\"\",\"contact_info\":\"\",\"coop_stage\":\"挖掘中\",\"grade\":\"C\",\"contract_no\":\"\",\"contract_expiry\":null,\"auth_expiry\":null,\"payment_terms\":\"\",\"remark\":\"\"}','POST /api/brands [name,logo_url,country,category,company,contact,contact_info,coop_stage,grade,contract_no,contract_expiry,auth_expiry,payment_terms,remark]','2026-08-17 15:56:18'),(13,1,'系统管理员','61.186.27.5','POST','/api/products','products','2','create',NULL,'{\"name\":\"千颂威士忌\",\"sku\":\"\",\"brand_id\":3,\"category\":\"\",\"main_image\":\"\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":0,\"sale_price\":0,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"\"}','POST /api/products [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark]','2026-08-17 15:56:31'),(14,1,'admin','61.186.18.64','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-17 16:19:48'),(15,1,'admin','61.186.18.64','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-17 16:22:16'),(16,1,'admin','61.186.27.5','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-17 16:53:02'),(17,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-18 15:50:02'),(18,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-18 15:52:19'),(19,1,'admin','::1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-18 15:53:26'),(20,1,'admin','127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-18 15:53:26'),(21,1,'admin','61.186.24.240','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-18 15:55:00'),(22,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-18 15:56:49'),(23,1,'admin','61.186.24.240','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-18 15:57:04'),(24,1,'admin','61.186.24.240','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-18 15:57:04'),(25,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-18 16:10:05'),(26,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-18 16:12:41'),(27,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-18 16:13:51'),(28,NULL,'admin','61.186.18.195','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录失败：账号或密码错误','2026-08-20 15:57:06'),(29,1,'系统管理员','61.186.18.195','POST','/api/scores','scores',NULL,'create',NULL,'{\"subject_type\":\"product\",\"subject_id\":1,\"remark\":\"线上冒烟\",\"scores\":{\"margin\":15,\"story\":7,\"usp\":7,\"content\":6,\"search\":5,\"trend\":5,\"competition\":5,\"potential\":5,\"supply\":5,\"inventory\":5,\"logistics\":5,\"cert\":5,\"ip\":5,\"legal\":5,\"repeat\":10,\"season\":5}}','POST /api/scores [subject_type,subject_id,remark,scores]','2026-08-20 15:57:51'),(30,1,'系统管理员','61.186.18.195','POST','/api/scores','scores',NULL,'create',NULL,'{\"subject_type\":\"product\",\"subject_id\":1,\"remark\":\"线上冒烟\",\"scores\":{\"margin\":15,\"story\":7,\"usp\":7,\"content\":6,\"search\":5,\"trend\":5,\"competition\":5,\"potential\":5,\"supply\":5,\"inventory\":5,\"logistics\":5,\"cert\":5,\"ip\":5,\"legal\":5,\"repeat\":10,\"season\":5}}','POST /api/scores [subject_type,subject_id,remark,scores]','2026-08-20 15:57:58'),(31,1,'系统管理员','61.186.18.195','POST','/api/scores','scores','1','create',NULL,'{\"subject_type\":\"product\",\"subject_id\":2,\"remark\":\"线上冒烟测试（可删）\",\"scores\":{\"margin\":15,\"story\":7,\"usp\":7,\"content\":6,\"search\":5,\"trend\":5,\"competition\":5,\"potential\":5,\"supply\":5,\"inventory\":5,\"logistics\":5,\"cert\":5,\"ip\":5,\"legal\":5,\"repeat\":10,\"season\":5}}','POST /api/scores [subject_type,subject_id,remark,scores]','2026-08-20 15:58:07'),(32,1,'系统管理员','61.186.18.195','DELETE','/api/scores/1','scores','1','delete',NULL,'{}','DELETE /api/scores/1','2026-08-20 15:58:23'),(33,1,'系统管理员','61.186.18.195','PUT','/api/scores/account-dims','scores',NULL,'update',NULL,'{\"dims\":[{\"dim_id\":1,\"enabled\":0},{\"dim_id\":2,\"enabled\":0},{\"dim_id\":3,\"enabled\":0},{\"dim_id\":4,\"enabled\":0},{\"dim_id\":5,\"enabled\":0},{\"dim_id\":6,\"enabled\":0},{\"dim_id\":7,\"enabled\":0},{\"dim_id\":8,\"enabled\":0},{\"dim_id\":9,\"enabled\":0},{\"dim_id\":10,\"enabled\":0},{\"dim_id\":11,\"enabled\":0},{\"dim_id\":12,\"enabled\":0},{\"dim_id\":13,\"enabled\":0},{\"dim_id\":14,\"enabled\":0},{\"dim_id\":15,\"enabled\":0},{\"dim_id\":16,\"enabled\":0}]}','PUT /api/scores/account-dims [dims]','2026-08-20 16:08:03'),(34,1,'系统管理员','61.186.18.195','PUT','/api/scores/account-dims','scores',NULL,'update',NULL,'{\"dims\":[{\"dim_id\":1,\"enabled\":0},{\"dim_id\":2,\"enabled\":0},{\"dim_id\":3,\"enabled\":0},{\"dim_id\":4,\"enabled\":0},{\"dim_id\":5,\"enabled\":0},{\"dim_id\":6,\"enabled\":0},{\"dim_id\":7,\"enabled\":0},{\"dim_id\":8,\"enabled\":0},{\"dim_id\":9,\"enabled\":0},{\"dim_id\":10,\"enabled\":0},{\"dim_id\":11,\"enabled\":0},{\"dim_id\":12,\"enabled\":0},{\"dim_id\":13,\"enabled\":0},{\"dim_id\":14,\"enabled\":0},{\"dim_id\":15,\"enabled\":0},{\"dim_id\":16,\"enabled\":0}]}','PUT /api/scores/account-dims [dims]','2026-08-20 16:08:08'),(35,1,'系统管理员','61.186.18.195','PUT','/api/scores/account-dims','scores',NULL,'update',NULL,'{\"dims\":[{\"dim_id\":1,\"enabled\":0},{\"dim_id\":2,\"enabled\":0},{\"dim_id\":3,\"enabled\":0},{\"dim_id\":4,\"enabled\":0},{\"dim_id\":5,\"enabled\":0},{\"dim_id\":6,\"enabled\":0},{\"dim_id\":7,\"enabled\":0},{\"dim_id\":8,\"enabled\":0},{\"dim_id\":9,\"enabled\":0},{\"dim_id\":10,\"enabled\":0},{\"dim_id\":11,\"enabled\":0},{\"dim_id\":12,\"enabled\":0},{\"dim_id\":13,\"enabled\":0},{\"dim_id\":14,\"enabled\":0},{\"dim_id\":15,\"enabled\":0},{\"dim_id\":16,\"enabled\":0}]}','PUT /api/scores/account-dims [dims]','2026-08-20 16:15:57'),(36,1,'系统管理员','61.186.18.195','PUT','/api/scores/account-dims','scores',NULL,'update',NULL,'{\"dims\":[{\"dim_id\":1,\"enabled\":0},{\"dim_id\":2,\"enabled\":0},{\"dim_id\":3,\"enabled\":0},{\"dim_id\":4,\"enabled\":0},{\"dim_id\":5,\"enabled\":0},{\"dim_id\":6,\"enabled\":0},{\"dim_id\":7,\"enabled\":0},{\"dim_id\":8,\"enabled\":0},{\"dim_id\":9,\"enabled\":0},{\"dim_id\":10,\"enabled\":0},{\"dim_id\":11,\"enabled\":0},{\"dim_id\":12,\"enabled\":0},{\"dim_id\":13,\"enabled\":0},{\"dim_id\":14,\"enabled\":0},{\"dim_id\":15,\"enabled\":0},{\"dim_id\":16,\"enabled\":0}]}','PUT /api/scores/account-dims [dims]','2026-08-20 16:23:44'),(37,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-20 16:29:58'),(38,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-20 16:30:10'),(39,1,'系统管理员','::ffff:127.0.0.1','PUT','/api/scores/account-dims','scores',NULL,'update',NULL,'{\"dims\":[{\"dim_id\":1,\"enabled\":1},{\"dim_id\":2,\"enabled\":0}]}','PUT /api/scores/account-dims [dims]','2026-08-20 16:30:13'),(40,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-20 16:34:41'),(41,1,'系统管理员','::ffff:127.0.0.1','PUT','/api/scores/account-dims','scores',NULL,'update',NULL,'{\"dims\":[{\"dim_id\":1,\"enabled\":1},{\"dim_id\":2,\"enabled\":1}]}','PUT /api/scores/account-dims [dims]','2026-08-20 16:34:42'),(42,1,'系统管理员','::ffff:127.0.0.1','PUT','/api/scores/999','scores',NULL,'update',NULL,'{}','PUT /api/scores/999','2026-08-20 16:34:43'),(43,1,'系统管理员','61.186.18.195','PUT','/api/scores/account-dims','scores',NULL,'update',NULL,'{\"dims\":[{\"enabled\":1},{\"enabled\":1},{\"enabled\":1},{\"enabled\":1},{\"enabled\":1},{\"enabled\":1},{\"enabled\":1},{\"enabled\":1},{\"enabled\":1},{\"enabled\":1},{\"enabled\":1},{\"enabled\":1},{\"enabled\":1},{\"enabled\":1},{\"enabled\":1},{\"enabled\":1}]}','PUT /api/scores/account-dims [dims]','2026-08-20 16:37:29'),(44,1,'admin','61.186.18.195','POST','/api/auth/change-password',NULL,NULL,'update',NULL,NULL,'修改我的密码','2026-08-20 16:38:36'),(45,1,'系统管理员','61.186.18.195','POST','/api/users','users',NULL,'create',NULL,'{\"username\":\"孙萌娟\",\"name\":\"孙萌娟\",\"role\":\"selection\",\"permissions\":\"[\\\"dashboard\\\",\\\"brands\\\",\\\"products\\\",\\\"coop\\\",\\\"samples\\\",\\\"scores\\\",\\\"excel\\\"]\"}','创建账号','2026-08-20 16:53:17'),(46,1,'系统管理员','61.186.18.195','POST','/api/auth/logout',NULL,NULL,'logout',NULL,NULL,'退出登录','2026-08-20 16:54:09'),(47,2,'孙萌娟','61.186.18.195','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-20 16:54:12'),(48,NULL,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录失败：账号或密码错误','2026-08-20 16:54:27'),(49,NULL,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录失败：账号或密码错误','2026-08-20 16:54:36'),(50,2,'孙萌娟','61.186.18.195','POST','/api/auth/logout',NULL,NULL,'logout',NULL,NULL,'退出登录','2026-08-20 16:55:10'),(51,1,'admin','61.186.18.195','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-20 16:55:13'),(52,1,'admin','61.186.18.195','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-20 16:55:17'),(53,1,'系统管理员','61.186.18.195','PUT','/api/users/2','users','2','update','{\"name\":\"孙萌娟\",\"role\":\"selection\",\"dept\":\"供应链中心\",\"permissions\":\"[\\\"dashboard\\\",\\\"brands\\\",\\\"products\\\",\\\"coop\\\",\\\"samples\\\",\\\"scores\\\",\\\"excel\\\"]\"}','{\"name\":\"孙萌娟\",\"role\":\"selection\",\"dept\":\"供应链中心\",\"permissions\":\"[\\\"dashboard\\\",\\\"brands\\\",\\\"darens\\\",\\\"products\\\",\\\"coop\\\",\\\"samples\\\",\\\"scores\\\",\\\"commission\\\",\\\"excel\\\"]\"}','编辑账号','2026-08-20 16:56:12'),(54,1,'系统管理员','61.186.18.195','POST','/api/auth/logout',NULL,NULL,'logout',NULL,NULL,'退出登录','2026-08-20 16:56:31'),(55,2,'孙萌娟','61.186.18.195','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-20 16:56:34'),(56,1,'系统管理员','61.186.18.195','POST','/api/users','users',NULL,'create',NULL,'{\"username\":\"康佳慧\",\"name\":\"康佳慧\",\"role\":\"selection\",\"permissions\":\"[\\\"scores\\\",\\\"samples\\\",\\\"brands\\\",\\\"dashboard\\\",\\\"products\\\",\\\"coop\\\",\\\"commission\\\",\\\"excel\\\"]\"}','创建账号','2026-08-20 17:00:21'),(57,2,'孙萌娟','61.186.18.195','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原37KB → 4KB','2026-08-20 17:00:27'),(58,2,'孙萌娟','61.186.18.195','POST','/api/brands','brands','4','create',NULL,'{\"name\":\"Natural Animal Solutions\",\"logo_url\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787216425633-56ff16580790.webp?sign=e33b2ca0ee9894148a032be6b609fd81&t=1787216427\",\"country\":\"澳洲\",\"category\":\"宠物补剂\",\"company\":\"\",\"contact\":\"孙萌娟\",\"contact_info\":\"暂无\",\"coop_stage\":\"挖掘中\",\"grade\":\"C\",\"contract_no\":\"\",\"contract_expiry\":null,\"auth_expiry\":null,\"payment_terms\":\"\",\"remark\":\"天猫跨境直营，国内无明确总代\"}','POST /api/brands [name,logo_url,country,category,company,contact,contact_info,coop_stage,grade,contract_no,contract_expiry,auth_expiry,payment_terms,remark]','2026-08-20 17:00:34'),(59,2,'孙萌娟','61.186.18.195','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原100KB → 11KB','2026-08-20 17:02:19'),(60,2,'孙萌娟','61.186.18.195','POST','/api/brands','brands','5','create',NULL,'{\"name\":\"Aniforte\",\"logo_url\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787216538867-0093384d5b2d.webp?sign=4d0a866d17d8262ea8c7dce5bcccf561&t=1787216539\",\"country\":\"德国\",\"category\":\"宠物补剂\",\"company\":\"\",\"contact\":\"孙萌娟\",\"contact_info\":\"13805011696\",\"coop_stage\":\"挖掘中\",\"grade\":\"C\",\"contract_no\":\"\",\"contract_expiry\":null,\"auth_expiry\":null,\"payment_terms\":\"\",\"remark\":\"已发资料和报价，2000起拿货\"}','POST /api/brands [name,logo_url,country,category,company,contact,contact_info,coop_stage,grade,contract_no,contract_expiry,auth_expiry,payment_terms,remark]','2026-08-20 17:02:41'),(61,2,'孙萌娟','61.186.18.195','PUT','/api/brands/5','brands','5','update',NULL,'{\"name\":\"Aniforte\",\"logo_url\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787216538867-0093384d5b2d.webp?sign=4d0a866d17d8262ea8c7dce5bcccf561&t=1787216539\",\"country\":\"德国\",\"category\":\"宠物补剂\",\"company\":\"\",\"contact\":\"孙萌娟\",\"contact_info\":\"13805011696\",\"coop_stage\":\"洽谈中\",\"grade\":\"B\",\"contract_no\":\"\",\"contract_expiry\":null,\"auth_expiry\":null,\"payment_terms\":\"\",\"remark\":\"已发资料和报价，2000起拿货\",\"id\":5,\"created_at\":\"2026-08-20T09:02:41.000Z\",\"updated_at\":\"2026-08-20T09:02:41.000Z\",\"owner_id\":null}','PUT /api/brands/5 [name,logo_url,country,category,company,contact,contact_info,coop_stage,grade,contract_no,contract_expiry,auth_expiry,payment_terms,remark,id,created_at,updated_at,owner_id]','2026-08-20 17:02:58'),(62,2,'孙萌娟','61.186.18.195','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原24KB → 4KB','2026-08-20 17:04:54'),(63,2,'孙萌娟','61.186.18.195','POST','/api/brands','brands','6','create',NULL,'{\"name\":\"SAMBUCOL\",\"logo_url\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787216693750-363641fc7d93.webp?sign=88e404ebbc659c8ce90a58dbe54149e2&t=1787216694\",\"country\":\"英国\",\"category\":\"母婴保健\",\"company\":\"\",\"contact\":\"孙萌娟\",\"contact_info\":\"17750823510\",\"coop_stage\":\"挖掘中\",\"grade\":\"C\",\"contract_no\":\"\",\"contract_expiry\":null,\"auth_expiry\":null,\"payment_terms\":\"\",\"remark\":\"品牌直营子公司，目前联系到的只能一件代发\",\"id\":5,\"created_at\":\"2026-08-20T09:02:41.000Z\",\"updated_at\":\"2026-08-20T09:02:58.000Z\",\"owner_id\":null}','POST /api/brands [name,logo_url,country,category,company,contact,contact_info,coop_stage,grade,contract_no,contract_expiry,auth_expiry,payment_terms,remark,id,created_at,updated_at,owner_id]','2026-08-20 17:05:33'),(64,2,'孙萌娟','61.186.18.195','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原10KB → 2KB','2026-08-20 17:07:04'),(65,2,'孙萌娟','61.186.18.195','POST','/api/brands','brands','7','create',NULL,'{\"name\":\"Mivolis\",\"logo_url\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787216823538-74507083675d.webp?sign=93811047655b0ec406faded22cb78e22&t=1787216824\",\"country\":\"德国\",\"category\":\"保健\",\"company\":\"\",\"contact\":\"\",\"contact_info\":\"无\",\"coop_stage\":\"挖掘中\",\"grade\":\"C\",\"contract_no\":\"\",\"contract_expiry\":null,\"auth_expiry\":null,\"payment_terms\":\"\",\"remark\":\"德国超市自有品牌，无授权\",\"id\":5,\"created_at\":\"2026-08-20T09:02:41.000Z\",\"updated_at\":\"2026-08-20T09:02:58.000Z\",\"owner_id\":null}','POST /api/brands [name,logo_url,country,category,company,contact,contact_info,coop_stage,grade,contract_no,contract_expiry,auth_expiry,payment_terms,remark,id,created_at,updated_at,owner_id]','2026-08-20 17:07:21'),(66,2,'孙萌娟','61.186.18.195','PUT','/api/brands/7','brands','7','update',NULL,'{\"name\":\"Mivolis\",\"logo_url\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787216823538-74507083675d.webp?sign=93811047655b0ec406faded22cb78e22&t=1787216824\",\"country\":\"德国\",\"category\":\"保健\",\"company\":\"\",\"contact\":\"孙萌娟\",\"contact_info\":\"无\",\"coop_stage\":\"挖掘中\",\"grade\":\"C\",\"contract_no\":\"\",\"contract_expiry\":null,\"auth_expiry\":null,\"payment_terms\":\"\",\"remark\":\"德国超市自有品牌，无授权\",\"id\":7,\"created_at\":\"2026-08-20T09:07:21.000Z\",\"updated_at\":\"2026-08-20T09:07:21.000Z\",\"owner_id\":null}','PUT /api/brands/7 [name,logo_url,country,category,company,contact,contact_info,coop_stage,grade,contract_no,contract_expiry,auth_expiry,payment_terms,remark,id,created_at,updated_at,owner_id]','2026-08-20 17:07:37'),(67,1,'系统管理员','61.186.26.93','POST','/api/brands','brands','8','create',NULL,'{\"name\":\"三山阳光\",\"logo_url\":\"\",\"country\":\"俄罗斯\",\"category\":\"酒\",\"company\":\"\",\"contact\":\"\",\"contact_info\":\"\",\"coop_stage\":\"洽谈中\",\"grade\":\"A\",\"contract_no\":\"\",\"contract_expiry\":null,\"auth_expiry\":null,\"payment_terms\":\"\",\"remark\":\"\"}','POST /api/brands [name,logo_url,country,category,company,contact,contact_info,coop_stage,grade,contract_no,contract_expiry,auth_expiry,payment_terms,remark]','2026-08-20 17:10:23'),(68,1,'系统管理员','61.186.26.93','POST','/api/brands','brands','9','create',NULL,'{\"name\":\"马赫斯基\",\"logo_url\":\"\",\"country\":\"俄罗斯\",\"category\":\"酒\",\"company\":\"\",\"contact\":\"\",\"contact_info\":\"\",\"coop_stage\":\"洽谈中\",\"grade\":\"A\",\"contract_no\":\"\",\"contract_expiry\":null,\"auth_expiry\":null,\"payment_terms\":\"\",\"remark\":\"\"}','POST /api/brands [name,logo_url,country,category,company,contact,contact_info,coop_stage,grade,contract_no,contract_expiry,auth_expiry,payment_terms,remark]','2026-08-20 17:10:54'),(69,1,'系统管理员','61.186.26.93','POST','/api/brands','brands','10','create',NULL,'{\"name\":\"鸿迈\",\"logo_url\":\"\",\"country\":\"俄罗斯\",\"category\":\"酒\",\"company\":\"\",\"contact\":\"\",\"contact_info\":\"\",\"coop_stage\":\"洽谈中\",\"grade\":\"A\",\"contract_no\":\"\",\"contract_expiry\":null,\"auth_expiry\":null,\"payment_terms\":\"\",\"remark\":\"\"}','POST /api/brands [name,logo_url,country,category,company,contact,contact_info,coop_stage,grade,contract_no,contract_expiry,auth_expiry,payment_terms,remark]','2026-08-20 17:11:17'),(70,1,'系统管理员','61.186.26.93','POST','/api/brands','brands','11','create',NULL,'{\"name\":\"酌力\",\"logo_url\":\"\",\"country\":\"俄罗斯\",\"category\":\"酒\",\"company\":\"\",\"contact\":\"\",\"contact_info\":\"\",\"coop_stage\":\"洽谈中\",\"grade\":\"A\",\"contract_no\":\"\",\"contract_expiry\":null,\"auth_expiry\":null,\"payment_terms\":\"\",\"remark\":\"\"}','POST /api/brands [name,logo_url,country,category,company,contact,contact_info,coop_stage,grade,contract_no,contract_expiry,auth_expiry,payment_terms,remark]','2026-08-20 17:11:34'),(71,1,'系统管理员','61.186.26.93','POST','/api/products','products','3','create',NULL,'{\"name\":\"1875经典-阳光精酿\",\"sku\":\"\",\"brand_id\":8,\"category\":\"\",\"main_image\":\"\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":0,\"sale_price\":0,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\"}','POST /api/products [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark]','2026-08-20 17:12:13'),(72,1,'系统管理员','61.186.26.93','POST','/api/products','products','4','create',NULL,'{\"name\":\"1875经典-纪念版（畅饮黄）\",\"sku\":\"\",\"brand_id\":8,\"category\":\"\",\"main_image\":\"\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":0,\"sale_price\":0,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\"}','POST /api/products [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark]','2026-08-20 17:12:42'),(73,2,'孙萌娟','61.186.18.195','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原5KB → 1KB','2026-08-20 17:13:07'),(74,1,'系统管理员','61.186.26.93','POST','/api/users','users',NULL,'create',NULL,'{\"username\":\"庄逸\",\"name\":\"庄逸\",\"role\":\"daren_op\",\"permissions\":\"[\\\"excel\\\",\\\"commission\\\",\\\"coop\\\",\\\"darens\\\",\\\"samples\\\",\\\"products\\\",\\\"brands\\\",\\\"dashboard\\\",\\\"scores\\\"]\"}','创建账号','2026-08-20 17:13:20'),(75,2,'孙萌娟','61.186.18.195','POST','/api/brands','brands','12','create',NULL,'{\"name\":\"Vivelab\",\"logo_url\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787217186510-eda2727ecee4.webp?sign=639b730acf33af9c2b967f73403421d2&t=1787217187\",\"country\":\"韩国\",\"category\":\"洗护\",\"company\":\"\",\"contact\":\"孙萌娟\",\"contact_info\":\"\",\"coop_stage\":\"挖掘中\",\"grade\":\"C\",\"contract_no\":\"\",\"contract_expiry\":null,\"auth_expiry\":null,\"payment_terms\":\"\",\"remark\":\"\",\"id\":7,\"created_at\":\"2026-08-20T09:07:21.000Z\",\"updated_at\":\"2026-08-20T09:07:21.000Z\",\"owner_id\":null}','POST /api/brands [name,logo_url,country,category,company,contact,contact_info,coop_stage,grade,contract_no,contract_expiry,auth_expiry,payment_terms,remark,id,created_at,updated_at,owner_id]','2026-08-20 17:13:39'),(76,1,'系统管理员','61.186.26.93','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原185KB → 46KB','2026-08-20 17:13:49'),(77,1,'系统管理员','61.186.26.93','POST','/api/auth/logout',NULL,NULL,'logout',NULL,NULL,'退出登录','2026-08-20 17:13:49'),(78,1,'系统管理员','61.186.26.93','POST','/api/products','products','5','create',NULL,'{\"name\":\"淡色红标-4.9度精酿\",\"sku\":\"\",\"brand_id\":8,\"category\":\"\",\"main_image\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787217228533-e4e6b694d8ea.webp?sign=33c83d1ed941d44139cd85ffa93f01d8&t=1787217229\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":0,\"sale_price\":0,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\"}','POST /api/products [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark]','2026-08-20 17:13:50'),(79,4,'庄逸','61.186.26.93','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-20 17:13:57'),(80,4,'庄逸','61.186.26.93','POST','/api/auth/logout',NULL,NULL,'logout',NULL,NULL,'退出登录','2026-08-20 17:14:28'),(81,1,'admin','61.186.26.93','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-20 17:14:31'),(82,1,'系统管理员','61.186.26.93','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原114KB → 15KB','2026-08-20 17:14:31'),(83,1,'系统管理员','61.186.26.93','PUT','/api/products/4','products','4','update',NULL,'{\"name\":\"1875经典-纪念版（畅饮黄）\",\"sku\":\"\",\"brand_id\":8,\"category\":\"\",\"main_image\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787217271066-1c43c2d3c395.webp?sign=6b757ee9be82bbc0828b340dc867c6ea&t=1787217271\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":0,\"sale_price\":0,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\",\"id\":4,\"created_at\":\"2026-08-20T09:12:42.000Z\",\"updated_at\":\"2026-08-20T09:12:42.000Z\",\"brand_name\":\"三山阳光\"}','PUT /api/products/4 [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-20 17:14:32'),(84,1,'系统管理员','::ffff:127.0.0.1','POST','/api/darens','darens','2','create',NULL,'{\"name\":\"__SOP_验证达人__\",\"coop_status\":\"建联中\",\"cooperation\":5,\"remark\":\"冒烟\"}','POST /api/darens [name,coop_status,cooperation,remark]','2026-08-20 17:14:43'),(85,1,'系统管理员','::ffff:127.0.0.1','POST','/api/coop','coop',NULL,'create',NULL,'{\"product_id\":2,\"daren_id\":2,\"status\":\"带货中\",\"coop_fee\":500,\"coop_mode\":\"直播\",\"commission_rate\":25,\"remark\":\"坑位费500\"}','POST /api/coop [product_id,daren_id,status,coop_fee,coop_mode,commission_rate,remark]','2026-08-20 17:14:43'),(86,1,'系统管理员','::ffff:127.0.0.1','POST','/api/samples','samples','2','create',NULL,'{\"product_id\":2,\"daren_id\":2,\"sample_fee\":0,\"remark\":\"冒烟\"}','POST /api/samples [product_id,daren_id,sample_fee,remark]','2026-08-20 17:14:43'),(87,1,'系统管理员','::ffff:127.0.0.1','PUT','/api/samples/2','samples','2','update',NULL,'{\"status\":\"寄出\",\"express_no\":\"SF123\",\"send_date\":\"2026-08-20\"}','PUT /api/samples/2 [status,express_no,send_date]','2026-08-20 17:14:43'),(88,1,'系统管理员','::ffff:127.0.0.1','PUT','/api/samples/2','samples','2','update',NULL,'{\"status\":\"签收\",\"sign_date\":\"2026-08-21\"}','PUT /api/samples/2 [status,sign_date]','2026-08-20 17:14:43'),(89,1,'系统管理员','::ffff:127.0.0.1','PUT','/api/samples/2','samples','2','update',NULL,'{\"status\":\"已回收\",\"recycle_date\":\"2026-08-22\"}','PUT /api/samples/2 [status,recycle_date]','2026-08-20 17:14:43'),(90,1,'系统管理员','::ffff:127.0.0.1','DELETE','/api/samples/2','samples',NULL,'delete',NULL,'{}','DELETE /api/samples/2','2026-08-20 17:14:43'),(91,1,'系统管理员','61.186.26.93','GET','/api/excel/export','excel',NULL,'export',NULL,NULL,'导出台账：达人导入模板.xlsx','2026-08-20 17:14:50'),(92,1,'系统管理员','::ffff:127.0.0.1','POST','/api/coop','coop',NULL,'create',NULL,'{\"product_id\":2,\"daren_id\":2,\"status\":\"带货中\",\"coop_fee\":500,\"coop_mode\":\"直播\",\"commission_rate\":25,\"remark\":\"坑位费500\"}','POST /api/coop [product_id,daren_id,status,coop_fee,coop_mode,commission_rate,remark]','2026-08-20 17:14:54'),(93,1,'系统管理员','::ffff:127.0.0.1','POST','/api/coop','coop',NULL,'create',NULL,'{}','POST /api/coop','2026-08-20 17:14:54'),(94,1,'系统管理员','::ffff:127.0.0.1','DELETE','/api/darens/2','darens',NULL,'delete',NULL,'{}','DELETE /api/darens/2','2026-08-20 17:14:54'),(95,1,'系统管理员','61.186.26.93','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原538KB → 92KB','2026-08-20 17:15:27'),(96,1,'系统管理员','61.186.26.93','PUT','/api/products/3','products','3','update',NULL,'{\"name\":\"1875经典-阳光精酿\",\"sku\":\"\",\"brand_id\":8,\"category\":\"\",\"main_image\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787217326433-706d0c586b4b.webp?sign=bb3eaf3a7782e45009a227ccad6c16b0&t=1787217327\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":0,\"sale_price\":0,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\",\"id\":3,\"created_at\":\"2026-08-20T09:12:13.000Z\",\"updated_at\":\"2026-08-20T09:12:13.000Z\",\"brand_name\":\"三山阳光\"}','PUT /api/products/3 [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-20 17:15:30'),(97,1,'系统管理员','::ffff:127.0.0.1','POST','/api/darens','darens','3','create',NULL,'{\"name\":\"__SOP_验证达人__\",\"coop_status\":\"建联中\",\"cooperation\":5,\"remark\":\"冒烟\"}','POST /api/darens [name,coop_status,cooperation,remark]','2026-08-20 17:15:32'),(98,1,'系统管理员','::ffff:127.0.0.1','POST','/api/coop','coop','2','create',NULL,'{\"product_id\":2,\"daren_id\":3,\"status\":\"带货中\",\"coop_fee\":500,\"coop_mode\":\"直播\",\"commission_rate\":25,\"remark\":\"坑位费500\"}','POST /api/coop [product_id,daren_id,status,coop_fee,coop_mode,commission_rate,remark]','2026-08-20 17:15:32'),(99,1,'系统管理员','::ffff:127.0.0.1','POST','/api/samples','samples','3','create',NULL,'{\"product_id\":2,\"daren_id\":3,\"sample_fee\":0,\"remark\":\"冒烟\"}','POST /api/samples [product_id,daren_id,sample_fee,remark]','2026-08-20 17:15:32'),(100,1,'系统管理员','::ffff:127.0.0.1','PUT','/api/samples/3','samples','3','update',NULL,'{\"status\":\"寄出\",\"express_no\":\"SF123\",\"send_date\":\"2026-08-20\"}','PUT /api/samples/3 [status,express_no,send_date]','2026-08-20 17:15:33'),(101,1,'系统管理员','::ffff:127.0.0.1','PUT','/api/samples/3','samples','3','update',NULL,'{\"status\":\"签收\",\"sign_date\":\"2026-08-21\"}','PUT /api/samples/3 [status,sign_date]','2026-08-20 17:15:33'),(102,1,'系统管理员','::ffff:127.0.0.1','PUT','/api/samples/3','samples','3','update',NULL,'{\"status\":\"已回收\",\"recycle_date\":\"2026-08-22\"}','PUT /api/samples/3 [status,recycle_date]','2026-08-20 17:15:33'),(103,1,'系统管理员','::ffff:127.0.0.1','DELETE','/api/samples/3','samples',NULL,'delete',NULL,'{}','DELETE /api/samples/3','2026-08-20 17:15:33'),(104,1,'系统管理员','61.186.26.93','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原490KB → 66KB','2026-08-20 17:16:30'),(105,1,'系统管理员','61.186.26.93','POST','/api/products','products','6','create',NULL,'{\"name\":\"淡色精酿-纪念版（中国红）\",\"sku\":\"\",\"brand_id\":8,\"category\":\"\",\"main_image\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787217390014-6f54ce9d1c56.webp?sign=f9802f2cca2b9c0adf4a2c52268df045&t=1787217390\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":0,\"sale_price\":0,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\",\"id\":3,\"created_at\":\"2026-08-20T09:12:13.000Z\",\"updated_at\":\"2026-08-20T09:12:13.000Z\",\"brand_name\":\"三山阳光\"}','POST /api/products [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-20 17:16:31'),(106,2,'孙萌娟','61.186.18.195','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原47KB → 7KB','2026-08-20 17:17:21'),(107,2,'孙萌娟','61.186.18.195','POST','/api/brands','brands','13','create',NULL,'{\"name\":\"八潮\",\"logo_url\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787217440641-c51771e20935.webp?sign=a0b21638e92ad341c178b9d92f4182fe&t=1787217441\",\"country\":\"日本\",\"category\":\"酒水\",\"company\":\"\",\"contact\":\"孙萌娟\",\"contact_info\":\"\",\"coop_stage\":\"挖掘中\",\"grade\":\"C\",\"contract_no\":\"\",\"contract_expiry\":null,\"auth_expiry\":null,\"payment_terms\":\"\",\"remark\":\"\",\"id\":7,\"created_at\":\"2026-08-20T09:07:21.000Z\",\"updated_at\":\"2026-08-20T09:07:21.000Z\",\"owner_id\":null}','POST /api/brands [name,logo_url,country,category,company,contact,contact_info,coop_stage,grade,contract_no,contract_expiry,auth_expiry,payment_terms,remark,id,created_at,updated_at,owner_id]','2026-08-20 17:17:27'),(108,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-20 17:18:40'),(109,1,'admin','61.186.18.195','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-20 17:20:03'),(110,1,'admin','61.186.18.195','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-20 17:20:24'),(111,2,'孙萌娟','61.186.18.195','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原22KB → 4KB','2026-08-20 17:20:29'),(112,2,'孙萌娟','61.186.18.195','POST','/api/brands','brands','14','create',NULL,'{\"name\":\"OLDELA 欧德拉\",\"logo_url\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787217629091-9917f8f959c9.webp?sign=aa77cbb75921066b11056899949b2dfd&t=1787217629\",\"country\":\"德国\",\"category\":\"保健\",\"company\":\"\",\"contact\":\"孙萌娟\",\"contact_info\":\"15221875898\",\"coop_stage\":\"挖掘中\",\"grade\":\"C\",\"contract_no\":\"\",\"contract_expiry\":null,\"auth_expiry\":null,\"payment_terms\":\"\",\"remark\":\"海外店可以提供授权，无中文标贴不能售卖\",\"id\":7,\"created_at\":\"2026-08-20T09:07:21.000Z\",\"updated_at\":\"2026-08-20T09:07:21.000Z\",\"owner_id\":null}','POST /api/brands [name,logo_url,country,category,company,contact,contact_info,coop_stage,grade,contract_no,contract_expiry,auth_expiry,payment_terms,remark,id,created_at,updated_at,owner_id]','2026-08-20 17:20:30'),(113,1,'admin','61.186.18.195','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-20 17:21:18'),(114,2,'孙萌娟','61.186.18.195','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原26KB → 4KB','2026-08-20 17:21:42'),(115,1,'系统管理员','61.186.26.93','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原479KB → 61KB','2026-08-20 17:22:22'),(116,2,'孙萌娟','61.186.18.195','POST','/api/brands','brands','15','create',NULL,'{\"name\":\"EUBOS\",\"logo_url\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787217702284-21ed3f6c7548.webp?sign=5d0f4c83bbb59a1c3065194ba09daed1&t=1787217702\",\"country\":\"德国\",\"category\":\"个护\",\"company\":\"\",\"contact\":\"孙萌娟\",\"contact_info\":\"18964565889\",\"coop_stage\":\"洽谈中\",\"grade\":\"B\",\"contract_no\":\"\",\"contract_expiry\":null,\"auth_expiry\":null,\"payment_terms\":\"\",\"remark\":\"可发政策和介绍\",\"id\":7,\"created_at\":\"2026-08-20T09:07:21.000Z\",\"updated_at\":\"2026-08-20T09:07:21.000Z\",\"owner_id\":null}','POST /api/brands [name,logo_url,country,category,company,contact,contact_info,coop_stage,grade,contract_no,contract_expiry,auth_expiry,payment_terms,remark,id,created_at,updated_at,owner_id]','2026-08-20 17:22:30'),(117,1,'系统管理员','61.186.26.93','POST','/api/products','products','7','create',NULL,'{\"name\":\"白啤精酿-纪念版（俄罗斯蓝）\",\"sku\":\"\",\"brand_id\":8,\"category\":\"\",\"main_image\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787217741747-70bf77bfb64b.webp?sign=c9ffc6f41360eaeb6e25bcd5daf552ed&t=1787217742\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":0,\"sale_price\":0,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\"}','POST /api/products [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark]','2026-08-20 17:22:32'),(118,1,'系统管理员','::ffff:127.0.0.1','GET','/api/excel/export','excel',NULL,'export',NULL,NULL,'导出台账：供应链台账_2026-08-20.xlsx','2026-08-20 17:22:40'),(119,1,'系统管理员','::ffff:127.0.0.1','GET','/api/excel/export','excel',NULL,'export',NULL,NULL,'导出台账：达人导入模板.xlsx','2026-08-20 17:22:51'),(120,2,'孙萌娟','61.186.18.195','PUT','/api/brands/15','brands','15','update',NULL,'{\"name\":\"EUBOS 优柔宝思\",\"logo_url\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787217702284-21ed3f6c7548.webp?sign=5d0f4c83bbb59a1c3065194ba09daed1&t=1787217702\",\"country\":\"德国\",\"category\":\"个护\",\"company\":\"\",\"contact\":\"孙萌娟\",\"contact_info\":\"18964565889\",\"coop_stage\":\"洽谈中\",\"grade\":\"B\",\"contract_no\":\"\",\"contract_expiry\":null,\"auth_expiry\":null,\"payment_terms\":\"\",\"remark\":\"可发政策和介绍\",\"id\":15,\"created_at\":\"2026-08-20T09:22:30.000Z\",\"updated_at\":\"2026-08-20T09:22:30.000Z\",\"owner_id\":null}','PUT /api/brands/15 [name,logo_url,country,category,company,contact,contact_info,coop_stage,grade,contract_no,contract_expiry,auth_expiry,payment_terms,remark,id,created_at,updated_at,owner_id]','2026-08-20 17:23:38'),(121,1,'系统管理员','61.186.26.93','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原191KB → 38KB','2026-08-20 17:23:42'),(122,1,'系统管理员','61.186.26.93','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=sub [cloudbase] 原257KB → 58KB','2026-08-20 17:23:46'),(123,1,'系统管理员','61.186.26.93','POST','/api/products','products','8','create',NULL,'{\"name\":\"马赫斯基农社（原浆未过滤）\",\"sku\":\"\",\"brand_id\":9,\"category\":\"\",\"main_image\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787217821789-a2dee03f9777.webp?sign=e54253602a7cc86233da2ff7ae9604f6&t=1787217822\",\"sub_image1\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787217826057-6d4adda161ea.webp?sign=782bcfa9ddeb1c412129287569dbaa2f&t=1787217826\",\"sub_image2\":\"\",\"supply_price\":0,\"sale_price\":0,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\",\"id\":6,\"created_at\":\"2026-08-20T09:16:31.000Z\",\"updated_at\":\"2026-08-20T09:16:31.000Z\",\"brand_name\":\"三山阳光\"}','POST /api/products [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-20 17:23:50'),(124,1,'系统管理员','61.186.26.93','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原161KB → 29KB','2026-08-20 17:24:24'),(125,1,'系统管理员','61.186.26.93','POST','/api/products','products','9','create',NULL,'{\"name\":\"熊蜂精酿啤酒\",\"sku\":\"\",\"brand_id\":9,\"category\":\"\",\"main_image\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787217863772-e13a8cd46ac4.webp?sign=9903c2f9fcfa4472b8092e4432bf73ed&t=1787217864\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":0,\"sale_price\":0,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\",\"id\":6,\"created_at\":\"2026-08-20T09:16:31.000Z\",\"updated_at\":\"2026-08-20T09:16:31.000Z\",\"brand_name\":\"三山阳光\"}','POST /api/products [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-20 17:24:43'),(126,1,'系统管理员','61.186.26.93','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原199KB → 34KB','2026-08-20 17:25:42'),(127,1,'系统管理员','61.186.26.93','POST','/api/products','products','10','create',NULL,'{\"name\":\"IPA精酿\",\"sku\":\"\",\"brand_id\":9,\"category\":\"\",\"main_image\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787217941573-af3f3b72df0e.webp?sign=c1109dc078d6ea29a5e35c1ebb917f23&t=1787217942\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":0,\"sale_price\":0,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\",\"id\":6,\"created_at\":\"2026-08-20T09:16:31.000Z\",\"updated_at\":\"2026-08-20T09:16:31.000Z\",\"brand_name\":\"三山阳光\"}','POST /api/products [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-20 17:25:48'),(128,1,'系统管理员','61.186.26.93','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原179KB → 31KB','2026-08-20 17:28:16'),(129,1,'系统管理员','61.186.26.93','POST','/api/products','products','11','create',NULL,'{\"name\":\"APA精酿\",\"sku\":\"\",\"brand_id\":9,\"category\":\"\",\"main_image\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787218096107-e58b1c3ce786.webp?sign=874b27f2822fd7f863b95a4f80013e66&t=1787218096\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":0,\"sale_price\":0,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\",\"id\":6,\"created_at\":\"2026-08-20T09:16:31.000Z\",\"updated_at\":\"2026-08-20T09:16:31.000Z\",\"brand_name\":\"三山阳光\"}','POST /api/products [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-20 17:28:17'),(130,1,'系统管理员','61.186.26.93','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原126KB → 23KB','2026-08-20 17:34:33'),(131,1,'系统管理员','61.186.26.93','POST','/api/products','products','12','create',NULL,'{\"name\":\"世涛精酿\",\"sku\":\"\",\"brand_id\":9,\"category\":\"\",\"main_image\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787218472502-3f8c81577337.webp?sign=547fde97836114701fecb95493f92a56&t=1787218473\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":0,\"sale_price\":0,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\",\"id\":6,\"created_at\":\"2026-08-20T09:16:31.000Z\",\"updated_at\":\"2026-08-20T09:16:31.000Z\",\"brand_name\":\"三山阳光\"}','POST /api/products [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-20 17:34:37'),(132,1,'系统管理员','61.186.18.195','PUT','/api/notifications/6','notifications','6','update',NULL,'{}','PUT /api/notifications/6','2026-08-20 17:43:29'),(133,1,'系统管理员','61.186.18.195','PUT','/api/notifications/5','notifications','5','update',NULL,'{}','PUT /api/notifications/5','2026-08-20 17:43:29'),(134,1,'系统管理员','61.186.18.195','PUT','/api/notifications/4','notifications','4','update',NULL,'{}','PUT /api/notifications/4','2026-08-20 17:43:29'),(135,1,'系统管理员','61.186.18.195','PUT','/api/notifications/3','notifications','3','update',NULL,'{}','PUT /api/notifications/3','2026-08-20 17:43:29'),(136,1,'系统管理员','61.186.18.195','PUT','/api/notifications/2','notifications','2','update',NULL,'{}','PUT /api/notifications/2','2026-08-20 17:43:29'),(137,1,'系统管理员','61.186.18.195','PUT','/api/notifications/1','notifications','1','update',NULL,'{}','PUT /api/notifications/1','2026-08-20 17:43:29'),(138,1,'系统管理员','61.186.26.93','GET','/api/excel/export','excel',NULL,'export',NULL,NULL,'导出台账：达人导入模板.xlsx','2026-08-20 17:44:46'),(139,1,'系统管理员','61.186.26.93','GET','/api/excel/export','excel',NULL,'export',NULL,NULL,'导出台账：达人导入模板.xlsx','2026-08-20 17:44:51'),(140,1,'系统管理员','61.186.26.93','POST','/api/excel/import','excel',NULL,'create',NULL,'{}','POST /api/excel/import','2026-08-20 17:48:10'),(141,1,'系统管理员','61.186.26.93','POST','/api/excel/import','excel',NULL,'create',NULL,'{}','POST /api/excel/import','2026-08-20 17:48:12'),(142,1,'系统管理员','61.186.26.93','POST','/api/excel/import','excel',NULL,'create',NULL,'{}','POST /api/excel/import','2026-08-20 17:48:13'),(143,1,'系统管理员','61.186.26.93','POST','/api/excel/import','excel',NULL,'create',NULL,'{}','POST /api/excel/import','2026-08-20 17:48:14'),(144,1,'系统管理员','61.186.26.93','POST','/api/excel/import','excel',NULL,'create',NULL,'{}','POST /api/excel/import','2026-08-20 17:48:14'),(145,1,'系统管理员','61.186.26.93','POST','/api/excel/import','excel',NULL,'create',NULL,'{}','POST /api/excel/import','2026-08-20 17:48:15'),(146,1,'系统管理员','61.186.26.93','POST','/api/excel/import','excel',NULL,'create',NULL,'{}','POST /api/excel/import','2026-08-20 17:50:16'),(147,1,'系统管理员','61.186.26.93','POST','/api/excel/import','excel',NULL,'create',NULL,'{}','POST /api/excel/import','2026-08-20 17:50:43'),(148,2,'孙萌娟','61.186.18.195','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原11KB → 2KB','2026-08-20 17:50:54'),(149,2,'孙萌娟','61.186.18.195','POST','/api/brands','brands','16','create',NULL,'{\"name\":\"VITABIOTICS\",\"logo_url\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787219453673-55693258c031.webp?sign=51fecf36a7429e506259c87e24543cdf&t=1787219454\",\"country\":\"英国\",\"category\":\"保健\",\"company\":\"\",\"contact\":\"孙萌娟\",\"contact_info\":\"17750823510\",\"coop_stage\":\"挖掘中\",\"grade\":\"C\",\"contract_no\":\"\",\"contract_expiry\":null,\"auth_expiry\":null,\"payment_terms\":\"\",\"remark\":\"\"}','POST /api/brands [name,logo_url,country,category,company,contact,contact_info,coop_stage,grade,contract_no,contract_expiry,auth_expiry,payment_terms,remark]','2026-08-20 17:51:12'),(150,2,'孙萌娟','61.186.18.195','POST','/api/brands','brands','17','create',NULL,'{\"name\":\"Weleda/维蕾德\",\"logo_url\":\"\",\"country\":\"瑞士\",\"category\":\"保健母婴\",\"company\":\"\",\"contact\":\"孙萌娟\",\"contact_info\":\"18278772873\",\"coop_stage\":\"洽谈中\",\"grade\":\"B\",\"contract_no\":\"\",\"contract_expiry\":null,\"auth_expiry\":null,\"payment_terms\":\"\",\"remark\":\"拿货授权，已发资料\"}','POST /api/brands [name,logo_url,country,category,company,contact,contact_info,coop_stage,grade,contract_no,contract_expiry,auth_expiry,payment_terms,remark]','2026-08-20 17:52:04'),(151,2,'孙萌娟','61.186.18.195','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原13KB → 3KB','2026-08-20 17:52:44'),(152,2,'孙萌娟','61.186.18.195','PUT','/api/brands/17','brands','17','update',NULL,'{\"name\":\"Weleda/维蕾德\",\"logo_url\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787219564096-b03981e74332.webp?sign=6fe91a9a7be17a94504164adf317626d&t=1787219564\",\"country\":\"瑞士\",\"category\":\"保健母婴\",\"company\":\"\",\"contact\":\"孙萌娟\",\"contact_info\":\"18278772873\",\"coop_stage\":\"洽谈中\",\"grade\":\"B\",\"contract_no\":\"\",\"contract_expiry\":null,\"auth_expiry\":null,\"payment_terms\":\"\",\"remark\":\"拿货授权，已发资料\",\"id\":17,\"created_at\":\"2026-08-20T09:52:04.000Z\",\"updated_at\":\"2026-08-20T09:52:04.000Z\",\"owner_id\":null}','PUT /api/brands/17 [name,logo_url,country,category,company,contact,contact_info,coop_stage,grade,contract_no,contract_expiry,auth_expiry,payment_terms,remark,id,created_at,updated_at,owner_id]','2026-08-20 17:52:47'),(153,1,'系统管理员','61.186.26.93','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原150KB → 23KB','2026-08-20 17:55:38'),(154,1,'系统管理员','61.186.26.93','POST','/api/products','products','13','create',NULL,'{\"name\":\"淡色IPA\",\"sku\":\"\",\"brand_id\":9,\"category\":\"\",\"main_image\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787219737548-9e7fd2faaa69.webp?sign=f31833fcada85793f05e8cf2d993e05f&t=1787219738\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":0,\"sale_price\":0,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\",\"id\":6,\"created_at\":\"2026-08-20T09:16:31.000Z\",\"updated_at\":\"2026-08-20T09:16:31.000Z\",\"brand_name\":\"三山阳光\"}','POST /api/products [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-20 17:55:43'),(155,1,'系统管理员','61.186.26.93','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原167KB → 28KB','2026-08-20 17:57:02'),(156,1,'系统管理员','61.186.26.93','POST','/api/products','products','14','create',NULL,'{\"name\":\"淡色精酿\",\"sku\":\"\",\"brand_id\":9,\"category\":\"\",\"main_image\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787219821456-ffbe1aea61ae.webp?sign=efd65a767f9abce22381a1848e4b5ae2&t=1787219822\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":0,\"sale_price\":0,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\",\"id\":6,\"created_at\":\"2026-08-20T09:16:31.000Z\",\"updated_at\":\"2026-08-20T09:16:31.000Z\",\"brand_name\":\"三山阳光\"}','POST /api/products [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-20 17:57:05'),(157,1,'系统管理员','61.186.26.93','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原167KB → 28KB','2026-08-20 17:58:05'),(158,1,'系统管理员','61.186.26.93','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原25KB → 6KB','2026-08-20 17:58:10'),(159,1,'系统管理员','61.186.26.93','POST','/api/products','products','15','create',NULL,'{\"name\":\"樱桃巴旦木味\",\"sku\":\"\",\"brand_id\":9,\"category\":\"\",\"main_image\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787219889698-a2180af57569.webp?sign=0767c63ebb90f042cf2c0500835000de&t=1787219890\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":0,\"sale_price\":0,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\",\"id\":6,\"created_at\":\"2026-08-20T09:16:31.000Z\",\"updated_at\":\"2026-08-20T09:16:31.000Z\",\"brand_name\":\"三山阳光\"}','POST /api/products [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-20 17:58:14'),(160,1,'admin','127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 09:16:50'),(161,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 09:17:09'),(162,1,'系统管理员','::ffff:127.0.0.1','POST','/api/excel/import','excel',NULL,'create',NULL,'{}','POST /api/excel/import','2026-08-21 09:17:09'),(163,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 09:17:39'),(164,1,'系统管理员','::ffff:127.0.0.1','POST','/api/excel/import','excel',NULL,'create',NULL,'{}','POST /api/excel/import','2026-08-21 09:17:39'),(165,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 09:17:52'),(166,1,'系统管理员','::ffff:127.0.0.1','POST','/api/excel/import','excel',NULL,'create',NULL,'{}','POST /api/excel/import','2026-08-21 09:17:52'),(167,1,'系统管理员','61.186.26.93','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原26KB → 5KB','2026-08-21 09:19:18'),(168,1,'系统管理员','61.186.26.93','POST','/api/products','products','16','create',NULL,'{\"name\":\"芒果荔枝味\",\"sku\":\"\",\"brand_id\":9,\"category\":\"\",\"main_image\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787275157201-6e9c1a9cc64c.webp?sign=375087df31a3bb83ae2f001b067484b1&t=1787275158\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":0,\"sale_price\":0,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\",\"id\":15,\"created_at\":\"2026-08-20T09:58:14.000Z\",\"updated_at\":\"2026-08-20T09:58:14.000Z\",\"brand_name\":\"马赫斯基\"}','POST /api/products [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-21 09:19:22'),(169,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 09:19:42'),(170,1,'系统管理员','::ffff:127.0.0.1','POST','/api/excel/import','excel',NULL,'create',NULL,'{}','POST /api/excel/import','2026-08-21 09:19:42'),(171,1,'系统管理员','61.186.26.93','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原24KB → 5KB','2026-08-21 09:21:11'),(172,1,'系统管理员','61.186.26.93','POST','/api/products','products','17','create',NULL,'{\"name\":\"草莓青柠味\",\"sku\":\"\",\"brand_id\":9,\"category\":\"\",\"main_image\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787275270057-7c90fc4691e0.webp?sign=9b9c873dc00c2c2ea440bb5d8f109e39&t=1787275271\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":0,\"sale_price\":0,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\",\"id\":15,\"created_at\":\"2026-08-20T09:58:14.000Z\",\"updated_at\":\"2026-08-20T09:58:14.000Z\",\"brand_name\":\"马赫斯基\"}','POST /api/products [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-21 09:21:15'),(173,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 09:22:05'),(174,1,'系统管理员','61.186.26.93','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原21KB → 4KB','2026-08-21 09:22:15'),(175,1,'系统管理员','61.186.26.93','POST','/api/products','products','18','create',NULL,'{\"name\":\"柠檬薄荷味\",\"sku\":\"\",\"brand_id\":9,\"category\":\"\",\"main_image\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787275335395-ddfd4a526dbd.webp?sign=744a9d870cd0995295294473dc946e2f&t=1787275335\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":0,\"sale_price\":0,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\",\"id\":15,\"created_at\":\"2026-08-20T09:58:14.000Z\",\"updated_at\":\"2026-08-20T09:58:14.000Z\",\"brand_name\":\"马赫斯基\"}','POST /api/products [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-21 09:22:22'),(176,1,'系统管理员','61.186.26.93','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原23KB → 4KB','2026-08-21 09:22:49'),(177,1,'系统管理员','61.186.26.93','POST','/api/products','products','19','create',NULL,'{\"name\":\"树莓黄桃味\",\"sku\":\"\",\"brand_id\":9,\"category\":\"\",\"main_image\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787275369227-35aee5d5a25c.webp?sign=c2f4b556d14c5cc8abecc1023f919f68&t=1787275369\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":0,\"sale_price\":0,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\",\"id\":15,\"created_at\":\"2026-08-20T09:58:14.000Z\",\"updated_at\":\"2026-08-20T09:58:14.000Z\",\"brand_name\":\"马赫斯基\"}','POST /api/products [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-21 09:23:19'),(178,1,'系统管理员','61.186.26.93','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原99KB → 17KB','2026-08-21 09:23:52'),(179,1,'系统管理员','61.186.26.93','POST','/api/products','products','20','create',NULL,'{\"name\":\"巴伐利亚小麦\",\"sku\":\"\",\"brand_id\":10,\"category\":\"\",\"main_image\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787275432030-0a303824ad60.webp?sign=1e52230d40f3e2d44649e8bc5b227b77&t=1787275432\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":0,\"sale_price\":0,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\",\"id\":15,\"created_at\":\"2026-08-20T09:58:14.000Z\",\"updated_at\":\"2026-08-20T09:58:14.000Z\",\"brand_name\":\"马赫斯基\"}','POST /api/products [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-21 09:24:32'),(180,1,'系统管理员','61.186.26.93','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原312KB → 75KB','2026-08-21 09:25:06'),(181,1,'系统管理员','61.186.26.93','POST','/api/products','products','21','create',NULL,'{\"name\":\"维也纳精酿\",\"sku\":\"\",\"brand_id\":10,\"category\":\"\",\"main_image\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787275505437-b17da67f3f3a.webp?sign=e7299db56a0d3e52217ffcdac7160b9d&t=1787275506\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":0,\"sale_price\":0,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\",\"id\":15,\"created_at\":\"2026-08-20T09:58:14.000Z\",\"updated_at\":\"2026-08-20T09:58:14.000Z\",\"brand_name\":\"马赫斯基\"}','POST /api/products [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-21 09:25:17'),(182,1,'系统管理员','61.186.26.93','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原125KB → 12KB','2026-08-21 09:26:19'),(183,1,'系统管理员','61.186.26.93','POST','/api/products','products','22','create',NULL,'{\"name\":\"维也纳 （拉罐）\",\"sku\":\"\",\"brand_id\":10,\"category\":\"\",\"main_image\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787275579067-9a8d2795601f.webp?sign=6481918dd9cfd6e84a0744730e60a1ab&t=1787275579\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":0,\"sale_price\":0,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*24听/件\",\"id\":15,\"created_at\":\"2026-08-20T09:58:14.000Z\",\"updated_at\":\"2026-08-20T09:58:14.000Z\",\"brand_name\":\"马赫斯基\"}','POST /api/products [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-21 09:26:21'),(184,1,'系统管理员','61.186.26.93','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原115KB → 18KB','2026-08-21 09:27:00'),(185,1,'系统管理员','61.186.26.93','POST','/api/products','products','23','create',NULL,'{\"name\":\"慕尼黑啤酒\",\"sku\":\"\",\"brand_id\":10,\"category\":\"\",\"main_image\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787275619863-cd26d9813868.webp?sign=6fad7d62f6f3aac900087b1773ff233e&t=1787275620\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":0,\"sale_price\":0,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*24听/件\",\"id\":15,\"created_at\":\"2026-08-20T09:58:14.000Z\",\"updated_at\":\"2026-08-20T09:58:14.000Z\",\"brand_name\":\"马赫斯基\"}','POST /api/products [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-21 09:27:17'),(186,1,'系统管理员','61.186.26.93','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原338KB → 60KB','2026-08-21 09:27:47'),(187,1,'系统管理员','61.186.26.93','POST','/api/products','products','24','create',NULL,'{\"name\":\"精酿小瓶\",\"sku\":\"\",\"brand_id\":11,\"category\":\"\",\"main_image\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787275666766-65324ff46f75.webp?sign=d10bc70795eb429cfb54ce0275be50be&t=1787275667\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":0,\"sale_price\":0,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"310ML*18瓶/件\",\"id\":15,\"created_at\":\"2026-08-20T09:58:14.000Z\",\"updated_at\":\"2026-08-20T09:58:14.000Z\",\"brand_name\":\"马赫斯基\"}','POST /api/products [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-21 09:27:59'),(188,1,'系统管理员','61.186.26.93','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [cloudbase] 原138KB → 22KB','2026-08-21 09:29:07'),(189,1,'系统管理员','61.186.26.93','POST','/api/products','products','25','create',NULL,'{\"name\":\"精酿大瓶\",\"sku\":\"\",\"brand_id\":11,\"category\":\"\",\"main_image\":\"https://7975-yunkaifa-d6gv4l0caddb222ba-1257037640.tcb.qcloud.la/uploads/1787275746539-25fa333e6584.webp?sign=04cd819ba11bfb75f03be2c7acc1febc&t=1787275747\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":0,\"sale_price\":0,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"900ML*12瓶/件\",\"id\":15,\"created_at\":\"2026-08-20T09:58:14.000Z\",\"updated_at\":\"2026-08-20T09:58:14.000Z\",\"brand_name\":\"马赫斯基\"}','POST /api/products [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-21 09:29:10'),(190,1,'admin','61.186.18.195','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 09:34:00'),(191,1,'admin','61.186.18.195','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 09:34:28'),(192,1,'admin','61.186.18.195','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 09:34:49'),(193,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 09:35:43'),(194,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 09:38:44'),(195,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 09:38:53'),(196,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 09:43:32'),(197,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 09:49:21'),(198,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 09:53:42'),(199,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 09:58:38'),(200,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 09:59:17'),(201,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 10:00:31'),(202,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 10:02:54'),(203,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 10:13:48'),(204,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 10:32:39'),(205,1,'系统管理员','::ffff:127.0.0.1','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [local+cloudbase] 原0KB → 0KB','2026-08-21 10:32:39'),(206,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 10:36:22'),(207,1,'admin','61.186.18.195','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 10:36:46'),(208,1,'admin','61.186.18.195','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 11:21:38'),(209,1,'admin','61.186.18.195','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 11:22:03'),(210,1,'admin','61.186.18.195','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 11:22:40'),(211,1,'admin','61.186.18.195','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 11:23:42'),(212,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 11:25:54'),(213,1,'admin','61.186.18.195','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 11:30:56'),(214,1,'admin','61.186.18.195','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 11:47:38'),(215,1,'admin','61.186.18.195','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 11:48:07'),(216,1,'系统管理员','61.186.18.195','PUT','/api/scores/account-dims','scores',NULL,'update',NULL,'{\"dims\":[{\"dim_id\":1,\"enabled\":1},{\"dim_id\":2,\"enabled\":1},{\"dim_id\":3,\"enabled\":0},{\"dim_id\":4,\"enabled\":0},{\"dim_id\":5,\"enabled\":0},{\"dim_id\":6,\"enabled\":0},{\"dim_id\":7,\"enabled\":0},{\"dim_id\":8,\"enabled\":0},{\"dim_id\":9,\"enabled\":0},{\"dim_id\":10,\"enabled\":0},{\"dim_id\":11,\"enabled\":0},{\"dim_id\":12,\"enabled\":0},{\"dim_id\":13,\"enabled\":0},{\"dim_id\":14,\"enabled\":0},{\"dim_id\":15,\"enabled\":0},{\"dim_id\":16,\"enabled\":0}]}','PUT /api/scores/account-dims [dims]','2026-08-21 11:48:13'),(217,1,'admin','61.186.18.195','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 11:48:36'),(218,1,'系统管理员','61.186.18.195','PUT','/api/scores/account-dims','scores',NULL,'update',NULL,'{\"dims\":[{\"dim_id\":1,\"enabled\":1},{\"dim_id\":2,\"enabled\":1},{\"dim_id\":3,\"enabled\":1},{\"dim_id\":4,\"enabled\":1},{\"dim_id\":5,\"enabled\":1},{\"dim_id\":6,\"enabled\":1},{\"dim_id\":7,\"enabled\":1},{\"dim_id\":8,\"enabled\":1},{\"dim_id\":9,\"enabled\":1},{\"dim_id\":10,\"enabled\":1},{\"dim_id\":11,\"enabled\":1},{\"dim_id\":12,\"enabled\":1},{\"dim_id\":13,\"enabled\":1},{\"dim_id\":14,\"enabled\":1},{\"dim_id\":15,\"enabled\":1},{\"dim_id\":16,\"enabled\":1}]}','PUT /api/scores/account-dims [dims]','2026-08-21 11:48:36'),(219,1,'系统管理员','61.186.18.195','POST','/api/scores','scores','2','create',NULL,'{\"subject_type\":\"product\",\"subject_id\":24,\"scores\":{\"margin\":0,\"story\":7,\"usp\":0,\"content\":0,\"search\":0,\"trend\":0,\"competition\":0,\"potential\":0,\"supply\":0,\"inventory\":0,\"logistics\":0,\"cert\":0,\"ip\":0,\"legal\":0,\"repeat\":0,\"season\":0},\"remark\":null}','POST /api/scores [subject_type,subject_id,scores,remark]','2026-08-21 12:00:15'),(220,1,'系统管理员','61.186.26.93','PUT','/api/products/3','products','3','update',NULL,'{\"name\":\"1875经典-阳光精酿\",\"sku\":\"\",\"brand_id\":8,\"category\":\"\",\"main_image\":\"/uploads/1787217326433-706d0c586b4b.webp\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":53,\"sale_price\":89.8,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\",\"id\":3,\"created_at\":\"2026-08-20T09:12:13.000Z\",\"updated_at\":\"2026-08-21T02:35:38.000Z\",\"brand_name\":\"三山阳光\"}','PUT /api/products/3 [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-21 15:27:59'),(221,1,'系统管理员','61.186.26.93','PUT','/api/products/6','products','6','update',NULL,'{\"name\":\"淡色精酿-纪念版（中国红）\",\"sku\":\"\",\"brand_id\":8,\"category\":\"\",\"main_image\":\"/uploads/1787217390014-6f54ce9d1c56.webp\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":60,\"sale_price\":99.8,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\",\"id\":6,\"created_at\":\"2026-08-20T09:16:31.000Z\",\"updated_at\":\"2026-08-21T02:35:39.000Z\",\"brand_name\":\"三山阳光\"}','PUT /api/products/6 [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-21 15:28:17'),(222,1,'系统管理员','61.186.26.93','PUT','/api/products/8','products','8','update',NULL,'{\"name\":\"马赫斯基农社（原浆未过滤）\",\"sku\":\"\",\"brand_id\":9,\"category\":\"\",\"main_image\":\"/uploads/1787217821789-a2dee03f9777.webp\",\"sub_image1\":\"/uploads/1787217826057-6d4adda161ea.webp\",\"sub_image2\":\"\",\"supply_price\":78,\"sale_price\":158,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\",\"id\":8,\"created_at\":\"2026-08-20T09:23:50.000Z\",\"updated_at\":\"2026-08-21T02:35:41.000Z\",\"brand_name\":\"马赫斯基\"}','PUT /api/products/8 [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-21 15:28:35'),(223,1,'系统管理员','61.186.26.93','PUT','/api/products/9','products','9','update',NULL,'{\"name\":\"熊蜂精酿啤酒\",\"sku\":\"\",\"brand_id\":9,\"category\":\"\",\"main_image\":\"/uploads/1787217863772-e13a8cd46ac4.webp\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":79.2,\"sale_price\":158,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\",\"id\":9,\"created_at\":\"2026-08-20T09:24:43.000Z\",\"updated_at\":\"2026-08-21T02:35:41.000Z\",\"brand_name\":\"马赫斯基\"}','PUT /api/products/9 [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-21 15:28:57'),(224,1,'系统管理员','61.186.26.93','PUT','/api/products/11','products','11','update',NULL,'{\"name\":\"APA精酿\",\"sku\":\"\",\"brand_id\":9,\"category\":\"\",\"main_image\":\"/uploads/1787218096107-e58b1c3ce786.webp\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":79.2,\"sale_price\":158,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\",\"id\":11,\"created_at\":\"2026-08-20T09:28:17.000Z\",\"updated_at\":\"2026-08-21T02:35:42.000Z\",\"brand_name\":\"马赫斯基\"}','PUT /api/products/11 [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-21 15:29:10'),(225,1,'系统管理员','61.186.26.93','PUT','/api/products/10','products','10','update',NULL,'{\"name\":\"IPA精酿\",\"sku\":\"\",\"brand_id\":9,\"category\":\"\",\"main_image\":\"/uploads/1787217941573-af3f3b72df0e.webp\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":79.2,\"sale_price\":158,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\",\"id\":10,\"created_at\":\"2026-08-20T09:25:48.000Z\",\"updated_at\":\"2026-08-21T02:35:42.000Z\",\"brand_name\":\"马赫斯基\"}','PUT /api/products/10 [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-21 15:29:22'),(226,1,'系统管理员','61.186.26.93','PUT','/api/products/13','products','13','update',NULL,'{\"name\":\"淡色IPA\",\"sku\":\"\",\"brand_id\":9,\"category\":\"\",\"main_image\":\"/uploads/1787219737548-9e7fd2faaa69.webp\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":79.2,\"sale_price\":158,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\",\"id\":13,\"created_at\":\"2026-08-20T09:55:43.000Z\",\"updated_at\":\"2026-08-21T02:35:43.000Z\",\"brand_name\":\"马赫斯基\"}','PUT /api/products/13 [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-21 15:29:37'),(227,1,'系统管理员','61.186.26.93','PUT','/api/products/12','products','12','update',NULL,'{\"name\":\"世涛精酿\",\"sku\":\"\",\"brand_id\":9,\"category\":\"\",\"main_image\":\"/uploads/1787218472502-3f8c81577337.webp\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":79.2,\"sale_price\":158,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\",\"id\":12,\"created_at\":\"2026-08-20T09:34:37.000Z\",\"updated_at\":\"2026-08-21T02:35:43.000Z\",\"brand_name\":\"马赫斯基\"}','PUT /api/products/12 [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-21 15:29:58'),(228,1,'系统管理员','61.186.26.93','PUT','/api/products/14','products','14','update',NULL,'{\"name\":\"淡色精酿\",\"sku\":\"\",\"brand_id\":9,\"category\":\"\",\"main_image\":\"/uploads/1787219821456-ffbe1aea61ae.webp\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":79.2,\"sale_price\":158,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\",\"id\":14,\"created_at\":\"2026-08-20T09:57:05.000Z\",\"updated_at\":\"2026-08-21T02:35:44.000Z\",\"brand_name\":\"马赫斯基\"}','PUT /api/products/14 [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-21 15:30:11'),(229,1,'系统管理员','61.186.26.93','PUT','/api/products/15','products','15','update',NULL,'{\"name\":\"樱桃巴旦木味\",\"sku\":\"\",\"brand_id\":9,\"category\":\"\",\"main_image\":\"/uploads/1787219889698-a2180af57569.webp\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":71.5,\"sale_price\":148,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\",\"id\":15,\"created_at\":\"2026-08-20T09:58:14.000Z\",\"updated_at\":\"2026-08-21T02:35:44.000Z\",\"brand_name\":\"马赫斯基\"}','PUT /api/products/15 [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-21 15:30:46'),(230,1,'系统管理员','61.186.26.93','PUT','/api/products/17','products','17','update',NULL,'{\"name\":\"草莓青柠味\",\"sku\":\"\",\"brand_id\":9,\"category\":\"\",\"main_image\":\"/uploads/1787275270057-7c90fc4691e0.webp\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":71.5,\"sale_price\":148,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\",\"id\":17,\"created_at\":\"2026-08-21T01:21:15.000Z\",\"updated_at\":\"2026-08-21T02:35:45.000Z\",\"brand_name\":\"马赫斯基\"}','PUT /api/products/17 [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-21 15:30:55'),(231,1,'系统管理员','61.186.26.93','PUT','/api/products/16','products','16','update',NULL,'{\"name\":\"芒果荔枝味\",\"sku\":\"\",\"brand_id\":9,\"category\":\"\",\"main_image\":\"/uploads/1787275157201-6e9c1a9cc64c.webp\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":71.5,\"sale_price\":148,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\",\"id\":16,\"created_at\":\"2026-08-21T01:19:22.000Z\",\"updated_at\":\"2026-08-21T02:35:45.000Z\",\"brand_name\":\"马赫斯基\"}','PUT /api/products/16 [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-21 15:31:06'),(232,1,'系统管理员','61.186.26.93','PUT','/api/products/19','products','19','update',NULL,'{\"name\":\"树莓黄桃味\",\"sku\":\"\",\"brand_id\":9,\"category\":\"\",\"main_image\":\"/uploads/1787275369227-35aee5d5a25c.webp\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":71.5,\"sale_price\":148,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\",\"id\":19,\"created_at\":\"2026-08-21T01:23:19.000Z\",\"updated_at\":\"2026-08-21T02:35:46.000Z\",\"brand_name\":\"马赫斯基\"}','PUT /api/products/19 [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-21 15:31:15'),(233,1,'系统管理员','61.186.26.93','PUT','/api/products/18','products','18','update',NULL,'{\"name\":\"柠檬薄荷味\",\"sku\":\"\",\"brand_id\":9,\"category\":\"\",\"main_image\":\"/uploads/1787275335395-ddfd4a526dbd.webp\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":71.5,\"sale_price\":148,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*12瓶/件\",\"id\":18,\"created_at\":\"2026-08-21T01:22:22.000Z\",\"updated_at\":\"2026-08-21T02:35:46.000Z\",\"brand_name\":\"马赫斯基\"}','PUT /api/products/18 [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-21 15:31:28'),(234,1,'系统管理员','61.186.26.93','PUT','/api/products/23','products','23','update',NULL,'{\"name\":\"慕尼黑啤酒\",\"sku\":\"\",\"brand_id\":10,\"category\":\"\",\"main_image\":\"/uploads/1787275619863-cd26d9813868.webp\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":108,\"sale_price\":198,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*24听/件\",\"id\":23,\"created_at\":\"2026-08-21T01:27:17.000Z\",\"updated_at\":\"2026-08-21T02:35:48.000Z\",\"brand_name\":\"鸿迈\"}','PUT /api/products/23 [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-21 15:31:46'),(235,1,'系统管理员','61.186.26.93','PUT','/api/products/22','products','22','update',NULL,'{\"name\":\"维也纳 （拉罐）\",\"sku\":\"\",\"brand_id\":10,\"category\":\"\",\"main_image\":\"/uploads/1787275579067-9a8d2795601f.webp\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":108,\"sale_price\":198,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"450ML*24听/件\",\"id\":22,\"created_at\":\"2026-08-21T01:26:21.000Z\",\"updated_at\":\"2026-08-21T02:35:48.000Z\",\"brand_name\":\"鸿迈\"}','PUT /api/products/22 [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark,id,created_at,updated_at,brand_name]','2026-08-21 15:31:56'),(236,1,'系统管理员','61.186.26.93','PUT','/api/scores/2','scores','2','update',NULL,'{\"subject_type\":\"product\",\"subject_id\":24,\"scores\":{\"margin\":15,\"story\":5,\"usp\":5,\"content\":6,\"search\":4,\"trend\":4,\"competition\":3,\"potential\":4,\"supply\":4,\"inventory\":5,\"logistics\":4,\"cert\":5,\"ip\":5,\"legal\":5,\"repeat\":10,\"season\":5},\"remark\":null,\"_score_id\":2}','PUT /api/scores/2 [subject_type,subject_id,scores,remark,_score_id]','2026-08-21 15:41:21'),(237,2,'孙萌娟','61.186.18.195','POST','/api/auth/logout',NULL,NULL,'logout',NULL,NULL,'退出登录','2026-08-21 16:00:36'),(238,1,'admin','61.186.18.195','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 16:00:39'),(239,1,'系统管理员','61.186.18.195','PUT','/api/users/2','users','2','update','{\"name\":\"孙萌娟\",\"role\":\"selection\",\"dept\":\"供应链中心\",\"permissions\":\"[\\\"dashboard\\\",\\\"brands\\\",\\\"darens\\\",\\\"products\\\",\\\"coop\\\",\\\"samples\\\",\\\"scores\\\",\\\"commission\\\",\\\"excel\\\"]\"}','{\"name\":\"孙萌娟\",\"role\":\"admin\",\"dept\":\"供应链中心\",\"permissions\":\"[\\\"dashboard\\\",\\\"brands\\\",\\\"darens\\\",\\\"products\\\",\\\"coop\\\",\\\"samples\\\",\\\"scores\\\",\\\"commission\\\",\\\"excel\\\"]\"}','编辑账号','2026-08-21 16:00:53'),(240,1,'系统管理员','61.186.18.195','POST','/api/auth/logout',NULL,NULL,'logout',NULL,NULL,'退出登录','2026-08-21 16:00:57'),(241,2,'孙萌娟','61.186.18.195','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-21 16:01:00'),(242,2,'孙萌娟','61.186.18.195','POST','/api/scores','scores','3','create',NULL,'{\"subject_type\":\"brand\",\"subject_id\":5,\"scores\":{\"margin\":8,\"story\":7,\"usp\":5,\"content\":4,\"search\":4,\"trend\":4,\"competition\":3,\"potential\":4,\"supply\":4,\"inventory\":4,\"logistics\":4,\"cert\":5,\"ip\":5,\"legal\":5,\"repeat\":10,\"season\":3},\"remark\":null}','POST /api/scores [subject_type,subject_id,scores,remark]','2026-08-21 16:10:34'),(243,2,'孙萌娟','61.186.18.195','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [local+cloudbase] 原50KB → 6KB','2026-08-21 16:18:38'),(244,2,'孙萌娟','61.186.18.195','POST','/api/products','products','26','create',NULL,'{\"name\":\"AniForte防狗狗叫止吠扰民神器安神助眠帮助调整睡眠宠\",\"sku\":\"\",\"brand_id\":5,\"category\":\"\",\"main_image\":\"/uploads/1787300317861-f5223f5281e2.webp\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":258,\"sale_price\":386,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"\"}','POST /api/products [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark]','2026-08-21 16:18:45'),(245,2,'孙萌娟','61.186.18.195','POST','/api/upload/image','upload',NULL,'create',NULL,NULL,'上传图片 kind=main [local+cloudbase] 原91KB → 17KB','2026-08-21 16:22:09'),(246,2,'孙萌娟','61.186.18.195','POST','/api/products','products','27','create',NULL,'{\"name\":\"vivelab头皮精华浓密发际线滚珠防脱精华固发缓解脱发\",\"sku\":\"\",\"brand_id\":12,\"category\":\"\",\"main_image\":\"/uploads/1787300528813-05b66966b8a6.webp\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":55,\"sale_price\":99,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"不含运，整箱拿货价\"}','POST /api/products [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark]','2026-08-21 16:22:26'),(247,2,'孙萌娟','61.186.18.195','POST','/api/scores','scores','4','create',NULL,'{\"subject_type\":\"product\",\"subject_id\":27,\"scores\":{\"margin\":12,\"story\":7,\"usp\":7,\"content\":4,\"search\":4,\"trend\":4,\"competition\":3,\"potential\":4,\"supply\":4,\"inventory\":4,\"logistics\":4,\"cert\":5,\"ip\":5,\"legal\":5,\"repeat\":10,\"season\":3},\"remark\":null}','POST /api/scores [subject_type,subject_id,scores,remark]','2026-08-21 16:27:08'),(248,2,'孙萌娟','61.186.18.195','POST','/api/scores','scores','5','create',NULL,'{\"subject_type\":\"product\",\"subject_id\":26,\"scores\":{\"margin\":8,\"story\":7,\"usp\":7,\"content\":4,\"search\":4,\"trend\":4,\"competition\":3,\"potential\":4,\"supply\":4,\"inventory\":4,\"logistics\":4,\"cert\":5,\"ip\":5,\"legal\":5,\"repeat\":10,\"season\":3},\"remark\":null}','POST /api/scores [subject_type,subject_id,scores,remark]','2026-08-21 16:42:39');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `brands`
--

DROP TABLE IF EXISTS `brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `brands` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '品牌名称',
  `logo_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Logo 图片 URL（COS）',
  `country` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '国家/地区',
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '主营品类',
  `company` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '品牌方主体',
  `contact` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '对接人',
  `contact_info` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '联系方式',
  `coop_stage` enum('挖掘中','洽谈中','已签约','合作中','已终止') COLLATE utf8mb4_unicode_ci DEFAULT '挖掘中' COMMENT '合作进度',
  `grade` enum('S','A','B','C') COLLATE utf8mb4_unicode_ci DEFAULT 'C' COMMENT '品牌分级',
  `contract_no` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '合同编号',
  `contract_expiry` date DEFAULT NULL COMMENT '合同到期日（到期提醒）',
  `auth_expiry` date DEFAULT NULL COMMENT '授权到期日',
  `payment_terms` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '账期',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `owner_id` int(10) unsigned DEFAULT NULL COMMENT '负责的选品专员user_id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='品牌档案';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brands`
--

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
INSERT INTO `brands` VALUES (3,'千颂','','日本','酒','','','','挖掘中','C','',NULL,NULL,'','','2026-08-17 15:56:18','2026-08-17 15:56:18',NULL),(4,'Natural Animal Solutions','/uploads/1787216425633-56ff16580790.webp','澳洲','宠物补剂','','孙萌娟','暂无','挖掘中','C','',NULL,NULL,'','天猫跨境直营，国内无明确总代','2026-08-20 17:00:34','2026-08-21 10:35:33',NULL),(5,'Aniforte','/uploads/1787216538867-0093384d5b2d.webp','德国','宠物补剂','','孙萌娟','13805011696','洽谈中','B','',NULL,NULL,'','已发资料和报价，2000起拿货','2026-08-20 17:02:41','2026-08-21 10:35:34',NULL),(6,'SAMBUCOL','/uploads/1787216693750-363641fc7d93.webp','英国','母婴保健','','孙萌娟','17750823510','挖掘中','C','',NULL,NULL,'','品牌直营子公司，目前联系到的只能一件代发','2026-08-20 17:05:33','2026-08-21 10:35:34',NULL),(7,'Mivolis','/uploads/1787216823538-74507083675d.webp','德国','保健','','孙萌娟','无','挖掘中','C','',NULL,NULL,'','德国超市自有品牌，无授权','2026-08-20 17:07:21','2026-08-21 10:35:34',NULL),(8,'三山阳光','','俄罗斯','酒','','','','洽谈中','A','',NULL,NULL,'','','2026-08-20 17:10:23','2026-08-20 17:10:23',NULL),(9,'马赫斯基','','俄罗斯','酒','','','','洽谈中','A','',NULL,NULL,'','','2026-08-20 17:10:54','2026-08-20 17:10:54',NULL),(10,'鸿迈','','俄罗斯','酒','','','','洽谈中','A','',NULL,NULL,'','','2026-08-20 17:11:17','2026-08-20 17:11:17',NULL),(11,'酌力','','俄罗斯','酒','','','','洽谈中','A','',NULL,NULL,'','','2026-08-20 17:11:34','2026-08-20 17:11:34',NULL),(12,'Vivelab','/uploads/1787217186510-eda2727ecee4.webp','韩国','洗护','','孙萌娟','','挖掘中','C','',NULL,NULL,'','','2026-08-20 17:13:39','2026-08-21 10:35:35',NULL),(13,'八潮','/uploads/1787217440641-c51771e20935.webp','日本','酒水','','孙萌娟','','挖掘中','C','',NULL,NULL,'','','2026-08-20 17:17:27','2026-08-21 10:35:35',NULL),(14,'OLDELA 欧德拉','/uploads/1787217629091-9917f8f959c9.webp','德国','保健','','孙萌娟','15221875898','挖掘中','C','',NULL,NULL,'','海外店可以提供授权，无中文标贴不能售卖','2026-08-20 17:20:30','2026-08-21 10:35:36',NULL),(15,'EUBOS 优柔宝思','/uploads/1787217702284-21ed3f6c7548.webp','德国','个护','','孙萌娟','18964565889','洽谈中','B','',NULL,NULL,'','可发政策和介绍','2026-08-20 17:22:30','2026-08-21 10:35:37',NULL),(16,'VITABIOTICS','/uploads/1787219453673-55693258c031.webp','英国','保健','','孙萌娟','17750823510','挖掘中','C','',NULL,NULL,'','','2026-08-20 17:51:12','2026-08-21 10:35:37',NULL),(17,'Weleda/维蕾德','/uploads/1787219564096-b03981e74332.webp','瑞士','保健母婴','','孙萌娟','18278772873','洽谈中','B','',NULL,NULL,'','拿货授权，已发资料','2026-08-20 17:52:04','2026-08-21 10:35:37',NULL);
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commission_configs`
--

DROP TABLE IF EXISTS `commission_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commission_configs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `daren_id` int(10) unsigned NOT NULL COMMENT '达人ID',
  `product_id` int(10) unsigned NOT NULL COMMENT '商品ID',
  `rate` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT '佣金率(%)',
  `effective_date` date DEFAULT NULL COMMENT '生效日期',
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_dp` (`daren_id`,`product_id`),
  KEY `idx_daren` (`daren_id`),
  KEY `idx_product` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='佣金方案配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commission_configs`
--

LOCK TABLES `commission_configs` WRITE;
/*!40000 ALTER TABLE `commission_configs` DISABLE KEYS */;
/*!40000 ALTER TABLE `commission_configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coop_logs`
--

DROP TABLE IF EXISTS `coop_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coop_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `daren_id` int(10) unsigned NOT NULL,
  `from_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '旧状态',
  `to_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '新状态',
  `operator_id` int(10) unsigned DEFAULT NULL COMMENT '操作人',
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_pd` (`product_id`,`daren_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='合作状态变更历史';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coop_logs`
--

LOCK TABLES `coop_logs` WRITE;
/*!40000 ALTER TABLE `coop_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `coop_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `darens`
--

DROP TABLE IF EXISTS `darens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `darens` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '达人名称',
  `douyin_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '抖音号',
  `fans` int(11) DEFAULT '0' COMMENT '粉丝量',
  `coop_status` enum('建联中','寄样中','已合作','已终止') COLLATE utf8mb4_unicode_ci DEFAULT '建联中' COMMENT '合作状态',
  `cooperation` tinyint(4) DEFAULT NULL COMMENT '配合度(1-5)',
  `contact` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '联系方式',
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '带货品类',
  `gmv` decimal(14,2) DEFAULT '0.00' COMMENT '累计GMV',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='达人矩阵';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `darens`
--

LOCK TABLES `darens` WRITE;
/*!40000 ALTER TABLE `darens` DISABLE KEYS */;
/*!40000 ALTER TABLE `darens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `type` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT 'info' COMMENT 'info/contract/stock/sample',
  `content` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_read` tinyint(4) DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='站内通知';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (1,1,'sample','寄样记录 #2 状态由「申请」变更为「寄出」',1,'2026-08-20 17:14:43'),(2,1,'sample','寄样记录 #2 状态由「寄出」变更为「签收」',1,'2026-08-20 17:14:43'),(3,1,'sample','寄样记录 #2 状态由「签收」变更为「已回收」',1,'2026-08-20 17:14:43'),(4,1,'sample','寄样记录 #3 状态由「申请」变更为「寄出」',1,'2026-08-20 17:15:33'),(5,1,'sample','寄样记录 #3 状态由「寄出」变更为「签收」',1,'2026-08-20 17:15:33'),(6,1,'sample','寄样记录 #3 状态由「签收」变更为「已回收」',1,'2026-08-20 17:15:33');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_daren`
--

DROP TABLE IF EXISTS `product_daren`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_daren` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `daren_id` int(10) unsigned NOT NULL,
  `status` enum('对接中','带货中','不合适','已终止') COLLATE utf8mb4_unicode_ci DEFAULT '对接中' COMMENT '当前合作状态',
  `coop_fee` decimal(12,2) DEFAULT '0.00' COMMENT '合作费用',
  `coop_mode` enum('短视频','直播','图文','混合') COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '带货方式',
  `commission_rate` decimal(5,2) DEFAULT '0.00' COMMENT '佣金比例(%)',
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '合作备注',
  `updated_by` int(10) unsigned DEFAULT NULL COMMENT '最后操作人',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_pd` (`product_id`,`daren_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='商品-达人合作（多对多）';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_daren`
--

LOCK TABLES `product_daren` WRITE;
/*!40000 ALTER TABLE `product_daren` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_daren` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '商品名称',
  `sku` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SKU',
  `brand_id` int(10) unsigned DEFAULT NULL COMMENT '所属品牌',
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '品类',
  `main_image` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '主图 URL',
  `sub_image1` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '副图1 URL',
  `sub_image2` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '副图2 URL',
  `supply_price` decimal(12,2) DEFAULT '0.00' COMMENT '供货价',
  `sale_price` decimal(12,2) DEFAULT '0.00' COMMENT '售价',
  `stock` int(11) DEFAULT '0' COMMENT '库存数量',
  `stock_warn` int(11) DEFAULT '0' COMMENT '库存预警线',
  `shelf_status` enum('待上架','已上架','已下架') COLLATE utf8mb4_unicode_ci DEFAULT '待上架' COMMENT '上架状态',
  `sales` int(11) DEFAULT '0' COMMENT '累计销量',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_brand` (`brand_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='商品档案';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (2,'千颂威士忌','',3,'','','','',0.00,0.00,0,0,'待上架',0,'','2026-08-17 15:56:31','2026-08-17 15:56:31'),(3,'1875经典-阳光精酿','',8,'','/uploads/1787217326433-706d0c586b4b.webp','','',53.00,89.80,0,0,'待上架',0,'450ML*12瓶/件','2026-08-20 17:12:13','2026-08-21 15:27:59'),(4,'1875经典-纪念版（畅饮黄）','',8,'','/uploads/1787217271066-1c43c2d3c395.webp','','',0.00,0.00,0,0,'待上架',0,'450ML*12瓶/件','2026-08-20 17:12:42','2026-08-21 10:35:38'),(5,'淡色红标-4.9度精酿','',8,'','/uploads/1787217228533-e4e6b694d8ea.webp','','',0.00,0.00,0,0,'待上架',0,'450ML*12瓶/件','2026-08-20 17:13:50','2026-08-21 10:35:39'),(6,'淡色精酿-纪念版（中国红）','',8,'','/uploads/1787217390014-6f54ce9d1c56.webp','','',60.00,99.80,0,0,'待上架',0,'450ML*12瓶/件','2026-08-20 17:16:31','2026-08-21 15:28:17'),(7,'白啤精酿-纪念版（俄罗斯蓝）','',8,'','/uploads/1787217741747-70bf77bfb64b.webp','','',0.00,0.00,0,0,'待上架',0,'450ML*12瓶/件','2026-08-20 17:22:32','2026-08-21 10:35:40'),(8,'马赫斯基农社（原浆未过滤）','',9,'','/uploads/1787217821789-a2dee03f9777.webp','/uploads/1787217826057-6d4adda161ea.webp','',78.00,158.00,0,0,'待上架',0,'450ML*12瓶/件','2026-08-20 17:23:50','2026-08-21 15:28:35'),(9,'熊蜂精酿啤酒','',9,'','/uploads/1787217863772-e13a8cd46ac4.webp','','',79.20,158.00,0,0,'待上架',0,'450ML*12瓶/件','2026-08-20 17:24:43','2026-08-21 15:28:57'),(10,'IPA精酿','',9,'','/uploads/1787217941573-af3f3b72df0e.webp','','',79.20,158.00,0,0,'待上架',0,'450ML*12瓶/件','2026-08-20 17:25:48','2026-08-21 15:29:22'),(11,'APA精酿','',9,'','/uploads/1787218096107-e58b1c3ce786.webp','','',79.20,158.00,0,0,'待上架',0,'450ML*12瓶/件','2026-08-20 17:28:17','2026-08-21 15:29:10'),(12,'世涛精酿','',9,'','/uploads/1787218472502-3f8c81577337.webp','','',79.20,158.00,0,0,'待上架',0,'450ML*12瓶/件','2026-08-20 17:34:37','2026-08-21 15:29:58'),(13,'淡色IPA','',9,'','/uploads/1787219737548-9e7fd2faaa69.webp','','',79.20,158.00,0,0,'待上架',0,'450ML*12瓶/件','2026-08-20 17:55:43','2026-08-21 15:29:37'),(14,'淡色精酿','',9,'','/uploads/1787219821456-ffbe1aea61ae.webp','','',79.20,158.00,0,0,'待上架',0,'450ML*12瓶/件','2026-08-20 17:57:05','2026-08-21 15:30:11'),(15,'樱桃巴旦木味','',9,'','/uploads/1787219889698-a2180af57569.webp','','',71.50,148.00,0,0,'待上架',0,'450ML*12瓶/件','2026-08-20 17:58:14','2026-08-21 15:30:46'),(16,'芒果荔枝味','',9,'','/uploads/1787275157201-6e9c1a9cc64c.webp','','',71.50,148.00,0,0,'待上架',0,'450ML*12瓶/件','2026-08-21 09:19:22','2026-08-21 15:31:06'),(17,'草莓青柠味','',9,'','/uploads/1787275270057-7c90fc4691e0.webp','','',71.50,148.00,0,0,'待上架',0,'450ML*12瓶/件','2026-08-21 09:21:15','2026-08-21 15:30:55'),(18,'柠檬薄荷味','',9,'','/uploads/1787275335395-ddfd4a526dbd.webp','','',71.50,148.00,0,0,'待上架',0,'450ML*12瓶/件','2026-08-21 09:22:22','2026-08-21 15:31:28'),(19,'树莓黄桃味','',9,'','/uploads/1787275369227-35aee5d5a25c.webp','','',71.50,148.00,0,0,'待上架',0,'450ML*12瓶/件','2026-08-21 09:23:19','2026-08-21 15:31:15'),(20,'巴伐利亚小麦','',10,'','/uploads/1787275432030-0a303824ad60.webp','','',0.00,0.00,0,0,'待上架',0,'450ML*12瓶/件','2026-08-21 09:24:32','2026-08-21 10:35:47'),(21,'维也纳精酿','',10,'','/uploads/1787275505437-b17da67f3f3a.webp','','',0.00,0.00,0,0,'待上架',0,'450ML*12瓶/件','2026-08-21 09:25:17','2026-08-21 10:35:47'),(22,'维也纳 （拉罐）','',10,'','/uploads/1787275579067-9a8d2795601f.webp','','',108.00,198.00,0,0,'待上架',0,'450ML*24听/件','2026-08-21 09:26:21','2026-08-21 15:31:56'),(23,'慕尼黑啤酒','',10,'','/uploads/1787275619863-cd26d9813868.webp','','',108.00,198.00,0,0,'待上架',0,'450ML*24听/件','2026-08-21 09:27:17','2026-08-21 15:31:46'),(24,'精酿小瓶','',11,'','/uploads/1787275666766-65324ff46f75.webp','','',0.00,0.00,0,0,'待上架',0,'310ML*18瓶/件','2026-08-21 09:27:59','2026-08-21 10:35:49'),(25,'精酿大瓶','',11,'','/uploads/1787275746539-25fa333e6584.webp','','',0.00,0.00,0,0,'待上架',0,'900ML*12瓶/件','2026-08-21 09:29:10','2026-08-21 10:35:49'),(26,'AniForte防狗狗叫止吠扰民神器安神助眠帮助调整睡眠宠','',5,'','/uploads/1787300317861-f5223f5281e2.webp','','',258.00,386.00,0,0,'待上架',0,'','2026-08-21 16:18:45','2026-08-21 16:18:45'),(27,'vivelab头皮精华浓密发际线滚珠防脱精华固发缓解脱发','',12,'','/uploads/1787300528813-05b66966b8a6.webp','','',55.00,99.00,0,0,'待上架',0,'不含运，整箱拿货价','2026-08-21 16:22:26','2026-08-21 16:22:26');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_records`
--

DROP TABLE IF EXISTS `sales_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales_records` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `daren_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  `period` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '结算周期',
  `gmv` decimal(14,2) DEFAULT '0.00',
  `orders` int(11) DEFAULT '0' COMMENT '订单数',
  `commission` decimal(14,2) DEFAULT '0.00' COMMENT '佣金',
  `settled_at` date DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_daren` (`daren_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='达人带货业绩';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_records`
--

LOCK TABLES `sales_records` WRITE;
/*!40000 ALTER TABLE `sales_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `sales_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `samples`
--

DROP TABLE IF EXISTS `samples`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `samples` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `daren_id` int(10) unsigned NOT NULL,
  `status` enum('申请','寄出','签收','退回','结算','拒绝','已回收') COLLATE utf8mb4_unicode_ci DEFAULT '申请' COMMENT '寄样状态(含回收)',
  `sample_fee` decimal(12,2) DEFAULT '0.00' COMMENT '样品费',
  `deposit` decimal(12,2) DEFAULT '0.00' COMMENT '押金',
  `express_no` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '快递单号',
  `apply_date` date DEFAULT NULL COMMENT '申请日期',
  `send_date` date DEFAULT NULL COMMENT '寄出日期',
  `sign_date` date DEFAULT NULL COMMENT '签收日期',
  `return_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '退回原因',
  `settle_amount` decimal(12,2) DEFAULT '0.00' COMMENT '结算金额',
  `settle_date` date DEFAULT NULL COMMENT '结算日期',
  `recycle_date` date DEFAULT NULL COMMENT '回收日期',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_pd` (`product_id`,`daren_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='寄样全流程';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `samples`
--

LOCK TABLES `samples` WRITE;
/*!40000 ALTER TABLE `samples` DISABLE KEYS */;
/*!40000 ALTER TABLE `samples` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `score_account_dims`
--

DROP TABLE IF EXISTS `score_account_dims`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `score_account_dims` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL COMMENT '账号',
  `dim_id` int(10) unsigned NOT NULL COMMENT '维度',
  `enabled` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1启用 0停用',
  `sort` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_dim` (`user_id`,`dim_id`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='账号-维度启用配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `score_account_dims`
--

LOCK TABLES `score_account_dims` WRITE;
/*!40000 ALTER TABLE `score_account_dims` DISABLE KEYS */;
INSERT INTO `score_account_dims` VALUES (1,1,1,1,10),(2,1,2,1,20),(3,1,3,1,21),(4,1,4,1,22),(5,1,5,1,30),(6,1,6,1,31),(7,1,7,1,32),(8,1,8,1,33),(9,1,9,1,40),(10,1,10,1,41),(11,1,11,1,42),(12,1,12,1,50),(13,1,13,1,51),(14,1,14,1,52),(15,1,15,1,60),(16,1,16,1,70),(34,2,1,1,10),(35,2,2,1,20),(36,2,3,1,21),(37,2,4,1,22),(38,2,5,1,30),(39,2,6,1,31),(40,2,7,1,32),(41,2,8,1,33),(42,2,9,1,40),(43,2,10,1,41),(44,2,11,1,42),(45,2,12,1,50),(46,2,13,1,51),(47,2,14,1,52),(48,2,15,1,60),(49,2,16,1,70);
/*!40000 ALTER TABLE `score_account_dims` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `score_dimensions`
--

DROP TABLE IF EXISTS `score_dimensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `score_dimensions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '如 margin / custom_12',
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '维度名称',
  `group_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '分组：价格利差/品牌故事/...',
  `max_score` tinyint(4) NOT NULL COMMENT '满分(权重)，1-20',
  `is_builtin` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=内置 0=自定义',
  `status` enum('active','disabled','pending') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active' COMMENT 'pending=待审核',
  `created_by` int(10) unsigned DEFAULT NULL COMMENT '申请人(自定义维度)',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='评分维度池(全局)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `score_dimensions`
--

LOCK TABLES `score_dimensions` WRITE;
/*!40000 ALTER TABLE `score_dimensions` DISABLE KEYS */;
INSERT INTO `score_dimensions` VALUES (1,'margin','毛利率','价格利差',15,1,'active',NULL,10,'2026-08-20 15:54:27','2026-08-20 15:54:27'),(2,'story','品牌故事','品牌故事与差异化',7,1,'active',NULL,20,'2026-08-20 15:54:27','2026-08-20 15:54:27'),(3,'usp','独特卖点','品牌故事与差异化',7,1,'active',NULL,21,'2026-08-20 15:54:27','2026-08-20 15:54:27'),(4,'content','内容可拍性','品牌故事与差异化',6,1,'active',NULL,22,'2026-08-20 15:54:27','2026-08-20 15:54:27'),(5,'search','搜索热度','市场需求与竞争度',5,1,'active',NULL,30,'2026-08-20 15:54:27','2026-08-20 15:54:27'),(6,'trend','需求趋势','市场需求与竞争度',5,1,'active',NULL,31,'2026-08-20 15:54:27','2026-08-20 15:54:27'),(7,'competition','竞争激烈度(反向)','市场需求与竞争度',5,1,'active',NULL,32,'2026-08-20 15:54:27','2026-08-20 15:54:27'),(8,'potential','市场潜力','市场需求与竞争度',5,1,'active',NULL,33,'2026-08-20 15:54:27','2026-08-20 15:54:27'),(9,'supply','供货能力','供应链稳定性',5,1,'active',NULL,40,'2026-08-20 15:54:27','2026-08-20 15:54:27'),(10,'inventory','库存保障','供应链稳定性',5,1,'active',NULL,41,'2026-08-20 15:54:27','2026-08-20 15:54:27'),(11,'logistics','物流时效','供应链稳定性',5,1,'active',NULL,42,'2026-08-20 15:54:27','2026-08-20 15:54:27'),(12,'cert','资质认证','合规与资质风险',5,1,'active',NULL,50,'2026-08-20 15:54:27','2026-08-20 15:54:27'),(13,'ip','知识产权','合规与资质风险',5,1,'active',NULL,51,'2026-08-20 15:54:27','2026-08-20 15:54:27'),(14,'legal','法律合规','合规与资质风险',5,1,'active',NULL,52,'2026-08-20 15:54:27','2026-08-20 15:54:27'),(15,'repeat','复购率','复购率与生命周期',10,1,'active',NULL,60,'2026-08-20 15:54:27','2026-08-20 15:54:27'),(16,'season','季节性','季节性/趋势性',5,1,'active',NULL,70,'2026-08-20 15:54:27','2026-08-20 15:54:27');
/*!40000 ALTER TABLE `score_dimensions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `score_histories`
--

DROP TABLE IF EXISTS `score_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `score_histories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `score_id` int(10) unsigned NOT NULL COMMENT '关联主表id',
  `user_id` int(10) unsigned DEFAULT NULL COMMENT '操作人',
  `action` enum('create','update','delete') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'update',
  `before_data` text COLLATE utf8mb4_unicode_ci COMMENT '变更前(JSON)',
  `after_data` text COLLATE utf8mb4_unicode_ci COMMENT '变更后(JSON)',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_score` (`score_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='评分修改历史';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `score_histories`
--

LOCK TABLES `score_histories` WRITE;
/*!40000 ALTER TABLE `score_histories` DISABLE KEYS */;
INSERT INTO `score_histories` VALUES (1,1,1,'update','[]','{\"subject_type\":\"product\",\"subject_id\":2,\"user_id\":1,\"total_score\":100,\"max_score\":100,\"score_rate\":100,\"verdict\":\"优先选品\",\"veto_flag\":0}','2026-08-20 15:58:07'),(2,1,1,'delete','{\"id\":1,\"subject_type\":\"product\",\"subject_id\":2,\"user_id\":1,\"total_score\":100,\"max_score\":100,\"score_rate\":\"100.00\",\"verdict\":\"优先选品\",\"veto_flag\":0,\"remark\":\"线上冒烟测试（可删）\",\"created_at\":\"2026-08-20T07:58:07.000Z\",\"updated_at\":\"2026-08-20T07:58:07.000Z\"}',NULL,'2026-08-20 15:58:23'),(3,2,1,'update','[]','{\"subject_type\":\"product\",\"subject_id\":24,\"user_id\":1,\"total_score\":7,\"max_score\":100,\"score_rate\":7,\"verdict\":\"不建议\",\"veto_flag\":1}','2026-08-21 12:00:15'),(4,2,1,'update','[{\"id\":2,\"subject_type\":\"product\",\"subject_id\":24,\"user_id\":1,\"total_score\":7,\"max_score\":100,\"score_rate\":\"7.00\",\"verdict\":\"不建议\",\"veto_flag\":1,\"remark\":null,\"created_at\":\"2026-08-21T04:00:15.000Z\",\"updated_at\":\"2026-08-21T04:00:15.000Z\"}]','{\"subject_type\":\"product\",\"subject_id\":24,\"user_id\":1,\"total_score\":89,\"max_score\":100,\"score_rate\":89,\"verdict\":\"优先选品\",\"veto_flag\":0}','2026-08-21 15:41:21'),(5,3,2,'update','[]','{\"subject_type\":\"brand\",\"subject_id\":5,\"user_id\":2,\"total_score\":79,\"max_score\":100,\"score_rate\":79,\"verdict\":\"可考虑\",\"veto_flag\":0}','2026-08-21 16:10:34'),(6,4,2,'update','[]','{\"subject_type\":\"product\",\"subject_id\":27,\"user_id\":2,\"total_score\":85,\"max_score\":100,\"score_rate\":85,\"verdict\":\"优先选品\",\"veto_flag\":0}','2026-08-21 16:27:08'),(7,5,2,'update','[]','{\"subject_type\":\"product\",\"subject_id\":26,\"user_id\":2,\"total_score\":81,\"max_score\":100,\"score_rate\":81,\"verdict\":\"优先选品\",\"veto_flag\":0}','2026-08-21 16:42:39');
/*!40000 ALTER TABLE `score_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `selection_score_items`
--

DROP TABLE IF EXISTS `selection_score_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `selection_score_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `score_id` int(10) unsigned NOT NULL COMMENT '关联主表id',
  `dim_id` int(10) unsigned NOT NULL COMMENT '维度',
  `score` tinyint(4) NOT NULL COMMENT '该账号该维度得分',
  `max_score` tinyint(4) NOT NULL COMMENT '维度满分快照(保存时)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_score_dim` (`score_id`,`dim_id`),
  KEY `idx_score` (`score_id`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='评分明细(账号×维度×分值)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `selection_score_items`
--

LOCK TABLES `selection_score_items` WRITE;
/*!40000 ALTER TABLE `selection_score_items` DISABLE KEYS */;
INSERT INTO `selection_score_items` VALUES (33,2,1,15,15),(34,2,2,5,7),(35,2,3,5,7),(36,2,4,6,6),(37,2,5,4,5),(38,2,6,4,5),(39,2,7,3,5),(40,2,8,4,5),(41,2,9,4,5),(42,2,10,5,5),(43,2,11,4,5),(44,2,12,5,5),(45,2,13,5,5),(46,2,14,5,5),(47,2,15,10,10),(48,2,16,5,5),(49,3,1,8,15),(50,3,2,7,7),(51,3,3,5,7),(52,3,4,4,6),(53,3,5,4,5),(54,3,6,4,5),(55,3,7,3,5),(56,3,8,4,5),(57,3,9,4,5),(58,3,10,4,5),(59,3,11,4,5),(60,3,12,5,5),(61,3,13,5,5),(62,3,14,5,5),(63,3,15,10,10),(64,3,16,3,5),(65,4,1,12,15),(66,4,2,7,7),(67,4,3,7,7),(68,4,4,4,6),(69,4,5,4,5),(70,4,6,4,5),(71,4,7,3,5),(72,4,8,4,5),(73,4,9,4,5),(74,4,10,4,5),(75,4,11,4,5),(76,4,12,5,5),(77,4,13,5,5),(78,4,14,5,5),(79,4,15,10,10),(80,4,16,3,5),(81,5,1,8,15),(82,5,2,7,7),(83,5,3,7,7),(84,5,4,4,6),(85,5,5,4,5),(86,5,6,4,5),(87,5,7,3,5),(88,5,8,4,5),(89,5,9,4,5),(90,5,10,4,5),(91,5,11,4,5),(92,5,12,5,5),(93,5,13,5,5),(94,5,14,5,5),(95,5,15,10,10),(96,5,16,3,5);
/*!40000 ALTER TABLE `selection_score_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `selection_scores`
--

DROP TABLE IF EXISTS `selection_scores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `selection_scores` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subject_type` enum('product','brand') COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '评分对象类型',
  `subject_id` int(10) unsigned NOT NULL COMMENT '商品/品牌ID',
  `user_id` int(10) unsigned NOT NULL COMMENT '评分账号(原created_by升级)',
  `total_score` int(11) NOT NULL DEFAULT '0' COMMENT '账号原始总分(Σ维度分)',
  `max_score` int(11) NOT NULL DEFAULT '0' COMMENT '账号满分快照(Σ启用维度满分)',
  `score_rate` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT '归一化得分率 total/max*100',
  `verdict` enum('优先选品','可考虑','观望','不建议') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '观望',
  `veto_flag` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1=触发一票否决',
  `remark` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_subject_user` (`subject_type`,`subject_id`,`user_id`),
  KEY `idx_subject` (`subject_type`,`subject_id`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='选品评分主表(账号×对象)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `selection_scores`
--

LOCK TABLES `selection_scores` WRITE;
/*!40000 ALTER TABLE `selection_scores` DISABLE KEYS */;
INSERT INTO `selection_scores` VALUES (2,'product',24,1,89,100,89.00,'优先选品',0,NULL,'2026-08-21 12:00:15','2026-08-21 15:41:21'),(3,'brand',5,2,79,100,79.00,'可考虑',0,NULL,'2026-08-21 16:10:34','2026-08-21 16:10:34'),(4,'product',27,2,85,100,85.00,'优先选品',0,NULL,'2026-08-21 16:27:08','2026-08-21 16:27:08'),(5,'product',26,2,81,100,81.00,'优先选品',0,NULL,'2026-08-21 16:42:39','2026-08-21 16:42:39');
/*!40000 ALTER TABLE `selection_scores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `selection_scores_bak_v1`
--

DROP TABLE IF EXISTS `selection_scores_bak_v1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `selection_scores_bak_v1` (
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  `subject_type` enum('product','brand') COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '评分对象类型',
  `subject_id` int(10) unsigned NOT NULL COMMENT '商品/品牌 ID',
  `score_margin` tinyint(4) NOT NULL DEFAULT '0' COMMENT '毛利率 0-15',
  `score_story` tinyint(4) NOT NULL DEFAULT '0' COMMENT '品牌故事 0-7',
  `score_usp` tinyint(4) NOT NULL DEFAULT '0' COMMENT '独特卖点 0-7',
  `score_content` tinyint(4) NOT NULL DEFAULT '0' COMMENT '内容可拍性 0-6',
  `score_search` tinyint(4) NOT NULL DEFAULT '0' COMMENT '搜索热度 0-5',
  `score_trend` tinyint(4) NOT NULL DEFAULT '0' COMMENT '需求趋势 0-5',
  `score_competition` tinyint(4) NOT NULL DEFAULT '0' COMMENT '竞争激烈度 0-5',
  `score_potential` tinyint(4) NOT NULL DEFAULT '0' COMMENT '市场潜力 0-5',
  `score_supply` tinyint(4) NOT NULL DEFAULT '0' COMMENT '供货能力 0-5',
  `score_inventory` tinyint(4) NOT NULL DEFAULT '0' COMMENT '库存保障 0-5',
  `score_logistics` tinyint(4) NOT NULL DEFAULT '0' COMMENT '物流时效 0-5',
  `score_cert` tinyint(4) NOT NULL DEFAULT '0' COMMENT '资质认证 0-5',
  `score_ip` tinyint(4) NOT NULL DEFAULT '0' COMMENT '知识产权 0-5',
  `score_legal` tinyint(4) NOT NULL DEFAULT '0' COMMENT '法律合规 0-5',
  `score_repeat` tinyint(4) NOT NULL DEFAULT '0' COMMENT '复购率 0-10',
  `score_season` tinyint(4) NOT NULL DEFAULT '0' COMMENT '季节性 0-5',
  `total_score` int(11) NOT NULL DEFAULT '0' COMMENT '总分 0-100',
  `verdict` enum('优先选品','可考虑','观望','不建议') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '观望' COMMENT '结论',
  `veto_flag` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1=一票否决',
  `remark` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '评分备注',
  `created_by` int(10) unsigned DEFAULT NULL COMMENT '评分人 user_id',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `selection_scores_bak_v1`
--

LOCK TABLES `selection_scores_bak_v1` WRITE;
/*!40000 ALTER TABLE `selection_scores_bak_v1` DISABLE KEYS */;
/*!40000 ALTER TABLE `selection_scores_bak_v1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settlements`
--

DROP TABLE IF EXISTS `settlements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settlements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `period` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '结算周期',
  `daren_id` int(10) unsigned NOT NULL COMMENT '达人ID',
  `product_id` int(10) unsigned NOT NULL COMMENT '商品ID',
  `gmv` decimal(14,2) DEFAULT '0.00' COMMENT 'GMV',
  `actual_amount` decimal(14,2) DEFAULT '0.00' COMMENT '实收金额',
  `rate` decimal(5,2) DEFAULT '0.00' COMMENT '佣金率(%)',
  `commission_amount` decimal(14,2) DEFAULT '0.00' COMMENT '佣金金额',
  `settle_status` enum('待核对','已确认','有差异') COLLATE utf8mb4_unicode_ci DEFAULT '待核对' COMMENT '结算状态',
  `pay_status` enum('未打款','已打款') COLLATE utf8mb4_unicode_ci DEFAULT '未打款' COMMENT '打款状态',
  `settle_date` date DEFAULT NULL COMMENT '结算日期',
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_daren` (`daren_id`),
  KEY `idx_product` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='结算单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settlements`
--

LOCK TABLES `settlements` WRITE;
/*!40000 ALTER TABLE `settlements` DISABLE KEYS */;
/*!40000 ALTER TABLE `settlements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '登录账号',
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'bcrypt 密码哈希',
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '姓名',
  `role` enum('admin','selection','daren_op','finance','logistics','viewer') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'viewer' COMMENT '角色：管理员/选品/达人运营/财务/物流售后/只读',
  `dept` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '部门',
  `permissions` text COLLATE utf8mb4_unicode_ci COMMENT '自定义模块权限(JSON数组)，NULL=跟随角色',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1启用 0禁用',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户账号与角色';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','$2a$10$xG4nDiPCyK7Q88S51rS8XuHhwGrmAE4rFSqwe9CVZt9jcHOGYe60m','系统管理员','admin',NULL,NULL,1,'2026-08-17 15:40:34','2026-08-20 16:38:36'),(2,'孙萌娟','$2a$10$7o0vJCdlQmaA89GZnh8RTO5zplc581GpefBQjpZH4SFLEXV7IAX7G','孙萌娟','admin','供应链中心','[\"dashboard\",\"brands\",\"darens\",\"products\",\"coop\",\"samples\",\"scores\",\"commission\",\"excel\"]',1,'2026-08-20 16:53:17','2026-08-21 16:00:53'),(3,'康佳慧','$2a$10$vBMds5aH0OEtDwh8LhSdEev74rYFE20kzrQIqANYJ3RSZf.6vkLum','康佳慧','selection',NULL,'[\"scores\",\"samples\",\"brands\",\"dashboard\",\"products\",\"coop\",\"commission\",\"excel\"]',1,'2026-08-20 17:00:21','2026-08-20 17:00:21'),(4,'庄逸','$2a$10$qrfahS4mvekjyg0Eu7/KfObHIOhETAfr30VZmVDD4D/3moz/AGkda','庄逸','daren_op','国内事业部','[\"excel\",\"commission\",\"coop\",\"darens\",\"samples\",\"products\",\"brands\",\"dashboard\",\"scores\"]',1,'2026-08-20 17:13:20','2026-08-20 17:13:20');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-24  3:00:01

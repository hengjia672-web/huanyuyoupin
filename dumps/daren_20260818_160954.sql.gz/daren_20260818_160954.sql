-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: daren_selection
-- ------------------------------------------------------
-- Server version	5.7.44-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL COMMENT '操作人ID',
  `user_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '操作人姓名',
  `ip` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '来源IP',
  `method` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'HTTP方法',
  `path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '请求路径',
  `target_table` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '目标表',
  `target_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '目标记录ID',
  `action_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '操作类型',
  `before_data` text COLLATE utf8mb4_unicode_ci COMMENT '变更前(JSON)',
  `after_data` text COLLATE utf8mb4_unicode_ci COMMENT '变更后(JSON)',
  `detail` text COLLATE utf8mb4_unicode_ci COMMENT '操作摘要',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_table` (`target_table`),
  KEY `idx_action` (`action_type`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='操作审计日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-17 15:40:34'),(2,1,'系统管理员','::ffff:127.0.0.1','POST','/api/brands','brands','1','create',NULL,'{\"name\":\"API测试品牌\",\"country\":\"日本\",\"category\":\"美妆\",\"coop_stage\":\"洽谈中\",\"grade\":\"A\"}','POST /api/brands [name,country,category,coop_stage,grade]','2026-08-17 15:40:34'),(3,1,'系统管理员','::ffff:127.0.0.1','POST','/api/products','products','1','create',NULL,'{\"name\":\"API测试商品\",\"sku\":\"API-01\",\"supply_price\":45,\"sale_price\":129,\"stock\":100,\"shelf_status\":\"已上架\"}','POST /api/products [name,sku,supply_price,sale_price,stock,shelf_status]','2026-08-17 15:40:34'),(4,1,'admin','61.186.18.64','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-17 15:40:41'),(5,1,'admin','61.186.18.64','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-17 15:45:20'),(6,1,'admin','61.186.18.64','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-17 15:47:14'),(7,1,'admin','61.186.18.64','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-17 15:49:53'),(8,1,'admin','61.186.27.5','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-17 15:50:02'),(9,1,'admin','61.186.18.64','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-17 15:53:01'),(10,1,'系统管理员','61.186.18.64','POST','/api/brands','brands','2','create',NULL,'{\"name\":\"伊菲丹\",\"logo_url\":\"\",\"country\":\"法国\",\"category\":\"\",\"company\":\"\",\"contact\":\"\",\"contact_info\":\"\",\"coop_stage\":\"挖掘中\",\"grade\":\"C\",\"contract_no\":\"\",\"contract_expiry\":null,\"auth_expiry\":null,\"payment_terms\":\"\",\"remark\":\"\"}','POST /api/brands [name,logo_url,country,category,company,contact,contact_info,coop_stage,grade,contract_no,contract_expiry,auth_expiry,payment_terms,remark]','2026-08-17 15:53:17'),(11,1,'系统管理员','61.186.18.64','DELETE','/api/brands/2','brands',NULL,'delete',NULL,'{}','DELETE /api/brands/2','2026-08-17 15:54:47'),(12,1,'系统管理员','61.186.27.5','POST','/api/brands','brands','3','create',NULL,'{\"name\":\"千颂\",\"logo_url\":\"\",\"country\":\"日本\",\"category\":\"酒\",\"company\":\"\",\"contact\":\"\",\"contact_info\":\"\",\"coop_stage\":\"挖掘中\",\"grade\":\"C\",\"contract_no\":\"\",\"contract_expiry\":null,\"auth_expiry\":null,\"payment_terms\":\"\",\"remark\":\"\"}','POST /api/brands [name,logo_url,country,category,company,contact,contact_info,coop_stage,grade,contract_no,contract_expiry,auth_expiry,payment_terms,remark]','2026-08-17 15:56:18'),(13,1,'系统管理员','61.186.27.5','POST','/api/products','products','2','create',NULL,'{\"name\":\"千颂威士忌\",\"sku\":\"\",\"brand_id\":3,\"category\":\"\",\"main_image\":\"\",\"sub_image1\":\"\",\"sub_image2\":\"\",\"supply_price\":0,\"sale_price\":0,\"stock\":0,\"stock_warn\":0,\"shelf_status\":\"待上架\",\"sales\":0,\"remark\":\"\"}','POST /api/products [name,sku,brand_id,category,main_image,sub_image1,sub_image2,supply_price,sale_price,stock,stock_warn,shelf_status,sales,remark]','2026-08-17 15:56:31'),(14,1,'admin','61.186.18.64','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-17 16:19:48'),(15,1,'admin','61.186.18.64','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-17 16:22:16'),(16,1,'admin','61.186.27.5','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-17 16:53:02'),(17,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-18 15:50:02'),(18,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-18 15:52:19'),(19,1,'admin','::1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-18 15:53:26'),(20,1,'admin','127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-18 15:53:26'),(21,1,'admin','61.186.24.240','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-18 15:55:00'),(22,1,'admin','::ffff:127.0.0.1','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-18 15:56:49'),(23,1,'admin','61.186.24.240','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-18 15:57:04'),(24,1,'admin','61.186.24.240','POST','/api/auth/login',NULL,NULL,'login',NULL,NULL,'登录成功','2026-08-18 15:57:04');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `brands`
--

DROP TABLE IF EXISTS `brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `brands` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '品牌名称',
  `logo_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Logo 图片 URL（COS）',
  `country` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '国家/地区',
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '主营品类',
  `company` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '品牌方主体',
  `contact` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '对接人',
  `contact_info` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '联系方式',
  `coop_stage` enum('挖掘中','洽谈中','已签约','合作中','已终止') COLLATE utf8mb4_unicode_ci DEFAULT '挖掘中' COMMENT '合作进度',
  `grade` enum('S','A','B','C') COLLATE utf8mb4_unicode_ci DEFAULT 'C' COMMENT '品牌分级',
  `contract_no` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '合同编号',
  `contract_expiry` date DEFAULT NULL COMMENT '合同到期日（到期提醒）',
  `auth_expiry` date DEFAULT NULL COMMENT '授权到期日',
  `payment_terms` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '账期',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `owner_id` int(10) unsigned DEFAULT NULL COMMENT '负责的选品专员user_id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='品牌档案';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brands`
--

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
INSERT INTO `brands` VALUES (3,'千颂','','日本','酒','','','','挖掘中','C','',NULL,NULL,'','','2026-08-17 15:56:18','2026-08-17 15:56:18',NULL);
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commission_configs`
--

DROP TABLE IF EXISTS `commission_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commission_configs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `daren_id` int(10) unsigned NOT NULL COMMENT '达人ID',
  `product_id` int(10) unsigned NOT NULL COMMENT '商品ID',
  `rate` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT '佣金率(%)',
  `effective_date` date DEFAULT NULL COMMENT '生效日期',
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_dp` (`daren_id`,`product_id`),
  KEY `idx_daren` (`daren_id`),
  KEY `idx_product` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='佣金方案配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commission_configs`
--

LOCK TABLES `commission_configs` WRITE;
/*!40000 ALTER TABLE `commission_configs` DISABLE KEYS */;
/*!40000 ALTER TABLE `commission_configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coop_logs`
--

DROP TABLE IF EXISTS `coop_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coop_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `daren_id` int(10) unsigned NOT NULL,
  `from_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '旧状态',
  `to_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '新状态',
  `operator_id` int(10) unsigned DEFAULT NULL COMMENT '操作人',
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_pd` (`product_id`,`daren_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='合作状态变更历史';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coop_logs`
--

LOCK TABLES `coop_logs` WRITE;
/*!40000 ALTER TABLE `coop_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `coop_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `darens`
--

DROP TABLE IF EXISTS `darens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `darens` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '达人名称',
  `douyin_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '抖音号',
  `fans` int(11) DEFAULT '0' COMMENT '粉丝量',
  `coop_status` enum('建联中','寄样中','已合作','已终止') COLLATE utf8mb4_unicode_ci DEFAULT '建联中' COMMENT '合作状态',
  `contact` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '联系方式',
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '带货品类',
  `gmv` decimal(14,2) DEFAULT '0.00' COMMENT '累计GMV',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='达人矩阵';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `darens`
--

LOCK TABLES `darens` WRITE;
/*!40000 ALTER TABLE `darens` DISABLE KEYS */;
/*!40000 ALTER TABLE `darens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `type` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT 'info' COMMENT 'info/contract/stock/sample',
  `content` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_read` tinyint(4) DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='站内通知';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_daren`
--

DROP TABLE IF EXISTS `product_daren`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_daren` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `daren_id` int(10) unsigned NOT NULL,
  `status` enum('对接中','带货中','不合适','已终止') COLLATE utf8mb4_unicode_ci DEFAULT '对接中' COMMENT '当前合作状态',
  `updated_by` int(10) unsigned DEFAULT NULL COMMENT '最后操作人',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_pd` (`product_id`,`daren_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='商品-达人合作（多对多）';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_daren`
--

LOCK TABLES `product_daren` WRITE;
/*!40000 ALTER TABLE `product_daren` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_daren` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '商品名称',
  `sku` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SKU',
  `brand_id` int(10) unsigned DEFAULT NULL COMMENT '所属品牌',
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '品类',
  `main_image` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '主图 URL',
  `sub_image1` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '副图1 URL',
  `sub_image2` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '副图2 URL',
  `supply_price` decimal(12,2) DEFAULT '0.00' COMMENT '供货价',
  `sale_price` decimal(12,2) DEFAULT '0.00' COMMENT '售价',
  `stock` int(11) DEFAULT '0' COMMENT '库存数量',
  `stock_warn` int(11) DEFAULT '0' COMMENT '库存预警线',
  `shelf_status` enum('待上架','已上架','已下架') COLLATE utf8mb4_unicode_ci DEFAULT '待上架' COMMENT '上架状态',
  `sales` int(11) DEFAULT '0' COMMENT '累计销量',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_brand` (`brand_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='商品档案';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (2,'千颂威士忌','',3,'','','','',0.00,0.00,0,0,'待上架',0,'','2026-08-17 15:56:31','2026-08-17 15:56:31');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_records`
--

DROP TABLE IF EXISTS `sales_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales_records` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `daren_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  `period` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '结算周期',
  `gmv` decimal(14,2) DEFAULT '0.00',
  `orders` int(11) DEFAULT '0' COMMENT '订单数',
  `commission` decimal(14,2) DEFAULT '0.00' COMMENT '佣金',
  `settled_at` date DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_daren` (`daren_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='达人带货业绩';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_records`
--

LOCK TABLES `sales_records` WRITE;
/*!40000 ALTER TABLE `sales_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `sales_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `samples`
--

DROP TABLE IF EXISTS `samples`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `samples` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `daren_id` int(10) unsigned NOT NULL,
  `status` enum('申请','寄出','签收','退回','结算','拒绝') COLLATE utf8mb4_unicode_ci DEFAULT '申请' COMMENT '寄样状态',
  `sample_fee` decimal(12,2) DEFAULT '0.00' COMMENT '样品费',
  `deposit` decimal(12,2) DEFAULT '0.00' COMMENT '押金',
  `express_no` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '快递单号',
  `apply_date` date DEFAULT NULL COMMENT '申请日期',
  `send_date` date DEFAULT NULL COMMENT '寄出日期',
  `sign_date` date DEFAULT NULL COMMENT '签收日期',
  `return_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '退回原因',
  `settle_amount` decimal(12,2) DEFAULT '0.00' COMMENT '结算金额',
  `settle_date` date DEFAULT NULL COMMENT '结算日期',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_pd` (`product_id`,`daren_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='寄样全流程';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `samples`
--

LOCK TABLES `samples` WRITE;
/*!40000 ALTER TABLE `samples` DISABLE KEYS */;
/*!40000 ALTER TABLE `samples` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `selection_scores`
--

DROP TABLE IF EXISTS `selection_scores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `selection_scores` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subject_type` enum('product','brand') COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '评分对象类型',
  `subject_id` int(10) unsigned NOT NULL COMMENT '商品/品牌 ID',
  `score_margin` tinyint(4) NOT NULL DEFAULT '0' COMMENT '毛利率 0-15',
  `score_story` tinyint(4) NOT NULL DEFAULT '0' COMMENT '品牌故事 0-7',
  `score_usp` tinyint(4) NOT NULL DEFAULT '0' COMMENT '独特卖点 0-7',
  `score_content` tinyint(4) NOT NULL DEFAULT '0' COMMENT '内容可拍性 0-6',
  `score_search` tinyint(4) NOT NULL DEFAULT '0' COMMENT '搜索热度 0-5',
  `score_trend` tinyint(4) NOT NULL DEFAULT '0' COMMENT '需求趋势 0-5',
  `score_competition` tinyint(4) NOT NULL DEFAULT '0' COMMENT '竞争激烈度 0-5',
  `score_potential` tinyint(4) NOT NULL DEFAULT '0' COMMENT '市场潜力 0-5',
  `score_supply` tinyint(4) NOT NULL DEFAULT '0' COMMENT '供货能力 0-5',
  `score_inventory` tinyint(4) NOT NULL DEFAULT '0' COMMENT '库存保障 0-5',
  `score_logistics` tinyint(4) NOT NULL DEFAULT '0' COMMENT '物流时效 0-5',
  `score_cert` tinyint(4) NOT NULL DEFAULT '0' COMMENT '资质认证 0-5',
  `score_ip` tinyint(4) NOT NULL DEFAULT '0' COMMENT '知识产权 0-5',
  `score_legal` tinyint(4) NOT NULL DEFAULT '0' COMMENT '法律合规 0-5',
  `score_repeat` tinyint(4) NOT NULL DEFAULT '0' COMMENT '复购率 0-10',
  `score_season` tinyint(4) NOT NULL DEFAULT '0' COMMENT '季节性 0-5',
  `total_score` int(11) NOT NULL DEFAULT '0' COMMENT '总分 0-100',
  `verdict` enum('优先选品','可考虑','观望','不建议') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '观望' COMMENT '结论',
  `veto_flag` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1=一票否决',
  `remark` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '评分备注',
  `created_by` int(10) unsigned DEFAULT NULL COMMENT '评分人 user_id',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_subject` (`subject_type`,`subject_id`),
  KEY `idx_verdict` (`verdict`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='选品评分卡';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `selection_scores`
--

LOCK TABLES `selection_scores` WRITE;
/*!40000 ALTER TABLE `selection_scores` DISABLE KEYS */;
/*!40000 ALTER TABLE `selection_scores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settlements`
--

DROP TABLE IF EXISTS `settlements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settlements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `period` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '结算周期',
  `daren_id` int(10) unsigned NOT NULL COMMENT '达人ID',
  `product_id` int(10) unsigned NOT NULL COMMENT '商品ID',
  `gmv` decimal(14,2) DEFAULT '0.00' COMMENT 'GMV',
  `actual_amount` decimal(14,2) DEFAULT '0.00' COMMENT '实收金额',
  `rate` decimal(5,2) DEFAULT '0.00' COMMENT '佣金率(%)',
  `commission_amount` decimal(14,2) DEFAULT '0.00' COMMENT '佣金金额',
  `settle_status` enum('待核对','已确认','有差异') COLLATE utf8mb4_unicode_ci DEFAULT '待核对' COMMENT '结算状态',
  `pay_status` enum('未打款','已打款') COLLATE utf8mb4_unicode_ci DEFAULT '未打款' COMMENT '打款状态',
  `settle_date` date DEFAULT NULL COMMENT '结算日期',
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_daren` (`daren_id`),
  KEY `idx_product` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='结算单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settlements`
--

LOCK TABLES `settlements` WRITE;
/*!40000 ALTER TABLE `settlements` DISABLE KEYS */;
/*!40000 ALTER TABLE `settlements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '登录账号',
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'bcrypt 密码哈希',
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '姓名',
  `role` enum('admin','selection','daren_op','finance','logistics','viewer') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'viewer' COMMENT '角色：管理员/选品/达人运营/财务/物流售后/只读',
  `dept` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '部门',
  `permissions` text COLLATE utf8mb4_unicode_ci COMMENT '自定义模块权限(JSON数组)，NULL=跟随角色',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1启用 0禁用',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户账号与角色';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','$2a$10$eiGZoOrNJ9MsyDfZA0MvreHl3kgRloI2bHu/.e2l.3A80m8jUB/Em','系统管理员','admin',NULL,NULL,1,'2026-08-17 15:40:34','2026-08-17 15:40:34');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-18 16:09:54

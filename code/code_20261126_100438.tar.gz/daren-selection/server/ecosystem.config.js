module.exports = {
  apps: [{
    name: 'daren-selection',
    script: 'src/index.js',
    cwd: '/www/wwwroot/daren-selection/server',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '512M',
    env: {
      NODE_ENV: 'production'
    },
    out_file: '/www/wwwroot/daren-selection/logs/pm2-out.log',
    error_file: '/www/wwwroot/daren-selection/logs/pm2-err.log',
    log_file: '/www/wwwroot/daren-selection/logs/pm2-combined.log',
    time: true
  }]
}

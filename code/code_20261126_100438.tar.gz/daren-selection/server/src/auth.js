'use strict';
// JWT 鉴权 + RBAC 权限中间件
const jwt = require('jsonwebtoken');

const SECRET = process.env.JWT_SECRET || 'dev_secret_change_me';

// 签发 token
function signToken(user) {
  return jwt.sign(
    { id: user.id, username: user.username, name: user.name, role: user.role },
    SECRET,
    { expiresIn: process.env.JWT_EXPIRES || '7d' }
  );
}

// 必须登录
function authRequired(req, res, next) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  if (!token) return res.status(401).json({ code: 401, msg: '未登录' });
  try {
    req.user = jwt.verify(token, SECRET);
    next();
  } catch (e) {
    return res.status(401).json({ code: 401, msg: '登录已过期，请重新登录' });
  }
}

// 角色权限：requireRole('admin') 或 requireRole(['admin','selection'])
function requireRole(roles) {
  const allow = Array.isArray(roles) ? roles : [roles];
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ code: 401, msg: '未登录' });
    if (allow.indexOf(req.user.role) < 0) {
      return res.status(403).json({ code: 403, msg: '无权限执行此操作' });
    }
    next();
  };
}

// 可选鉴权：解析 token 到 req.user（不强制登录），供审计等全局中间件使用；
// 无效 token 直接忽略，由各路由级 authRequired 统一拦截。
function optionalAuth(req, res, next) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  if (token) {
    try {
      req.user = jwt.verify(token, SECRET);
    } catch (e) {
      /* 忽略，交给 authRequired */
    }
  }
  next();
}

module.exports = { signToken, authRequired, requireRole, optionalAuth };

'use strict';
// 达人带货选品管理系统 · 后端入口
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');

const { optionalAuth } = require('./auth');
const audit = require('./audit');

const app = express();

// CORS 白名单（CORS_ORIGIN 逗号分隔，默认前端本地地址）
const corsOrigins = (process.env.CORS_ORIGIN || 'http://localhost:5173')
  .split(',')
  .map((s) => s.trim())
  .filter(Boolean);
app.use(cors({
  origin(origin, cb) {
    // 无 Origin（同源请求 / 服务端调用）放行
    if (!origin || corsOrigins.includes(origin)) return cb(null, true);
    return cb(null, false); // 不设置 CORS 头，浏览器端将被拦截
  },
}));

app.use(express.json({ limit: '10mb' }));

// 本地图片降级目录（COS 未配置时使用）
app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));

// 健康检查
app.get('/api/health', (req, res) => res.json({ code: 0, data: 'ok' }));

// 全局可选鉴权：解析 token 到 req.user（不强制登录，强制校验由各路由 authRequired 执行）
app.use(optionalAuth);
// 操作审计：拦截 POST/PUT/DELETE 写审计日志
app.use(audit);

// 路由
app.use('/api/auth', require('./routes/auth'));
app.use('/api/brands', require('./routes/brands'));
app.use('/api/products', require('./routes/products'));
app.use('/api/darens', require('./routes/darens'));
app.use('/api/upload', require('./routes/upload'));
app.use('/api/coop', require('./routes/coop'));
app.use('/api/samples', require('./routes/samples'));
app.use('/api/excel', require('./routes/excel'));
app.use('/api/commission', require('./routes/commission'));
app.use('/api/settlement', require('./routes/settlement'));
app.use('/api/dashboard', require('./routes/dashboard'));
app.use('/api/notifications', require('./routes/notifications'));
app.use('/api/alerts', require('./routes/alerts'));
app.use('/api/scores', require('./routes/scores'));
app.use('/api/users', require('./routes/users').router);
app.use('/api/audit', require('./routes/audit-logs'));

// 统一 404
app.use((req, res) => res.status(404).json({ code: 404, msg: '接口不存在' }));

// 统一错误处理
app.use((err, req, res, next) => {
  console.error('[error]', err.message);
  res.status(500).json({ code: 500, msg: '服务器内部错误' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`[daren-selection] API running on :${PORT}`));

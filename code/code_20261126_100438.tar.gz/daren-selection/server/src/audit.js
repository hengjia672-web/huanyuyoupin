'use strict';
// 操作审计：登录/登出/增删改/导出/权限变更，记录 操作人/时间/IP/类型/前后对比
const { query } = require('./db');

// 获取客户端 IP（优先 x-forwarded-for，取首个）
function clientIp(req) {
  const xf = req.headers['x-forwarded-for'];
  if (xf) return String(xf).split(',')[0].trim();
  return req.ip || (req.socket && req.socket.remoteAddress) || null;
}

// 从路径解析目标表：/api/brands/123 -> brands
function tableFromPath(path) {
  const m = String(path || '').match(/^\/api\/([^/]+)/);
  return m ? m[1] : null;
}

// 可查旧值的业务表白名单（防止路径注入）
const TABLE_WHITELIST = ['brands', 'products', 'darens', 'product_daren', 'samples',
  'commission_configs', 'settlements', 'users', 'selection_scores', 'notifications', 'sales_records', 'coop_logs'];

// 通用写审计（供路由显式调用：登录/登出/导出/权限变更等）
async function writeAudit({ userId, userName, ip, method, path, table, targetId, action, before, after, detail }) {
  try {
    await query(
      `INSERT INTO audit_logs
        (user_id, user_name, ip, method, path, target_table, target_id, action_type, before_data, after_data, detail)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        userId || null, userName || null, ip || null, method || null, path || null,
        table || null, targetId != null ? String(targetId) : null, action || null,
        before != null ? JSON.stringify(before) : null,
        after != null ? JSON.stringify(after) : null,
        detail || null,
      ]
    );
  } catch (e) {
    console.error('[audit]', e.message);
  }
}

// 中间件：拦截 POST/PUT/DELETE，记录操作并尽量采集变更前后对比
module.exports = function audit(req, res, next) {
  if (['POST', 'PUT', 'DELETE'].indexOf(req.method) < 0) return next();
  const user = req.user;
  if (!user || !user.id) return next();

  const method = req.method;
  const path = (req.originalUrl || req.url || '').split('?')[0];
  const targetTable = tableFromPath(path);
  const targetId = req.params && req.params.id ? req.params.id : null;
  const ip = clientIp(req);

  // 已由路由显式审计的路径跳过（避免重复记录）
  const SKIP_PATHS = ['/api/auth', '/api/users', '/api/upload'];
  if (SKIP_PATHS.some((p) => path.startsWith(p))) return next();

  const actionMap = { POST: 'create', PUT: 'update', DELETE: 'delete' };
  const action = actionMap[method];

  // 更新/删除前采集旧值（异步，先查再放行）
  let before = null;
  const captureBefore = () =>
    new Promise((resolve) => {
      if (!targetId || !targetTable || TABLE_WHITELIST.indexOf(targetTable) < 0) return resolve();
      query(`SELECT * FROM ${targetTable} WHERE id = ?`, [targetId])
        .then((rows) => {
          if (rows.length) {
            const r = rows[0];
            const clean = {};
            Object.keys(r).forEach((k) => { clean[k] = r[k]; });
            before = clean;
          }
          resolve();
        })
        .catch(() => resolve());
    });

  captureBefore().then(() => {
    // 捕获响应里的 id（新增接口返回 { data: { id } }）与响应体摘要
    const originalJson = res.json.bind(res);
    let respId = targetId;
    let respData = null;
    res.json = function (body) {
      if (body && body.data) {
        if (body.data.id !== undefined && body.data.id !== null && !respId) respId = body.data.id;
        respData = body.data;
      }
      return originalJson(body);
    };

    res.on('finish', () => {
      const body = req.body && typeof req.body === 'object' && !Array.isArray(req.body) ? req.body : null;
      // 避免把密码哈希写进日志
      const safeAfter = body ? { ...body } : respData && typeof respData === 'object' ? { ...respData } : null;
      if (safeAfter && 'password' in safeAfter) delete safeAfter.password;
      if (safeAfter && 'password_hash' in safeAfter) delete safeAfter.password_hash;
      const bodyKeys = body ? Object.keys(body).join(',') : '';
      const detail = bodyKeys ? `${method} ${path} [${bodyKeys}]` : `${method} ${path}`;
      writeAudit({
        userId: user.id, userName: user.name || null, ip, method, path,
        table: targetTable, targetId: respId, action, before, after: safeAfter, detail,
      });
    });
    next();
  });
};

module.exports.clientIp = clientIp;
module.exports.writeAudit = writeAudit;
module.exports.tableFromPath = tableFromPath;

'use strict';
const express = require('express');
const { query } = require('../db');
const { authRequired, requireRole } = require('../auth');

const router = express.Router();
router.use(authRequired);

// 状态机：允许的状态流转（v3 新增「已回收」第 7 态）
const TRANSITIONS = {
  '申请': ['寄出', '拒绝'],
  '寄出': ['签收'],
  '签收': ['结算', '退回', '已回收'],
  '退回': ['寄出', '已回收'],
  '结算': [],
  '拒绝': [],
  '已回收': [],
};

// 创建时可写入字段
const FIELDS = [
  'product_id', 'daren_id', 'sample_fee', 'deposit', 'express_no',
  'apply_date', 'send_date', 'sign_date', 'return_reason',
  'settle_amount', 'settle_date', 'remark',
];

// GET /api/samples —— 寄样列表（联表商品/达人，支持 ?status=）
router.get('/', async (req, res, next) => {
  try {
    const { status } = req.query;
    let sql = `SELECT s.*, p.name AS product_name, p.sku, d.name AS daren_name
               FROM samples s
               LEFT JOIN products p ON s.product_id = p.id
               LEFT JOIN darens d ON s.daren_id = d.id`;
    const params = [];
    if (status) { sql += ' WHERE s.status = ?'; params.push(status); }
    sql += ' ORDER BY s.updated_at DESC';
    const rows = params.length ? await query(sql, params) : await query(sql);
    res.json({ code: 0, data: rows });
  } catch (e) { next(e); }
});

// POST /api/samples —— 创建寄样申请（status 默认「申请」）
router.post('/', requireRole(['admin', 'daren_op']), async (req, res, next) => {
  try {
    const body = req.body || {};
    if (!body.product_id || !body.daren_id) return res.status(400).json({ code: 400, msg: '商品和达人必填' });
    const data = { status: '申请' };
    FIELDS.forEach((k) => { if (body[k] !== undefined) data[k] = body[k]; });
    const keys = Object.keys(data);
    const vals = Object.values(data);
    const r = await query(
      `INSERT INTO samples (${keys.join(',')}) VALUES (${keys.map(() => '?').join(',')})`,
      vals
    );
    res.json({ code: 0, data: { id: r.insertId } });
  } catch (e) { next(e); }
});

// PUT /api/samples/:id —— 更新寄样状态（校验状态机 + 写通知）
router.put('/:id', requireRole(['admin', 'daren_op']), async (req, res, next) => {
  try {
    const id = req.params.id;
    const rows = await query('SELECT * FROM samples WHERE id = ?', [id]);
    if (!rows.length) return res.status(404).json({ code: 404, msg: '寄样记录不存在' });
    const current = rows[0];

    const body = req.body || {};
    const status = body.status;
    if (!status) return res.status(400).json({ code: 400, msg: '目标状态必填' });

    const allowed = TRANSITIONS[current.status] || [];
    if (allowed.indexOf(status) < 0) {
      return res.status(400).json({ code: 400, msg: `非法状态流转：${current.status} → ${status}` });
    }

    const updates = { status };
    ['express_no', 'send_date', 'sign_date', 'return_reason', 'settle_amount', 'settle_date', 'recycle_date', 'remark', 'sample_fee', 'deposit'].forEach((k) => {
      if (body[k] !== undefined && body[k] !== '') updates[k] = body[k];
    });

    // 前端未显式传入日期时，才按状态自动补当天
    const today = new Date().toISOString().slice(0, 10);
    if (status === '寄出' && !updates.send_date) updates.send_date = today;
    if (status === '签收' && !updates.sign_date) updates.sign_date = today;
    if (status === '结算' && !updates.settle_date) updates.settle_date = today;
    if (status === '已回收' && !updates.recycle_date) updates.recycle_date = today;

    const keys = Object.keys(updates);
    const setSql = keys.map((k) => `${k} = ?`).join(', ');
    await query(`UPDATE samples SET ${setSql} WHERE id = ?`, [...Object.values(updates), id]);

    // 状态变更通知（写入当前操作人）
    await query(
      'INSERT INTO notifications (user_id, type, content) VALUES (?, ?, ?)',
      [req.user.id, 'sample', `寄样记录 #${id} 状态由「${current.status}」变更为「${status}」`]
    );

    res.json({ code: 0, data: { id: Number(id), status } });
  } catch (e) { next(e); }
});

module.exports = router;

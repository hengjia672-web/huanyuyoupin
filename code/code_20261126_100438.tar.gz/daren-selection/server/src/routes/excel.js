'use strict';
const express = require('express');
const path = require('path');
const multer = require('multer');
const ExcelJS = require('exceljs');
const { query } = require('../db');
const { authRequired, requireRole } = require('../auth');
const { writeAudit, clientIp } = require('../audit');

const router = express.Router();
router.use(authRequired);

// ============ Excel 导入配置 ============
// 表头中文 → 数据库字段映射（与导出列保持一致）
const IMPORT_SCHEMAS = {
  brands: {
    fields: {
      '品牌名称': 'name', '国家/地区': 'country', '主营品类': 'category', '品牌方主体': 'company',
      '对接人': 'contact', '联系方式': 'contact_info', '合作进度': 'coop_stage', '品牌分级': 'grade',
      '合同编号': 'contract_no', '合同到期日': 'contract_expiry', '授权到期日': 'auth_expiry',
      '账期': 'payment_terms', '备注': 'remark',
    },
  },
  products: {
    fields: {
      '商品名称': 'name', 'SKU': 'sku', '所属品牌': 'brand_name', '品类': 'category',
      '供货价': 'supply_price', '售价': 'sale_price', '库存': 'stock', '库存预警线': 'stock_warn',
      '上架状态': 'shelf_status', '累计销量': 'sales', '备注': 'remark',
    },
  },
  darens: {
    fields: {
      '达人名称': 'name', '抖音号': 'douyin_id', '粉丝量': 'fans', '合作状态': 'coop_status',
      '配合度(1-5)': 'cooperation', '联系方式': 'contact', '带货品类': 'category', '累计GMV': 'gmv', '备注': 'remark',
    },
  },
};
const SHEET_NAMES = { brands: '品牌', products: '商品', darens: '达人' };
const ENUMS = {
  coop_stage: ['挖掘中', '洽谈中', '已签约', '合作中', '已终止'],
  grade: ['S', 'A', 'B', 'C'],
  shelf_status: ['待上架', '已上架', '已下架'],
  coop_status: ['建联中', '寄样中', '已合作', '已终止'],
};
// 模板示例行
const SAMPLE_ROWS = {
  brands: { name: '示例品牌', country: '日本', category: '美妆', company: 'XXX株式会社',
    contact: '张三', contact_info: '13800000000', coop_stage: '洽谈中', grade: 'A',
    contract_no: 'HT-001', contract_expiry: '2026-12-31', auth_expiry: '2027-06-30',
    payment_terms: '月结30天', remark: '示例行，可删除后填写' },
  products: { name: '示例商品', sku: 'SKU-001', brand_name: '示例品牌', category: '护肤',
    supply_price: 45, sale_price: 129, stock: 100, stock_warn: 20,
    shelf_status: '已上架', sales: 0, remark: '示例行，可删除后填写' },
  darens: { name: '示例达人', douyin_id: 'dy123456', fans: 50000, coop_status: '建联中',
    cooperation: 4, contact: '13800000000', category: '美妆', gmv: 120000, remark: '示例行，可删除后填写' },
};

// 只接收 xlsx，内存缓冲（解析用）
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter(req, file, cb) {
    const ext = path.extname(file.originalname || '').toLowerCase();
    if (['.xlsx', '.xls'].includes(ext)) return cb(null, true);
    cb(new Error('仅支持上传 .xlsx 文件'));
  },
});

// Excel 单元格值归一化：Date→YYYY-MM-DD，空串→null
// 数字字段容错：识别「1000W」「5K」「2.5亿」「1.2w」等业务简写（W/K 不区分大小写，中文单位万/千/亿）
function normVal(v) {
  if (v === null || v === undefined) return null;
  if (v instanceof Date) {
    const p = (n) => String(n).padStart(2, '0');
    return `${v.getFullYear()}-${p(v.getMonth() + 1)}-${p(v.getDate())}`;
  }
  if (typeof v === 'string') {
    const t = v.trim();
    if (t === '') return null;
    // 数字简写识别：纯数字/小数 + 可选单位（w/k/万/千/亿，不区分大小写）
    const m = t.match(/^(-?\d+(?:\.\d+)?)\s*([wWkK万千亿])?$/);
    if (m) {
      const n = parseFloat(m[1]);
      const unit = (m[2] || '').toLowerCase();
      const mul = unit === 'w' || unit === '万' ? 10000
                : unit === 'k' || unit === '千' ? 1000
                : unit === '亿' ? 100000000
                : 1;
      return Math.round(n * mul * 100) / 100; // 保留两位精度，避免浮点尾巴
    }
    return t;
  }
  return v;
}

// GET /api/excel/template?type=brands|products|darens —— 下载导入模板
router.get('/template', requireRole(['admin', 'selection', 'daren_op']), async (req, res, next) => {
  try {
    const type = req.query.type;
    const schema = IMPORT_SCHEMAS[type];
    if (!schema) return res.status(400).json({ code: 400, msg: 'type 无效：brands / products / darens' });

    const wb = new ExcelJS.Workbook();
    const ws = wb.addWorksheet(SHEET_NAMES[type]);
    const headers = Object.keys(schema.fields);
    ws.columns = headers.map((h) => ({ header: h, width: 18 }));
    const sample = SAMPLE_ROWS[type];
    ws.addRow(headers.map((h) => sample[schema.fields[h]]));

    const buf = await wb.xlsx.writeBuffer();
    const filename = `${SHEET_NAMES[type]}导入模板.xlsx`;
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename*=UTF-8''${encodeURIComponent(filename)}`);
    res.on('finish', () => {
      writeAudit({ userId: req.user.id, userName: req.user.name, ip: clientIp(req), method: 'GET', path: '/api/excel/export', table: 'excel', action: 'export', detail: `导出台账：${filename}` });
    });
    res.send(Buffer.from(buf));
  } catch (e) { next(e); }
});

// POST /api/excel/import?type=brands|products|darens —— 上传 xlsx 批量导入
router.post('/import', requireRole(['admin', 'selection', 'daren_op']), upload.single('file'), async (req, res, next) => {
  try {
    const type = req.query.type;
    const schema = IMPORT_SCHEMAS[type];
    if (!schema) return res.status(400).json({ code: 400, msg: 'type 无效：brands / products / darens' });
    if (!req.file) return res.status(400).json({ code: 400, msg: '未收到文件，请上传 .xlsx' });

    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(req.file.buffer);
    const ws = wb.worksheets[0];
    if (!ws || ws.rowCount < 2) return res.status(400).json({ code: 400, msg: '表格内容为空，请下载模板填写后再导入' });

    // 表头 → 数据库字段映射（按列号）
    const colMap = new Map();
    ws.getRow(1).eachCell({ includeEmpty: true }, (cell, col) => {
      const h = String(cell.value || '').trim();
      if (schema.fields[h]) colMap.set(col, schema.fields[h]);
    });
    if (colMap.size === 0) return res.status(400).json({ code: 400, msg: '未识别到表头，请使用系统下载的模板' });

    // 商品导入需要 品牌名称 → brand_id
    let brandMap = null;
    if (type === 'products') {
      const brands = await query('SELECT id, name FROM brands');
      brandMap = new Map(brands.map((b) => [String(b.name).trim(), b.id]));
    }

    const errors = [];
    let ok = 0;
    let skip = 0;

    for (let r = 2; r <= ws.rowCount; r++) {
      const row = ws.getRow(r);
      const vals = {};
      let hasData = false;
      for (const [col, field] of colMap.entries()) {
        const v = normVal(row.getCell(col).value);
        vals[field] = v;
        if (v !== null) hasData = true;
      }
      if (!hasData) { skip++; continue; }

      const required = schema.fields['品牌名称'] || schema.fields['商品名称'] || schema.fields['达人名称'];
      if (!vals.name) { errors.push(`第${r}行：缺少必填字段「${required}」`); continue; }

      // 枚举校验
      for (const [field, allowed] of Object.entries(ENUMS)) {
        if (vals[field] && !allowed.includes(vals[field])) {
          errors.push(`第${r}行：${field} 值「${vals[field]}」不合法，允许：${allowed.join('/')}`);
          break;
        }
      }
      if (errors.length && errors[errors.length - 1].startsWith(`第${r}行`)) continue;

      // 商品：品牌名称 → brand_id
      if (type === 'products' && vals.brand_name) {
        const bid = brandMap.get(String(vals.brand_name).trim());
        if (!bid) { errors.push(`第${r}行：品牌「${vals.brand_name}」不存在，请先导入该品牌`); continue; }
        vals.brand_id = bid;
        delete vals.brand_name;
      }

      const fields = Object.keys(vals).filter((f) => !['created_at', 'updated_at'].includes(f));
      const placeholders = fields.map(() => '?').join(',');
      try {
        await query(
          `INSERT INTO ${type} (${fields.join(',')}) VALUES (${placeholders})`,
          fields.map((f) => vals[f])
        );
        ok++;
      } catch (e) {
        // 单行失败不中断整批，附加到 errors 继续
        errors.push(`第${r}行：插入失败 — ${e.sqlMessage || e.code || e.message}`);
      }
    }

    res.json({ code: 0, data: { total: ok + skip + errors.length, ok, skip, errors } });
  } catch (e) { next(e); }
});

// GET /api/excel/export —— 导出多 sheet 台账（.xlsx 下载）
router.get('/export', requireRole(['admin', 'selection', 'daren_op', 'finance']), async (req, res, next) => {
  try {
    const [brands, products, darens, coop, samples] = await Promise.all([
      query('SELECT * FROM brands ORDER BY id ASC'),
      query(`SELECT p.*, b.name AS brand_name FROM products p
             LEFT JOIN brands b ON p.brand_id = b.id ORDER BY p.id ASC`),
      query(`SELECT id, name, douyin_id, fans, coop_status, cooperation, contact, category, gmv, remark, updated_at
             FROM darens ORDER BY id ASC`),
      query(`SELECT pd.product_id, pd.daren_id, pd.status,
                    pd.coop_fee, pd.coop_mode, pd.commission_rate, pd.remark,
                    pd.updated_at,
                    p.name AS product_name, p.sku,
                    d.name AS daren_name, d.cooperation AS daren_cooperation
             FROM product_daren pd
             LEFT JOIN products p ON pd.product_id = p.id
             LEFT JOIN darens d ON pd.daren_id = d.id
             ORDER BY pd.updated_at DESC`),
      query(`SELECT s.*, p.name AS product_name, d.name AS daren_name
             FROM samples s
             LEFT JOIN products p ON s.product_id = p.id
             LEFT JOIN darens d ON s.daren_id = d.id
             ORDER BY s.updated_at DESC`),
    ]);

    const wb = new ExcelJS.Workbook();
    wb.creator = '寰宇优品供应链品牌管理系统';
    wb.created = new Date();

    // Sheet 1：品牌
    const brandSheet = wb.addWorksheet('品牌');
    brandSheet.columns = [
      { header: '品牌名称', key: 'name', width: 20 },
      { header: '国家/地区', key: 'country', width: 12 },
      { header: '主营品类', key: 'category', width: 16 },
      { header: '品牌方主体', key: 'company', width: 22 },
      { header: '对接人', key: 'contact', width: 12 },
      { header: '联系方式', key: 'contact_info', width: 20 },
      { header: '合作进度', key: 'coop_stage', width: 12 },
      { header: '品牌分级', key: 'grade', width: 10 },
      { header: '合同编号', key: 'contract_no', width: 16 },
      { header: '合同到期日', key: 'contract_expiry', width: 14 },
      { header: '授权到期日', key: 'auth_expiry', width: 14 },
      { header: '账期', key: 'payment_terms', width: 12 },
      { header: '备注', key: 'remark', width: 24 },
    ];
    brandSheet.addRows(brands);

    // Sheet 2：商品
    const productSheet = wb.addWorksheet('商品');
    productSheet.columns = [
      { header: '商品名称', key: 'name', width: 24 },
      { header: 'SKU', key: 'sku', width: 14 },
      { header: '所属品牌', key: 'brand_name', width: 16 },
      { header: '品类', key: 'category', width: 12 },
      { header: '供货价', key: 'supply_price', width: 12 },
      { header: '售价', key: 'sale_price', width: 12 },
      { header: '库存', key: 'stock', width: 10 },
      { header: '库存预警线', key: 'stock_warn', width: 12 },
      { header: '上架状态', key: 'shelf_status', width: 10 },
      { header: '累计销量', key: 'sales', width: 10 },
      { header: '备注', key: 'remark', width: 24 },
    ];
    productSheet.addRows(products);

    // Sheet 3：达人
    const darenSheet = wb.addWorksheet('达人');
    darenSheet.columns = [
      { header: '达人名称', key: 'name', width: 16 },
      { header: '抖音号', key: 'douyin_id', width: 14 },
      { header: '粉丝量', key: 'fans', width: 10 },
      { header: '合作状态', key: 'coop_status', width: 12 },
      { header: '配合度(1-5)', key: 'cooperation', width: 12 },
      { header: '联系方式', key: 'contact', width: 18 },
      { header: '带货品类', key: 'category', width: 12 },
      { header: '累计GMV', key: 'gmv', width: 12 },
      { header: '备注', key: 'remark', width: 24 },
    ];
    darenSheet.addRows(darens);

    // Sheet 4：达人合作
    const coopSheet = wb.addWorksheet('达人合作');
    coopSheet.columns = [
      { header: '商品名称', key: 'product_name', width: 24 },
      { header: 'SKU', key: 'sku', width: 14 },
      { header: '达人名称', key: 'daren_name', width: 16 },
      { header: '达人配合度', key: 'daren_cooperation', width: 12 },
      { header: '合作状态', key: 'status', width: 12 },
      { header: '合作费用', key: 'coop_fee', width: 12 },
      { header: '带货方式', key: 'coop_mode', width: 12 },
      { header: '佣金比例(%)', key: 'commission_rate', width: 14 },
      { header: '备注', key: 'remark', width: 20 },
      { header: '更新时间', key: 'updated_at', width: 20 },
    ];
    coopSheet.addRows(coop);

    // Sheet 5：寄样记录
    const sampleSheet = wb.addWorksheet('寄样记录');
    sampleSheet.columns = [
      { header: '商品名称', key: 'product_name', width: 24 },
      { header: '达人名称', key: 'daren_name', width: 16 },
      { header: '状态', key: 'status', width: 12 },
      { header: '样品费', key: 'sample_fee', width: 12 },
      { header: '押金', key: 'deposit', width: 12 },
      { header: '快递单号', key: 'express_no', width: 18 },
      { header: '申请日期', key: 'apply_date', width: 14 },
      { header: '寄出日期', key: 'send_date', width: 14 },
      { header: '签收日期', key: 'sign_date', width: 14 },
      { header: '退回原因', key: 'return_reason', width: 20 },
      { header: '结算金额', key: 'settle_amount', width: 12 },
      { header: '结算日期', key: 'settle_date', width: 14 },
      { header: '回收日期', key: 'recycle_date', width: 14 },
      { header: '备注', key: 'remark', width: 24 },
    ];
    sampleSheet.addRows(samples);

    const buf = await wb.xlsx.writeBuffer();

    const filename = `供应链台账_${new Date().toISOString().slice(0, 10)}.xlsx`;
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename*=UTF-8''${encodeURIComponent(filename)}`);
    res.on('finish', () => {
      writeAudit({ userId: req.user.id, userName: req.user.name, ip: clientIp(req), method: 'GET', path: '/api/excel/export', table: 'excel', action: 'export', detail: `导出台账：${filename}` });
    });
    res.send(Buffer.from(buf));
  } catch (e) { next(e); }
});

module.exports = router;

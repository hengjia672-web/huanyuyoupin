'use strict';
const express = require('express');
const { query } = require('../db');
const { authRequired } = require('../auth');

const router = express.Router();
router.use(authRequired);

// GET /api/alerts —— 合同到期预警 + 库存预警
router.get('/', async (req, res, next) => {
  try {
    const today = new Date().toISOString().slice(0, 10);
    const future = new Date(Date.now() + 30 * 24 * 3600 * 1000).toISOString().slice(0, 10);

    // 合同到期日在未来 30 天内 或 已逾期（contract_expiry <= 今天+30，含逾期）
    const contractExpiry = await query(
      `SELECT id, name, contract_expiry,
              DATEDIFF(contract_expiry, ?) AS days_left
       FROM brands
       WHERE contract_expiry IS NOT NULL AND contract_expiry <= ?
       ORDER BY contract_expiry ASC`,
      [today, future]
    );

    // 库存数量 <= 预警线 且 预警线 > 0
    const stockWarn = await query(
      `SELECT id, name, sku, stock, stock_warn
       FROM products
       WHERE stock_warn > 0 AND stock <= stock_warn
       ORDER BY stock ASC`
    );

    res.json({ code: 0, data: { contractExpiry, stockWarn } });
  } catch (e) { next(e); }
});

module.exports = router;

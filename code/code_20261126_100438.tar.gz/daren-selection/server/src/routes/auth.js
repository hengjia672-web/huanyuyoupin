'use strict';
const express = require('express');
const bcrypt = require('bcryptjs');
const rateLimit = require('express-rate-limit');
const { query } = require('../db');
const { signToken, authRequired } = require('../auth');
const { writeAudit, clientIp } = require('../audit');

const router = express.Router();

// 登录限流：15 分钟内同 IP 最多 10 次
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { code: 429, msg: '登录尝试过于频繁，请 15 分钟后再试' },
});

// 登录（成功/失败均审计）
router.post('/login', loginLimiter, async (req, res, next) => {
  const ip = clientIp(req);
  try {
    const { username, password } = req.body || {};
    if (!username || !password) return res.status(400).json({ code: 400, msg: '请输入账号和密码' });
    const rows = await query('SELECT * FROM users WHERE username = ? LIMIT 1', [username]);
    const user = rows[0];
    if (!user || !bcrypt.compareSync(password, user.password_hash)) {
      writeAudit({ userId: null, userName: username, ip, method: 'POST', path: '/api/auth/login', action: 'login', detail: '登录失败：账号或密码错误' });
      return res.status(401).json({ code: 401, msg: '账号或密码错误' });
    }
    if (user.status !== 1) {
      writeAudit({ userId: user.id, userName: user.username, ip, method: 'POST', path: '/api/auth/login', action: 'login', detail: '登录失败：账号已停用' });
      return res.status(403).json({ code: 403, msg: '账号已停用' });
    }
    const token = signToken(user);
    writeAudit({ userId: user.id, userName: user.username, ip, method: 'POST', path: '/api/auth/login', action: 'login', detail: '登录成功' });
    let permissions = user.permissions || null;
    try { permissions = permissions ? JSON.parse(permissions) : null; } catch (e) { permissions = null; }
    res.json({ code: 0, data: { token, user: { id: user.id, username: user.username, name: user.name, role: user.role, permissions } } });
  } catch (e) { next(e); }
});

// 登出（无状态 JWT，仅记录痕迹）
router.post('/logout', authRequired, (req, res) => {
  writeAudit({
    userId: req.user.id, userName: req.user.name || req.user.username, ip: clientIp(req),
    method: 'POST', path: '/api/auth/logout', action: 'logout', detail: '退出登录',
  });
  res.json({ code: 0, data: null, msg: '已退出' });
});

// 修改我的密码（登录用户自助）
router.post('/change-password', authRequired, async (req, res, next) => {
  const ip = clientIp(req);
  try {
    const { old_password, new_password } = req.body || {};
    if (!old_password || !new_password) return res.status(400).json({ code: 400, msg: '请输入旧密码和新密码' });
    if (String(new_password).length < 6) return res.status(400).json({ code: 400, msg: '新密码至少 6 位' });
    if (old_password === new_password) return res.status(400).json({ code: 400, msg: '新密码不能与旧密码相同' });

    const rows = await query('SELECT * FROM users WHERE id = ?', [req.user.id]);
    const user = rows[0];
    if (!user || !bcrypt.compareSync(old_password, user.password_hash)) {
      writeAudit({ userId: req.user.id, userName: req.user.name || req.user.username, ip, method: 'POST', path: '/api/auth/change-password', action: 'update', detail: '修改密码失败：旧密码错误' });
      return res.status(400).json({ code: 400, msg: '旧密码不正确' });
    }

    const hash = bcrypt.hashSync(String(new_password), 10);
    await query('UPDATE users SET password_hash = ? WHERE id = ?', [hash, user.id]);
    writeAudit({ userId: user.id, userName: user.username, ip, method: 'POST', path: '/api/auth/change-password', action: 'update', detail: '修改我的密码' });
    res.json({ code: 0, data: null, msg: '密码已修改' });
  } catch (e) { next(e); }
});

// 当前用户信息
router.get('/me', authRequired, (req, res) => {
  res.json({ code: 0, data: req.user });
});

module.exports = router;

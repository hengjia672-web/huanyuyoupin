'use strict';
const express = require('express');
const { query } = require('../db');
const { authRequired, requireRole } = require('../auth');

const router = express.Router();
router.use(authRequired);

// 允许写入的字段白名单（防注入）
const FIELDS = ['name','logo_url','country','category','company','contact','contact_info','coop_stage','grade','contract_no','contract_expiry','auth_expiry','payment_terms','remark','owner_id'];

function pick(body) {
  const out = {};
  FIELDS.forEach(k => { if (body[k] !== undefined) out[k] = body[k]; });
  return out;
}

// 列表（含合同到期/逾期标记计算在前端，这里只回数据）
// 数据级权限：selection 角色只返回自己负责（owner_id=自己）或未归属（owner_id IS NULL）的品牌
router.get('/', async (req, res, next) => {
  try {
    let sql = 'SELECT * FROM brands';
    const params = [];
    if (req.user.role === 'selection') {
      sql += ' WHERE owner_id = ? OR owner_id IS NULL';
      params.push(req.user.id);
    }
    sql += ' ORDER BY updated_at DESC';
    const rows = params.length ? await query(sql, params) : await query(sql);
    res.json({ code: 0, data: rows });
  } catch (e) { next(e); }
});

// 新增（选品 / 管理员）
router.post('/', requireRole(['admin','selection']), async (req, res, next) => {
  try {
    const data = pick(req.body);
    if (!data.name) return res.status(400).json({ code: 400, msg: '品牌名称必填' });
    const keys = Object.keys(data), vals = Object.values(data);
    const r = await query(
      `INSERT INTO brands (${keys.join(',')}) VALUES (${keys.map(() => '?').join(',')})`, vals
    );
    res.json({ code: 0, data: { id: r.insertId } });
  } catch (e) { next(e); }
});

// 更新
router.put('/:id', requireRole(['admin','selection']), async (req, res, next) => {
  try {
    const data = pick(req.body);
    const keys = Object.keys(data);
    if (!keys.length) return res.status(400).json({ code: 400, msg: '无更新字段' });
    const setSql = keys.map(k => `${k} = ?`).join(', ');
    await query(`UPDATE brands SET ${setSql} WHERE id = ?`, [...Object.values(data), req.params.id]);
    res.json({ code: 0, data: { id: Number(req.params.id) } });
  } catch (e) { next(e); }
});

// 删除（仅管理员）
router.delete('/:id', requireRole('admin'), async (req, res, next) => {
  try {
    await query('DELETE FROM brands WHERE id = ?', [req.params.id]);
    res.json({ code: 0, data: {} });
  } catch (e) { next(e); }
});

module.exports = router;

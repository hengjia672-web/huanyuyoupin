'use strict';
const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const sharp = require('sharp');
const COS = require('cos-nodejs-sdk-v5');
const { authRequired, requireRole } = require('../auth');
const { query } = require('../db');

// ===== CloudBase 云存储（API Key 外部访问，官方推荐方案）=====
// 配置：CLOUDBASE_ENV_ID + CLOUDBASE_API_KEY_ID + CLOUDBASE_API_KEY_SECRET（控制台 环境设置→API密钥）
let cloudBaseApp = null;
function getCloudBaseApp() {
  if (!process.env.CLOUDBASE_ENV_ID) return null;
  if (!cloudBaseApp) {
    const cloudbase = require('@cloudbase/node-sdk');
    const initOpts = { env: process.env.CLOUDBASE_ENV_ID };
    // 鉴权优先级：accessKey（服务端 API Key JWT，CLOUDBASE_API_KEY 或 CLOUDBASE_APIKEY）→ secretId/secretKey
    const apiKey = process.env.CLOUDBASE_API_KEY || process.env.CLOUDBASE_APIKEY;
    if (apiKey) {
      initOpts.accessKey = apiKey;
    } else if (process.env.CLOUDBASE_API_KEY_ID && process.env.CLOUDBASE_API_KEY_SECRET) {
      initOpts.secretId = process.env.CLOUDBASE_API_KEY_ID;
      initOpts.secretKey = process.env.CLOUDBASE_API_KEY_SECRET;
    }
    cloudBaseApp = cloudbase.init(initOpts);
  }
  return cloudBaseApp;
}
// 兼容别名：是否有可用 CloudBase（仅需 env id + 任一鉴权）
function getCloudBaseStorage() {
  const app = getCloudBaseApp();
  return app || null;
}
const { writeAudit, clientIp } = require('../audit');

const router = express.Router();
router.use(authRequired);

// 本地降级存储目录
// 统一图片存储目录：server/uploads（与 index.js 静态服务 /uploads 一致）
const UPLOAD_DIR = path.join(__dirname, '..', '..', 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

// 压缩参数：主图 ≤800px，副图 ≤400px（规划文档约定）
const KIND_LIMITS = { main: 800, sub: 400, avatar: 200 };
const JPEG_QUALITY = 82;

// 只接收图片，内存缓冲（天然无临时文件残留）
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter(req, file, cb) {
    if (/^image\//.test(file.mimetype)) return cb(null, true);
    cb(new Error('仅支持上传图片文件'));
  },
});

function extOf(file) { return path.extname(file.originalname || '').toLowerCase(); }

// sharp 压缩：限制尺寸 + 按格式压质量 + png/gif 转 webp
async function compress(buffer, kind) {
  const maxW = KIND_LIMITS[kind] || KIND_LIMITS.main;
  const meta = await sharp(buffer).metadata();
  const fmt = (meta.format || 'jpeg').toLowerCase();

  let pipeline = sharp(buffer, { animated: false }).rotate().resize({
    width: Math.min(meta.width || maxW, maxW),
    withoutEnlargement: true,
  });

  let outFormat = fmt;
  if (fmt === 'jpeg') { pipeline = pipeline.jpeg({ quality: JPEG_QUALITY, mozjpeg: true }); outFormat = 'jpeg'; }
  else if (fmt === 'png' || fmt === 'gif' || fmt === 'tiff' || fmt === 'bmp') {
    pipeline = pipeline.webp({ quality: JPEG_QUALITY });
    outFormat = 'webp';
  } else { pipeline = pipeline.webp({ quality: JPEG_QUALITY }); outFormat = 'webp'; }

  return { buffer: await pipeline.toBuffer(), outFormat, width: meta.width || 0 };
}

function uploadToCos(key, buffer) {
  return new Promise((resolve, reject) => {
    const cos = new COS({ SecretId: process.env.COS_SECRET_ID, SecretKey: process.env.COS_SECRET_KEY });
    const region = process.env.COS_REGION || 'ap-guangzhou';
    cos.putObject({ Bucket: process.env.COS_BUCKET, Region: region, Key: key, Body: buffer }, (err) => {
      if (err) return reject(err);
      const cdn = (process.env.COS_CDN_DOMAIN || '').replace(/\/+$/, '');
      const url = cdn ? `${cdn}/${key}` : `https://${process.env.COS_BUCKET}.cos.${region}.myqcloud.com/${key}`;
      resolve(url);
    });
  });
}

// 上传到 CloudBase 云存储；返回稳定可访问 URL
async function uploadToCloudBase(cloudPath, buffer) {
  const app = getCloudBaseApp();
  const res = await app.uploadFile({ cloudPath, fileContent: buffer });
  const fileID = res.fileID;
  // 已配置 CDN 域名：拼永久 URL 并验证匿名可读；
  // 若存储桶尚未在控制台开启「所有用户可读」（403），自动降级为签名 URL，保证系统内图片正常
  let cdn = (process.env.CLOUDBASE_CDN_DOMAIN || '').replace(/\/+$/, '');
  if (cdn) {
    if (!/^https?:\/\//.test(cdn)) cdn = 'https://' + cdn; // 补协议头
    try {
      const resp = await fetch(`${cdn}/${cloudPath}`, { method: 'HEAD', signal: AbortSignal.timeout(5000) });
      if (resp.ok) return `${cdn}/${cloudPath}`;
    } catch (e) { /* CDN 不可达或超时，走签名 URL 降级 */ }
  }
  // 用 SDK 换取临时签名 URL（maxAge 最大 7 天）
  const urls = await app.getTempFileURL({ fileList: [{ fileID, maxAge: 604800 }] });
  const item = urls.fileList && urls.fileList[0];
  if (!item || !item.tempFileURL) throw new Error('获取文件访问地址失败');
  return item.tempFileURL;
}

function saveLocal(buffer, ext) {
  const filename = `${Date.now()}-${crypto.randomBytes(6).toString('hex')}${ext}`;
  fs.writeFileSync(path.join(UPLOAD_DIR, filename), buffer);
  return `/uploads/${filename}`;
}

// ===== 本地图片清理（孤儿文件回收）=====
// ⚠️ 安全铁律：只要文件仍被数据库引用（商品主图/副图、品牌 LOGO），无论多旧都不删除。
// 历史事故：旧版仅按 mtime 删除 30 天前文件，本地存储成为唯一存储后，
//          导致线上正在使用的图片被定时任务清空（2026-09-25）。
async function collectReferencedFiles() {
  const rows = await query(
    `SELECT main_image AS u FROM products WHERE main_image LIKE '/uploads/%'
     UNION SELECT sub_image1 FROM products WHERE sub_image1 LIKE '/uploads/%'
     UNION SELECT sub_image2 FROM products WHERE sub_image2 LIKE '/uploads/%'
     UNION SELECT logo_url FROM brands WHERE logo_url LIKE '/uploads/%'`
  );
  const set = new Set();
  for (const r of rows) {
    const u = String(r.u || '').trim();
    if (u) set.add(path.posix.basename(u));
  }
  return set;
}

// 清理本地孤儿文件：仅删除「数据库未引用」且超过 maxAgeDays 未变动的文件
async function cleanupLocal(maxAgeDays = 30) {
  const files = fs.readdirSync(UPLOAD_DIR);
  const referenced = await collectReferencedFiles();
  // 引用集为空说明数据库查询异常，此时放弃本轮清理（宁可不删，绝不误删）
  if (referenced.size === 0) {
    console.warn('[upload] 引用集为空（数据库异常？），跳过本次清理以避免误删');
    return { removed: 0, freed: 0, kept: files.length, referenced: 0, total: files.length, skipped: true };
  }
  const cutoff = Date.now() - maxAgeDays * 24 * 3600 * 1000;
  let freed = 0;
  let removed = 0;
  let kept = 0;
  for (const f of files) {
    const fp = path.join(UPLOAD_DIR, f);
    try {
      const st = fs.statSync(fp);
      if (!st.isFile()) continue;
      // 在用文件 → 受保护；未超期文件 → 保留
      if (referenced.has(f) || st.mtimeMs >= cutoff) { kept++; continue; }
      freed += st.size;
      fs.unlinkSync(fp);
      removed++;
    } catch (e) { /* 忽略并发删除 */ }
  }
  return { removed, freed, kept, referenced: referenced.size, total: files.length };
}

// 启动时 + 每 24h 回收孤儿文件（在用文件受保护，不会再被删）
function startCleanupLoop() {
  const run = () => cleanupLocal(30).then((r) => {
    if (r.skipped) return;
    console.log(`[upload] 本地图清理：在用/受保护 ${r.referenced} 个，目录共 ${r.total} 个，删除孤儿 ${r.removed} 个，释放 ${(r.freed / 1024 / 1024).toFixed(2)} MB`);
  }).catch((e) => console.warn('[upload] 清理任务异常（已跳过，不影响服务）:', e.message));
  run();
  setInterval(run, 24 * 3600 * 1000);
}
startCleanupLoop();

// POST /api/upload/image?kind=main|sub|avatar —— 压缩后上传
router.post('/image', requireRole(['admin', 'selection', 'daren_op']), (req, res, next) => {
  upload.single('file')(req, res, async (err) => {
    if (err) return res.status(400).json({ code: 400, msg: err.message || '上传失败' });
    if (!req.file) return res.status(400).json({ code: 400, msg: '请选择要上传的文件（字段名 file）' });
    try {
      const kind = req.query.kind || 'main';
      const original = req.file.size;
      const { buffer, outFormat } = await compress(req.file.buffer, kind);
      const ext = outFormat === 'jpeg' ? '.jpg' : '.webp';
      const key = `uploads/${Date.now()}-${crypto.randomBytes(6).toString('hex')}${ext}`;

      // 存储后端：本地优先（稳定、无签名过期问题）；CloudBase 作为异地备份（失败不影响主流程）
      // 背景：CloudBase 桶未开启匿名可读，上传会降级为临时签名 URL，签名过期后前端图片 403。
      //       故改用本地静态存储 + nginx /uploads 反代，CloudBase 仅作容灾备份。
      let url;
      let provider = 'local';
      url = saveLocal(buffer, ext);
      if (getCloudBaseStorage()) {
        try {
          await uploadToCloudBase(key, buffer);
          provider = 'local+cloudbase';
        } catch (e) {
          console.warn('[upload] CloudBase 异地备份失败（不影响本地存储）:', e.message);
        }
      }
      writeAudit({
        userId: req.user.id, userName: req.user.name, ip: clientIp(req), method: 'POST', path: '/api/upload/image',
        table: 'upload', action: 'create', detail: `上传图片 kind=${kind} [${provider}] 原${(original / 1024).toFixed(0)}KB → ${(buffer.length / 1024).toFixed(0)}KB`,
      });
      res.json({ code: 0, data: { url, size: buffer.length, original_size: original, format: outFormat, provider } });
    } catch (e) { next(e); }
  });
});

// GET /api/upload/stats —— 本地存储占用
router.get('/stats', async (req, res) => {
  let count = 0;
  let bytes = 0;
  try {
    for (const f of fs.readdirSync(UPLOAD_DIR)) {
      const st = fs.statSync(path.join(UPLOAD_DIR, f));
      if (st.isFile()) { count++; bytes += st.size; }
    }
  } catch (e) { /* ignore */ }
  res.json({ code: 0, data: { count, bytes, has_cos: !!process.env.COS_SECRET_ID, has_cloudbase: !!getCloudBaseStorage(), provider: getCloudBaseStorage() ? 'cloudbase' : (process.env.COS_SECRET_ID ? 'cos' : 'local') } });
});

// POST /api/upload/cleanup?days=30 —— 手动回收孤儿本地图片（管理员；在用图片永不删除）
router.post('/cleanup', requireRole('admin'), async (req, res, next) => {
  try {
    const days = Math.max(1, Number(req.query.days) || 30);
    const r = await cleanupLocal(days);
    writeAudit({
      userId: req.user.id, userName: req.user.name, ip: clientIp(req), method: 'POST', path: '/api/upload/cleanup',
      table: 'upload', action: 'delete', detail: `回收孤儿图片 ${r.removed} 个，释放 ${(r.freed / 1024 / 1024).toFixed(2)} MB（保护在用 ${r.referenced} 个，超期阈值 ${days} 天）`,
    });
    if (r.skipped) {
      return res.json({ code: 0, data: r, msg: '数据库引用集为空，已跳过清理（保护性中止）' });
    }
    res.json({ code: 0, data: r, msg: `已回收孤儿文件 ${r.removed} 个，释放 ${(r.freed / 1024).toFixed(0)} KB；在用图片 ${r.referenced} 个全部保留` });
  } catch (e) { next(e); }
});

module.exports = router;

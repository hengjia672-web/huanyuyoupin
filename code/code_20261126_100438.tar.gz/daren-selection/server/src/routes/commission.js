'use strict';
const express = require('express');
const { query } = require('../db');
const { authRequired, requireRole } = require('../auth');

const router = express.Router();
router.use(authRequired);

// 允许写入的字段白名单
const FIELDS = ['daren_id', 'product_id', 'rate', 'effective_date', 'remark'];

function pick(body) {
  const out = {};
  FIELDS.forEach((k) => { if (body[k] !== undefined) out[k] = body[k]; });
  return out;
}

// GET /api/commission —— 佣金方案列表（联表达人/商品）
router.get('/', async (req, res, next) => {
  try {
    const rows = await query(
      `SELECT cc.*, d.name AS daren_name, p.name AS product_name, p.sku
       FROM commission_configs cc
       LEFT JOIN darens d ON cc.daren_id = d.id
       LEFT JOIN products p ON cc.product_id = p.id
       ORDER BY cc.updated_at DESC`
    );
    res.json({ code: 0, data: rows });
  } catch (e) { next(e); }
});

// POST /api/commission —— upsert（存在则更新 rate，不存在则插入）
router.post('/', requireRole(['admin', 'daren_op']), async (req, res, next) => {
  try {
    const body = req.body || {};
    const { daren_id, product_id, rate } = body;
    if (!daren_id || !product_id) return res.status(400).json({ code: 400, msg: '达人和商品必填' });
    if (rate === undefined || rate === null || rate === '') {
      return res.status(400).json({ code: 400, msg: '佣金率必填' });
    }

    const exist = await query(
      'SELECT * FROM commission_configs WHERE daren_id = ? AND product_id = ?',
      [daren_id, product_id]
    );

    let id;
    if (exist.length) {
      id = exist[0].id;
      const data = pick(body);
      data.rate = rate; // 强制更新佣金率
      const keys = Object.keys(data);
      const setSql = keys.map((k) => `${k} = ?`).join(', ');
      await query(`UPDATE commission_configs SET ${setSql} WHERE id = ?`, [...Object.values(data), id]);
    } else {
      const data = pick(body);
      const keys = Object.keys(data);
      const vals = Object.values(data);
      const r = await query(
        `INSERT INTO commission_configs (${keys.join(',')}) VALUES (${keys.map(() => '?').join(',')})`,
        vals
      );
      id = r.insertId;
    }
    res.json({ code: 0, data: { id } });
  } catch (e) { next(e); }
});

// PUT /api/commission/:id
router.put('/:id', requireRole(['admin', 'daren_op']), async (req, res, next) => {
  try {
    const data = pick(req.body);
    const keys = Object.keys(data);
    if (!keys.length) return res.status(400).json({ code: 400, msg: '无更新字段' });
    const setSql = keys.map((k) => `${k} = ?`).join(', ');
    await query(`UPDATE commission_configs SET ${setSql} WHERE id = ?`, [...Object.values(data), req.params.id]);
    res.json({ code: 0, data: { id: Number(req.params.id) } });
  } catch (e) { next(e); }
});

// DELETE /api/commission/:id
router.delete('/:id', requireRole(['admin', 'daren_op']), async (req, res, next) => {
  try {
    await query('DELETE FROM commission_configs WHERE id = ?', [req.params.id]);
    res.json({ code: 0, data: {} });
  } catch (e) { next(e); }
});

module.exports = router;

'use strict';
const express = require('express');
const { query } = require('../db');
const { authRequired, requireRole } = require('../auth');

const router = express.Router();
router.use(authRequired);

const STATUSES = ['对接中', '带货中', '不合适', '已终止'];

// GET /api/coop —— 选品合作列表（联表商品/达人，支持 ?product_id=）
router.get('/', async (req, res, next) => {
  try {
    const { product_id } = req.query;
    let sql = `SELECT pd.id, pd.product_id, pd.daren_id, pd.status,
                      pd.coop_fee, pd.coop_mode, pd.commission_rate, pd.remark,
                      pd.updated_by, pd.updated_at,
                      p.name AS product_name, p.sku, p.main_image,
                      b.name AS brand_name,
                      d.name AS daren_name, d.douyin_id, d.fans, d.category, d.cooperation, d.coop_status AS daren_coop_status
               FROM product_daren pd
               LEFT JOIN products p ON pd.product_id = p.id
               LEFT JOIN brands b ON p.brand_id = b.id
               LEFT JOIN darens d ON pd.daren_id = d.id`;
    const params = [];
    if (product_id) { sql += ' WHERE pd.product_id = ?'; params.push(product_id); }
    sql += ' ORDER BY pd.updated_at DESC';
    const rows = params.length ? await query(sql, params) : await query(sql);
    res.json({ code: 0, data: rows });
  } catch (e) { next(e); }
});

// POST /api/coop —— 建立/更新 商品-达人 合作关系（upsert）
router.post('/', requireRole(['admin', 'daren_op']), async (req, res, next) => {
  try {
    const { product_id, daren_id, status = '对接中', remark, coop_fee, coop_mode, commission_rate } = req.body || {};
    if (!product_id || !daren_id) return res.status(400).json({ code: 400, msg: '商品和达人必填' });
    if (STATUSES.indexOf(status) < 0) return res.status(400).json({ code: 400, msg: '非法合作状态' });

    // 客制参数校验（错误早暴露，避免写入脏数据）
    if (coop_mode != null && ['短视频','直播','图文','混合'].indexOf(coop_mode) < 0) {
      return res.status(400).json({ code: 400, msg: '带货方式必须是：短视频/直播/图文/混合' });
    }
    if (coop_fee != null && isNaN(Number(coop_fee))) {
      return res.status(400).json({ code: 400, msg: '合作费用必须是数字' });
    }
    if (commission_rate != null && isNaN(Number(commission_rate))) {
      return res.status(400).json({ code: 400, msg: '佣金比例必须是数字' });
    }

    const exist = await query(
      'SELECT * FROM product_daren WHERE product_id = ? AND daren_id = ?',
      [product_id, daren_id]
    );

    let relationId;
    let fromStatus = null;
    if (exist.length) {
      relationId = exist[0].id;
      fromStatus = exist[0].status;
      if (fromStatus === status) {
        // 状态未变，但合作参数（费用/方式/佣金/备注）可能更新
        const hasExtra = [coop_fee, coop_mode, commission_rate, remark].some(v => v !== undefined);
        if (hasExtra) {
          await query(
            'UPDATE product_daren SET coop_fee = COALESCE(?, coop_fee), coop_mode = COALESCE(?, coop_mode), commission_rate = COALESCE(?, commission_rate), remark = COALESCE(?, remark), updated_by = ? WHERE id = ?',
            [coop_fee ?? null, coop_mode ?? null, commission_rate ?? null, remark ?? null, req.user.id, relationId]
          );
        }
        return res.json({ code: 0, data: { id: relationId, status, unchanged: true } });
      }
      await query(
        'UPDATE product_daren SET status = ?, coop_fee = COALESCE(?, coop_fee), coop_mode = COALESCE(?, coop_mode), commission_rate = COALESCE(?, commission_rate), remark = COALESCE(?, remark), updated_by = ? WHERE id = ?',
        [status, coop_fee ?? null, coop_mode ?? null, commission_rate ?? null, remark ?? null, req.user.id, relationId]
      );
    } else {
      const r = await query(
        'INSERT INTO product_daren (product_id, daren_id, status, coop_fee, coop_mode, commission_rate, remark, updated_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        [product_id, daren_id, status, coop_fee ?? 0, coop_mode ?? null, commission_rate ?? 0, remark ?? null, req.user.id]
      );
      relationId = r.insertId;
    }

    // 写合作历史流水
    await query(
      'INSERT INTO coop_logs (product_id, daren_id, from_status, to_status, operator_id, remark) VALUES (?, ?, ?, ?, ?, ?)',
      [product_id, daren_id, fromStatus, status, req.user.id, remark || null]
    );

    res.json({ code: 0, data: { id: relationId, status } });
  } catch (e) { next(e); }
});

// GET /api/coop/history —— 合作历史（支持 ?product_id= 与 ?daren_id=，按时间倒序）
router.get('/history', async (req, res, next) => {
  try {
    const { product_id, daren_id } = req.query;
    let sql = `SELECT cl.*, p.name AS product_name, d.name AS daren_name, u.name AS operator_name
               FROM coop_logs cl
               LEFT JOIN products p ON cl.product_id = p.id
               LEFT JOIN darens d ON cl.daren_id = d.id
               LEFT JOIN users u ON cl.operator_id = u.id`;
    const conds = [];
    const params = [];
    if (product_id) { conds.push('cl.product_id = ?'); params.push(product_id); }
    if (daren_id) { conds.push('cl.daren_id = ?'); params.push(daren_id); }
    if (conds.length) sql += ' WHERE ' + conds.join(' AND ');
    sql += ' ORDER BY cl.created_at DESC, cl.id DESC';
    const rows = params.length ? await query(sql, params) : await query(sql);
    res.json({ code: 0, data: rows });
  } catch (e) { next(e); }
});

module.exports = router;

'use strict';
const express = require('express');
const { query } = require('../db');
const { authRequired, requireRole } = require('../auth');

const router = express.Router();
router.use(authRequired);
router.use(requireRole('admin')); // 审计日志仅管理员

// GET /api/audit/logs?start=&end=&user=&type=&action=&page=&pageSize=
router.get('/logs', async (req, res, next) => {
  try {
    const { start, end, user, action, page = 1, pageSize = 20 } = req.query;
    const conds = [];
    const params = [];

    if (start) { conds.push('created_at >= ?'); params.push(start + ' 00:00:00'); }
    if (end) { conds.push('created_at <= ?'); params.push(end + ' 23:59:59'); }
    if (user) { conds.push('(user_name LIKE ? OR user_id = ?)'); params.push(`%${user}%`, Number(user) || -1); }
    if (action) { conds.push('action_type = ?'); params.push(action); }

    const where = conds.length ? 'WHERE ' + conds.join(' AND ') : '';
    const p = Math.max(1, Number(page) || 1);
    const ps = Math.min(100, Math.max(1, Number(pageSize) || 20));
    const offset = (p - 1) * ps;

    const totalRows = await query(`SELECT COUNT(*) AS c FROM audit_logs ${where}`, params);
    const total = Number(totalRows[0].c);
    const list = await query(
      `SELECT * FROM audit_logs ${where} ORDER BY id DESC LIMIT ? OFFSET ?`,
      [...params, ps, offset]
    );

    res.json({ code: 0, data: { list, total, page: p, pageSize: ps } });
  } catch (e) { next(e); }
});

// GET /api/audit/types —— 操作类型字典
router.get('/types', async (req, res) => {
  const types = [
    { value: 'login', label: '登录' },
    { value: 'logout', label: '登出' },
    { value: 'create', label: '新增' },
    { value: 'update', label: '编辑' },
    { value: 'delete', label: '删除' },
    { value: 'disable', label: '禁用账号' },
    { value: 'enable', label: '启用账号' },
    { value: 'reset_password', label: '重置密码' },
    { value: 'export', label: '导出文件' },
  ];
  res.json({ code: 0, data: types });
});

module.exports = router;

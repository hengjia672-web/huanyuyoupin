'use strict';
const express = require('express');
const { query } = require('../db');
const { authRequired, requireRole } = require('../auth');

const router = express.Router();
router.use(authRequired);

const FIELDS = ['name','douyin_id','fans','coop_status','cooperation','contact','category','gmv','remark'];

function pick(body) {
  const out = {};
  FIELDS.forEach(k => { if (body[k] !== undefined) out[k] = body[k]; });
  return out;
}

router.get('/', async (req, res, next) => {
  try {
    const rows = await query('SELECT * FROM darens ORDER BY gmv DESC');
    res.json({ code: 0, data: rows });
  } catch (e) { next(e); }
});

router.post('/', requireRole(['admin','daren_op']), async (req, res, next) => {
  try {
    const data = pick(req.body);
    if (!data.name) return res.status(400).json({ code: 400, msg: '达人名称必填' });
    const keys = Object.keys(data), vals = Object.values(data);
    const r = await query(
      `INSERT INTO darens (${keys.join(',')}) VALUES (${keys.map(() => '?').join(',')})`, vals
    );
    res.json({ code: 0, data: { id: r.insertId } });
  } catch (e) { next(e); }
});

router.put('/:id', requireRole(['admin','daren_op']), async (req, res, next) => {
  try {
    const data = pick(req.body);
    const keys = Object.keys(data);
    if (!keys.length) return res.status(400).json({ code: 400, msg: '无更新字段' });
    const setSql = keys.map(k => `${k} = ?`).join(', ');
    await query(`UPDATE darens SET ${setSql} WHERE id = ?`, [...Object.values(data), req.params.id]);
    res.json({ code: 0, data: { id: Number(req.params.id) } });
  } catch (e) { next(e); }
});

router.delete('/:id', requireRole('admin'), async (req, res, next) => {
  try {
    await query('DELETE FROM darens WHERE id = ?', [req.params.id]);
    res.json({ code: 0, data: {} });
  } catch (e) { next(e); }
});

module.exports = router;

'use strict';
const express = require('express');
const { query } = require('../db');
const { authRequired } = require('../auth');

const router = express.Router();
router.use(authRequired);

// GET /api/notifications —— 当前用户通知列表（按时间倒序，支持 ?limit=）
router.get('/', async (req, res, next) => {
  try {
    const limit = Math.min(Number(req.query.limit) || 50, 200);
    const rows = await query(
      'SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC, id DESC LIMIT ?',
      [req.user.id, limit]
    );
    res.json({ code: 0, data: rows });
  } catch (e) { next(e); }
});

// PUT /api/notifications/:id —— 标记已读
router.put('/:id', async (req, res, next) => {
  try {
    await query(
      'UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?',
      [req.params.id, req.user.id]
    );
    res.json({ code: 0, data: { id: Number(req.params.id) } });
  } catch (e) { next(e); }
});

module.exports = router;

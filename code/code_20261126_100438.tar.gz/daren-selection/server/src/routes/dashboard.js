'use strict';
/**
 * 数据看板聚合接口
 *
 * 设计对齐：output/数据看板设计方案.md
 * - GET /api/dashboard                → 主 KPI 汇总（含环比趋势）
 * - GET /api/dashboard/alerts         → 预警聚合（合同到期/库存告急/待打款/评分否决/寄样待跟进）
 * - GET /api/dashboard/trends         → GMV / 佣金趋势（按 period 分组）
 * - GET /api/dashboard/dynamics       → 最近动态（审计日志时间流）+ 未读通知
 * - GET /api/dashboard/distributions  → 分布聚合（品牌分级/品类占比/评分分布/达人Top6）
 */
const express = require('express');
const { query } = require('../db');
const { authRequired } = require('../auth');

const router = express.Router();
router.use(authRequired);

// 环比辅助：近两期对比 → 增长率（%）
function trendPct(curr, prev) {
  if (!prev) return null; // 无上期数据
  return Math.round(((curr - prev) / prev) * 1000) / 10;
}

// ============ GET /api/dashboard —— 主 KPI 汇总 ============
router.get('/', async (req, res, next) => {
  try {
    const [[brandRow], [productRow], [darenRow], [coopRow], [gmvRow], [commissionRow], [pendingRow],
      [brandNewRow], [darenCoopRow], [gmvMonthRow], [gmvPrevRow], [commMonthRow], [commPrevRow]] = await Promise.all([
      query('SELECT COUNT(*) AS c FROM brands'),
      query('SELECT COUNT(*) AS c FROM products'),
      query('SELECT COUNT(*) AS c FROM darens'),
      query('SELECT COUNT(*) AS c FROM product_daren'),
      query('SELECT COALESCE(SUM(gmv),0) AS v FROM darens'),
      query('SELECT COALESCE(SUM(commission_amount),0) AS v FROM settlements'),
      query("SELECT COUNT(*) AS c, COALESCE(SUM(commission_amount),0) AS v FROM settlements WHERE pay_status = '未打款'"),
      // 本月新增品牌（created_at 在本月）
      query("SELECT COUNT(*) AS c FROM brands WHERE created_at >= DATE_FORMAT(CURDATE(), '%Y-%m-01')"),
      // 已合作达人
      query("SELECT COUNT(*) AS c FROM darens WHERE coop_status = '已合作'"),
      // 本月 GMV（sales_records 按 period；period 形如 2026-08）
      query("SELECT COALESCE(SUM(gmv),0) AS v FROM sales_records WHERE period = DATE_FORMAT(CURDATE(), '%Y-%m')"),
      query("SELECT COALESCE(SUM(gmv),0) AS v FROM sales_records WHERE period = DATE_FORMAT(DATE_SUB(CURDATE(), INTERVAL 1 MONTH), '%Y-%m')"),
      // 本月佣金
      query("SELECT COALESCE(SUM(commission_amount),0) AS v FROM settlements WHERE period = DATE_FORMAT(CURDATE(), '%Y-%m')"),
      query("SELECT COALESCE(SUM(commission_amount),0) AS v FROM settlements WHERE period = DATE_FORMAT(DATE_SUB(CURDATE(), INTERVAL 1 MONTH), '%Y-%m')"),
    ]);

    res.json({
      code: 0,
      data: {
        brandTotal: Number(brandRow.c),
        brandNewMonth: Number(brandNewRow.c),
        productTotal: Number(productRow.c),
        darenTotal: Number(darenRow.c),
        darenCoop: Number(darenCoopRow.c),
        coopTotal: Number(coopRow.c),
        totalGmv: Number(gmvRow.v),
        totalCommission: Number(commissionRow.v),
        pendingPay: Number(pendingRow.v),
        pendingPayCount: Number(pendingRow.c),
        // 环比趋势（%）
        gmvTrend: trendPct(Number(gmvMonthRow.v), Number(gmvPrevRow.v)),
        commissionTrend: trendPct(Number(commMonthRow.v), Number(commPrevRow.v)),
      },
    });
  } catch (e) { next(e); }
});

// ============ GET /api/dashboard/alerts —— 预警聚合 ============
router.get('/alerts', async (req, res, next) => {
  try {
    const [contractRows, stockRows, [pendingRow], vetoRow, [sampleRow], expiredRows] = await Promise.all([
      // 合同近 30 天到期（含已到期未处理）
      query(
        `SELECT id, name, contract_expiry FROM brands
         WHERE contract_expiry IS NOT NULL
           AND contract_expiry BETWEEN DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
           AND coop_stage IN ('已签约','合作中')
         ORDER BY contract_expiry ASC LIMIT 5`),
      // 库存告急（stock <= stock_warn 且已上架/待上架）
      query(
        `SELECT id, name, stock, stock_warn FROM products
         WHERE stock_warn > 0 AND stock <= stock_warn
         ORDER BY (stock - stock_warn) ASC LIMIT 5`),
      query("SELECT COUNT(*) AS c, COALESCE(SUM(commission_amount),0) AS v FROM settlements WHERE pay_status = '未打款'"),
      // 评分否决（对象级：存在任一账号 veto）
      query(
        `SELECT subject_type, subject_id, COUNT(DISTINCT user_id) AS n FROM selection_scores
         WHERE veto_flag = 1 GROUP BY subject_type, subject_id LIMIT 5`),
      // 寄样待跟进
      query("SELECT COUNT(*) AS c FROM samples WHERE status = '申请'"),
      // 合同已过期未终止
      query(
        `SELECT id, name, contract_expiry FROM brands
         WHERE contract_expiry IS NOT NULL AND contract_expiry < CURDATE()
           AND coop_stage IN ('已签约','合作中') LIMIT 5`),
    ]);

    res.json({
      code: 0,
      data: {
        contract_expiring: { count: contractRows.length + expiredRows.length, list: [...expiredRows, ...contractRows].slice(0, 5) },
        stock_low: { count: stockRows.length, list: stockRows },
        pending_pay: { count: Number(pendingRow.c), amount: Number(pendingRow.v) },
        score_veto: { count: vetoRow.length, list: vetoRow },
        sample_pending: { count: Number(sampleRow.c) },
      },
    });
  } catch (e) { next(e); }
});

// ============ GET /api/dashboard/trends —— 趋势（近 12 期） ============
router.get('/trends', async (req, res, next) => {
  try {
    const limit = Math.min(Number(req.query.limit) || 12, 24);
    const [gmvTrend, commTrend] = await Promise.all([
      query(
        `SELECT period, COALESCE(SUM(gmv),0) AS v FROM sales_records
         WHERE period IS NOT NULL AND period != ''
         GROUP BY period ORDER BY period DESC LIMIT ?`, [limit]),
      query(
        `SELECT period, COALESCE(SUM(commission_amount),0) AS v FROM settlements
         WHERE period IS NOT NULL AND period != ''
         GROUP BY period ORDER BY period DESC LIMIT ?`, [limit]),
    ]);
    // 按 period 升序返回（时间轴正序）
    const gmvAsc = gmvTrend.reverse();
    const commAsc = commTrend.reverse();
    res.json({
      code: 0,
      data: {
        gmv: gmvAsc.map((r) => ({ period: r.period, value: Number(r.v) })),
        commission: commAsc.map((r) => ({ period: r.period, value: Number(r.v) })),
      },
    });
  } catch (e) { next(e); }
});

// ============ GET /api/dashboard/dynamics —— 最近动态 ============
router.get('/dynamics', async (req, res, next) => {
  try {
    const [logs, notifications] = await Promise.all([
      query(
        `SELECT l.user_name, l.action_type, l.target_table, l.detail, l.created_at
         FROM audit_logs l
         WHERE l.target_table IS NOT NULL
         ORDER BY l.created_at DESC, l.id DESC LIMIT 8`),
      query(
        `SELECT n.id, n.type, n.content, n.is_read, n.created_at
         FROM notifications n WHERE n.user_id = ? AND n.is_read = 0
         ORDER BY n.created_at DESC LIMIT 6`, [req.user.id]),
    ]);
    res.json({ code: 0, data: { logs, notifications } });
  } catch (e) { next(e); }
});

// ============ GET /api/dashboard/distributions —— 分布聚合 ============
router.get('/distributions', async (req, res, next) => {
  try {
    const [gradeRows, categoryRows, verdictRows, topDarens, settleByPeriod] = await Promise.all([
      query('SELECT grade, COUNT(*) AS c FROM brands GROUP BY grade'),
      query('SELECT category, COUNT(*) AS c FROM products WHERE category IS NOT NULL AND category != \'\' GROUP BY category ORDER BY c DESC LIMIT 8'),
      // 评分分布：对象级平均分档位（多账号体系去重）
      query(
        `SELECT ROUND(AVG(score_rate),0) AS r, COUNT(*) AS c FROM (
           SELECT subject_type, subject_id, AVG(score_rate) AS score_rate
           FROM selection_scores GROUP BY subject_type, subject_id
         ) t GROUP BY ROUND(t.score_rate,0)`),
      query('SELECT id, name, douyin_id, fans, gmv FROM darens ORDER BY gmv DESC LIMIT 6'),
      query('SELECT period, COALESCE(SUM(commission_amount),0) AS commission_amount FROM settlements GROUP BY period ORDER BY period ASC LIMIT 12'),
    ]);

    const gradeDist = { S: 0, A: 0, B: 0, C: 0 };
    gradeRows.forEach((r) => { if (gradeDist[r.grade] !== undefined) gradeDist[r.grade] = Number(r.c); });

    // verdict 分档（对象平均分 → 档位）
    const vd = { 优先选品: 0, 可考虑: 0, 观望: 0, 不建议: 0 };
    verdictRows.forEach((r) => {
      const rate = Number(r.r);
      const key = rate >= 80 ? '优先选品' : rate >= 65 ? '可考虑' : rate >= 50 ? '观望' : '不建议';
      vd[key] += Number(r.c);
    });

    res.json({
      code: 0,
      data: {
        gradeDist,
        categoryDist: categoryRows.map((r) => ({ name: r.category, value: Number(r.c) })),
        verdictDist: vd,
        topDarens: topDarens.map((d) => ({ id: d.id, name: d.name, douyin_id: d.douyin_id, fans: Number(d.fans), gmv: Number(d.gmv) })),
        settleByPeriod: settleByPeriod.map((r) => ({ period: r.period, commission_amount: Number(r.commission_amount) })),
      },
    });
  } catch (e) { next(e); }
});

module.exports = router;

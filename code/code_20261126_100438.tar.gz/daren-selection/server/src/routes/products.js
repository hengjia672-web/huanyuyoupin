'use strict';
const express = require('express');
const { query } = require('../db');
const { authRequired, requireRole } = require('../auth');

const router = express.Router();
router.use(authRequired);

const FIELDS = ['name','sku','brand_id','category','main_image','sub_image1','sub_image2','supply_price','sale_price','stock','stock_warn','shelf_status','sales','remark'];

function pick(body) {
  const out = {};
  FIELDS.forEach(k => { if (body[k] !== undefined) out[k] = body[k]; });
  return out;
}

// 列表（联表带品牌名）
// 数据级权限：selection 角色只返回所属品牌 owner_id 为自己或空的商品
router.get('/', async (req, res, next) => {
  try {
    let sql = `SELECT p.*, b.name AS brand_name FROM products p
       LEFT JOIN brands b ON p.brand_id = b.id`;
    const params = [];
    if (req.user.role === 'selection') {
      sql += ' WHERE b.owner_id = ? OR b.owner_id IS NULL';
      params.push(req.user.id);
    }
    sql += ' ORDER BY p.updated_at DESC';
    const rows = params.length ? await query(sql, params) : await query(sql);
    res.json({ code: 0, data: rows });
  } catch (e) { next(e); }
});

router.post('/', requireRole(['admin','selection']), async (req, res, next) => {
  try {
    const data = pick(req.body);
    if (!data.name) return res.status(400).json({ code: 400, msg: '商品名称必填' });
    const keys = Object.keys(data), vals = Object.values(data);
    const r = await query(
      `INSERT INTO products (${keys.join(',')}) VALUES (${keys.map(() => '?').join(',')})`, vals
    );
    res.json({ code: 0, data: { id: r.insertId } });
  } catch (e) { next(e); }
});

// 更新（选品可改全部；物流售后仅可改库存/预警字段）
router.put('/:id', async (req, res, next) => {
  try {
    const role = req.user.role;
    const body = req.body || {};
    let data;
    if (role === 'logistics') {
      data = {};
      if (body.stock !== undefined) data.stock = body.stock;
      if (body.stock_warn !== undefined) data.stock_warn = body.stock_warn;
    } else if (role === 'admin' || role === 'selection') {
      data = pick(body);
    } else {
      return res.status(403).json({ code: 403, msg: '无权限修改商品' });
    }
    const keys = Object.keys(data);
    if (!keys.length) return res.status(400).json({ code: 400, msg: '无更新字段' });
    const setSql = keys.map(k => `${k} = ?`).join(', ');
    await query(`UPDATE products SET ${setSql} WHERE id = ?`, [...Object.values(data), req.params.id]);
    res.json({ code: 0, data: { id: Number(req.params.id) } });
  } catch (e) { next(e); }
});

router.delete('/:id', requireRole('admin'), async (req, res, next) => {
  try {
    await query('DELETE FROM products WHERE id = ?', [req.params.id]);
    res.json({ code: 0, data: {} });
  } catch (e) { next(e); }
});

module.exports = router;

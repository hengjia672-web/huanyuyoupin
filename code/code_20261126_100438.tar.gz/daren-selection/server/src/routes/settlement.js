'use strict';
const express = require('express');
const { query } = require('../db');
const { authRequired, requireRole } = require('../auth');

const router = express.Router();
router.use(authRequired);

const FIELDS = [
  'period', 'daren_id', 'product_id', 'gmv', 'actual_amount', 'rate',
  'commission_amount', 'settle_status', 'pay_status', 'settle_date', 'remark',
];
const SETTLE_STATUSES = ['待核对', '已确认', '有差异'];
const PAY_STATUSES = ['未打款', '已打款'];

// GET /api/settlement —— 结算单列表（联表达人/商品）
router.get('/', async (req, res, next) => {
  try {
    const rows = await query(
      `SELECT s.*, d.name AS daren_name, p.name AS product_name, p.sku
       FROM settlements s
       LEFT JOIN darens d ON s.daren_id = d.id
       LEFT JOIN products p ON s.product_id = p.id
       ORDER BY s.updated_at DESC`
    );
    res.json({ code: 0, data: rows });
  } catch (e) { next(e); }
});

// POST /api/settlement —— 创建结算单（自动带出佣金率并计算佣金）
router.post('/', requireRole(['admin', 'finance', 'daren_op']), async (req, res, next) => {
  try {
    const body = req.body || {};
    if (!body.daren_id || !body.product_id) return res.status(400).json({ code: 400, msg: '达人和商品必填' });

    const data = { settle_status: '待核对', pay_status: '未打款' };
    FIELDS.forEach((k) => { if (body[k] !== undefined && body[k] !== '') data[k] = body[k]; });

    // 未传 rate 时从 commission_configs 按 daren_id+product_id 自动带出
    if (data.rate === undefined || data.rate === null || data.rate === '') {
      const cfg = await query(
        'SELECT rate FROM commission_configs WHERE daren_id = ? AND product_id = ? LIMIT 1',
        [body.daren_id, body.product_id]
      );
      if (cfg.length) data.rate = cfg[0].rate;
    }

    // 未传 commission_amount 时自动计算 = gmv * rate / 100（rate 为百分数）
    if (data.commission_amount === undefined || data.commission_amount === null || data.commission_amount === '') {
      if (data.gmv !== undefined && data.gmv !== null && data.gmv !== '' &&
          data.rate !== undefined && data.rate !== null && data.rate !== '') {
        data.commission_amount = Number(data.gmv) * Number(data.rate) / 100;
      }
    }

    const keys = Object.keys(data);
    const vals = Object.values(data);
    const r = await query(
      `INSERT INTO settlements (${keys.join(',')}) VALUES (${keys.map(() => '?').join(',')})`,
      vals
    );
    res.json({ code: 0, data: { id: r.insertId } });
  } catch (e) { next(e); }
});

// PUT /api/settlement/:id —— 更新（可改 settle_status/pay_status 等）
router.put('/:id', requireRole(['admin', 'finance', 'daren_op']), async (req, res, next) => {
  try {
    const body = req.body || {};
    const data = {};
    FIELDS.forEach((k) => { if (body[k] !== undefined) data[k] = body[k]; });

    if (data.settle_status !== undefined && SETTLE_STATUSES.indexOf(data.settle_status) < 0) {
      return res.status(400).json({ code: 400, msg: '非法结算状态' });
    }
    if (data.pay_status !== undefined && PAY_STATUSES.indexOf(data.pay_status) < 0) {
      return res.status(400).json({ code: 400, msg: '非法打款状态' });
    }

    const keys = Object.keys(data);
    if (!keys.length) return res.status(400).json({ code: 400, msg: '无更新字段' });
    const setSql = keys.map((k) => `${k} = ?`).join(', ');
    await query(`UPDATE settlements SET ${setSql} WHERE id = ?`, [...Object.values(data), req.params.id]);
    res.json({ code: 0, data: { id: Number(req.params.id) } });
  } catch (e) { next(e); }
});

// DELETE /api/settlement/:id
router.delete('/:id', requireRole(['admin', 'finance', 'daren_op']), async (req, res, next) => {
  try {
    await query('DELETE FROM settlements WHERE id = ?', [req.params.id]);
    res.json({ code: 0, data: {} });
  } catch (e) { next(e); }
});

module.exports = router;

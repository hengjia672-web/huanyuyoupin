'use strict';
/**
 * 选品评分 · 多账号多维度评分体系（v2）
 *
 * 设计对齐：output/选品评分多账号体系-设计方案.md
 * - 三层模型：维度池(score_dimensions) → 账号评分(selection_scores+items) → 对象汇总(实时聚合)
 * - 归一化得分率：score_rate = total_score / max_score × 100（服务端权威计算）
 * - 一票否决：veto 维度（supply/inventory/logistics/cert/ip/legal）任一 0 分 → verdict=不建议
 * - 明细全员可见；写操作限 admin/selection；修改限本人/admin
 */
const express = require('express');
const { query } = require('../db');
const { authRequired, requireRole } = require('../auth');

const router = express.Router();
router.use(authRequired);

// ============ 内置维度配置（与 db/schema.sql 内置 16 项口径一致）============
const BUILTIN_DIMS = [
  { code: 'margin', name: '毛利率', max: 15, opts: [['≥45%', 15], ['35–44%', 12], ['25–34%', 8], ['15–24%', 4], ['<15%', 0]] },
  { code: 'story', name: '品牌故事', max: 7, opts: [['强背书', 7], ['基本故事', 5], ['薄弱', 3], ['无', 0]] },
  { code: 'usp', name: '独特卖点', max: 7, opts: [['独家', 7], ['较清晰', 5], ['同质化', 3], ['无', 0]] },
  { code: 'content', name: '内容可拍性', max: 6, opts: [['极易', 6], ['可拍', 4], ['一般', 2], ['难', 0]] },
  { code: 'search', name: '搜索热度', max: 5, opts: [['高热', 5], ['中', 4], ['低', 2], ['冷门', 1]] },
  { code: 'trend', name: '需求趋势', max: 5, opts: [['快升', 5], ['平稳', 4], ['小降', 2], ['大降', 0]] },
  { code: 'competition', name: '竞争激烈度(反向)', max: 5, opts: [['低竞争', 5], ['中等', 3], ['激烈', 1], ['红海', 0]] },
  { code: 'potential', name: '市场潜力', max: 5, opts: [['大且增', 5], ['中等', 4], ['饱和', 2], ['萎缩', 0]] },
  { code: 'supply', name: '供货能力', max: 5, opts: [['多源', 5], ['单一稳', 4], ['单一不稳', 2], ['无保障', 0]], veto: true },
  { code: 'inventory', name: '库存保障', max: 5, opts: [['现货', 5], ['基本', 4], ['时缺', 2], ['频繁缺', 0]], veto: true },
  { code: 'logistics', name: '物流时效', max: 5, opts: [['48h', 5], ['3天', 4], ['直邮', 2], ['差', 0]], veto: true },
  { code: 'cert', name: '资质认证', max: 5, opts: [['齐全', 5], ['基本', 4], ['部分缺', 2], ['关键缺', 0]], veto: true },
  { code: 'ip', name: '知识产权', max: 5, opts: [['无风险', 5], ['低', 4], ['中', 2], ['高', 0]], veto: true },
  { code: 'legal', name: '法律合规', max: 5, opts: [['合规', 5], ['基本', 4], ['瑕疵', 2], ['违规', 0]], veto: true },
  { code: 'repeat', name: '复购率', max: 10, opts: [['月耗', 10], ['季耗', 7], ['半年+', 4], ['一次性', 0]] },
  { code: 'season', name: '季节性', max: 5, opts: [['常青', 5], ['弱季', 3], ['强季', 2], ['爆款', 0]] },
];
const VETO_CODES = BUILTIN_DIMS.filter((d) => d.veto).map((d) => d.code);
const VERDICTS = ['优先选品', '可考虑', '观望', '不建议'];

// ============ 服务端权威计算 ============
function calcRate(items) {
  // items: [{code, score, max}] → 归一化得分率
  let total = 0, maxTotal = 0, veto = false;
  for (const it of items) {
    const s = Number(it.score) || 0;
    const m = Number(it.max) || 0;
    total += s;
    maxTotal += m;
    if (VETO_CODES.includes(it.code) && s === 0) veto = true;
  }
  const rate = maxTotal > 0 ? Math.round((total / maxTotal) * 1000) / 10 : 0; // 1位小数
  let verdict;
  if (veto) verdict = '不建议';
  else if (rate >= 80) verdict = '优先选品';
  else if (rate >= 65) verdict = '可考虑';
  else if (rate >= 50) verdict = '观望';
  else verdict = '不建议';
  return { total, maxTotal, rate, verdict, veto };
}

// 平均分 → 对象 verdict（沿用同一阈值）
function rateToVerdict(rate) {
  if (rate >= 80) return '优先选品';
  if (rate >= 65) return '可考虑';
  if (rate >= 50) return '观望';
  return '不建议';
}

// 校验数值为整数且在 [0, max]
function isIntInRange(v, max) {
  const n = Number(v);
  return Number.isInteger(n) && n >= 0 && n <= max;
}

// 兜底：确保用户有维度启用集（无则自动初始化内置维度），返回启用 dim_id 集合
async function ensureAccountDims(userId) {
  const [accDims, dims] = await Promise.all([
    query('SELECT dim_id FROM score_account_dims WHERE user_id = ? AND enabled = 1', [userId]),
    query("SELECT * FROM score_dimensions WHERE status='active'"),
  ]);
  if (accDims.length || !dims.length) {
    return { enabledIds: new Set(accDims.map((r) => r.dim_id)), dims };
  }
  // 无启用集 → 自动初始化内置 active 维度
  const initVals = dims.filter((d) => d.is_builtin).map((d) => [userId, d.id, 1, d.sort]);
  if (initVals.length) {
    const conn = await (require('../db').pool).getConnection();
    try {
      await conn.beginTransaction();
      for (const v of initVals) {
        await conn.query('INSERT IGNORE INTO score_account_dims (user_id, dim_id, enabled, sort) VALUES (?,?,?,?)', v);
      }
      await conn.commit();
    } catch (e) { await conn.rollback(); } finally { conn.release(); }
  }
  return { enabledIds: new Set(initVals.map((v) => v[1])), dims };
}

// ============ GET /api/scores/config —— 维度池(active) + 我的启用集 ============
router.get('/config', async (req, res, next) => {
  try {
    const [dims, accDims, subjects] = await Promise.all([
      query("SELECT * FROM score_dimensions WHERE status='active' ORDER BY sort ASC, id ASC"),
      query('SELECT dim_id, enabled FROM score_account_dims WHERE user_id = ?', [req.user.id]),
      query('SELECT id, name, username FROM users WHERE status = 1'),
    ]);
    const enabledMap = {};
    accDims.forEach((r) => { enabledMap[r.dim_id] = Number(r.enabled); });
    // 兜底：用户无启用集记录时自动初始化（默认全启用内置 active 维度）
    // 覆盖：迁移前创建的用户、迁移后新注册的用户等场景
    if (!accDims.length && dims.length) {
      const initVals = dims.filter((d) => d.is_builtin).map((d) => [req.user.id, d.id, 1, d.sort]);
      if (initVals.length) {
        const conn = await (require('../db').pool).getConnection();
        try {
          await conn.beginTransaction();
          for (const v of initVals) {
            await conn.query(
              'INSERT IGNORE INTO score_account_dims (user_id, dim_id, enabled, sort) VALUES (?,?,?,?)', v);
          }
          await conn.commit();
        } catch (e) { await conn.rollback(); } finally { conn.release(); }
      }
      // 重新读取
      const fresh = await query('SELECT dim_id, enabled FROM score_account_dims WHERE user_id = ?', [req.user.id]);
      fresh.forEach((r) => { enabledMap[r.dim_id] = Number(r.enabled); });
    }
    // 内置维度带档位选项（自定义维度仅基础信息，前端用数字输入）
    const builtinMap = {};
    BUILTIN_DIMS.forEach((d) => { builtinMap[d.code] = d; });
    const groups = [];
    const groupOrder = [];
    dims.forEach((d) => {
      const b = builtinMap[d.code];
      const item = {
        id: d.id, code: d.code, name: d.name, max: d.max_score,
        group: d.group_name || '其他', is_builtin: d.is_builtin,
        enabled: enabledMap[d.id] !== 0,
        veto: !!(b && b.veto),
        opts: (b && b.opts) || null,
      };
      let g = groups.find((x) => x.name === item.group);
      if (!g) { g = { name: item.group, dims: [] }; groups.push(g); groupOrder.push(item.group); }
      g.dims.push(item);
    });
    // 按内置 sort 排序分组（保持文档 7 大组顺序）
    const groupSeq = ['价格利差', '品牌故事与差异化', '市场需求与竞争度', '供应链稳定性', '合规与资质风险', '复购率与生命周期', '季节性/趋势性'];
    groups.sort((a, b) => {
      const ia = groupSeq.indexOf(a.name), ib = groupSeq.indexOf(b.name);
      return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib);
    });
    res.json({
      code: 0,
      data: {
        groups,
        my_enabled_dim_ids: dims.filter((d) => enabledMap[d.id] !== 0).map((d) => d.id),
        builtin_total: 100,
        users: subjects,
      },
    });
  } catch (e) { next(e); }
});

// ============ GET /api/scores/list?type=&verdict=&sort= —— 对象汇总 ============
router.get('/list', async (req, res, next) => {
  try {
    const { type, verdict, sort } = req.query;
    // 汇总：按 subject 聚合（每账号一条 → 平均分/账号数/分布/否决数）
    const rows = await query(
      `SELECT s.subject_type, s.subject_id,
              ROUND(AVG(s.score_rate), 1) AS avg_rate,
              COUNT(*) AS score_count,
              SUM(CASE WHEN s.veto_flag = 1 THEN 1 ELSE 0 END) AS veto_count,
              GROUP_CONCAT(DISTINCT s.verdict) AS verdicts
       FROM selection_scores s
       WHERE (? = '' OR s.subject_type = ?)
       GROUP BY s.subject_type, s.subject_id`,
      [type || '', type || '']
    );
    if (!rows.length) return res.json({ code: 0, data: [] });

    // 关联对象名
    const pIds = [], bIds = [];
    rows.forEach((r) => { (r.subject_type === 'product' ? pIds : bIds).push(r.subject_id); });
    const [pRows, bRows] = await Promise.all([
      pIds.length ? query(`SELECT id, name, brand_id FROM products WHERE id IN (${pIds.map(() => '?').join(',')})`, pIds) : [],
      bIds.length ? query(`SELECT id, name FROM brands WHERE id IN (${bIds.map(() => '?').join(',')})`, bIds) : [],
    ]);
    const pMap = {}, bMap = {};
    pRows.forEach((r) => { pMap[r.id] = r; });
    bRows.forEach((r) => { bMap[r.id] = r; });

    const list = rows.map((r) => {
      const sub = r.subject_type === 'product' ? pMap[r.subject_id] : bMap[r.subject_id];
      if (!sub) return null; // 对象已删除 → 过滤孤儿
      const dist = {};
      (r.verdicts || '').split(',').forEach((v) => { if (v) dist[v] = (dist[v] || 0) + 1; });
      return {
        subject_id: r.subject_id,
        subject_type: r.subject_type,
        subject_name: sub.name,
        brand_name: r.subject_type === 'product' ? (sub.brand_id ? (bMap[sub.brand_id] ? bMap[sub.brand_id].name : null) : null) : null,
        avg_rate: Number(r.avg_rate),
        score_count: Number(r.score_count),
        veto_count: Number(r.veto_count),
        verdict_dist: dist,
        verdict: rateToVerdict(Number(r.avg_rate)),
      };
    }).filter(Boolean);

    // 筛选 + 排序
    let out = list;
    if (verdict && VERDICTS.includes(verdict)) out = out.filter((x) => x.verdict === verdict);
    if (sort === 'avg_desc') out.sort((a, b) => b.avg_rate - a.avg_rate);
    else if (sort === 'avg_asc') out.sort((a, b) => a.avg_rate - b.avg_rate);
    else if (sort === 'count_desc') out.sort((a, b) => b.score_count - a.score_count);
    else out.sort((a, b) => b.score_count - a.score_count || b.avg_rate - a.avg_rate);
    res.json({ code: 0, data: out });
  } catch (e) { next(e); }
});

// ============ GET /api/scores/detail?type=&subject_id= —— 账号×维度矩阵 ============
router.get('/detail', async (req, res, next) => {
  try {
    const { type, subject_id } = req.query;
    if (!['product', 'brand'].includes(type)) return res.status(400).json({ code: 400, msg: 'type 无效' });
    const sid = Number(subject_id);
    if (!sid) return res.status(400).json({ code: 400, msg: 'subject_id 无效' });

    const subTable = type === 'product' ? 'products' : 'brands';
    const sub = await query(`SELECT * FROM ${subTable} WHERE id = ?`, [sid]);
    if (!sub.length) return res.status(404).json({ code: 404, msg: '对象不存在' });

    // 所有评分主表记录（账号层）
    const scores = await query(
      `SELECT s.*, u.name AS user_name, u.username, u.dept, u.status AS user_status
       FROM selection_scores s
       LEFT JOIN users u ON u.id = s.user_id
       WHERE s.subject_type = ? AND s.subject_id = ?
       ORDER BY s.score_rate DESC`,
      [type, sid]
    );
    // 明细（维度分）
    const scoreIds = scores.map((s) => s.id);
    const items = scoreIds.length
      ? await query(
          `SELECT i.score_id, i.dim_id, i.score, i.max_score, d.code, d.name, d.group_name
           FROM selection_score_items i
           JOIN score_dimensions d ON d.id = i.dim_id
           WHERE i.score_id IN (${scoreIds.map(() => '?').join(',')})
           ORDER BY d.sort ASC`,
          scoreIds
        )
      : [];

    // 维度平均分（只统计打了该维度的账号）
    const dimMap = {};
    items.forEach((it) => {
      if (!dimMap[it.dim_id]) dimMap[it.dim_id] = { dim_id: it.dim_id, code: it.code, name: it.name, group: it.group_name, max: it.max_score, sum: 0, count: 0 };
      dimMap[it.dim_id].sum += Number(it.score);
      dimMap[it.dim_id].count += 1;
    });
    const dims = Object.values(dimMap).map((d) => ({
      id: d.dim_id, code: d.code, name: d.name, group: d.group,
      max: d.max, avg: Math.round((d.sum / d.count) * 10) / 10, score_count: d.count,
    }));

    // 账号层组装
    const accounts = scores.map((s) => {
      const it = items.filter((x) => x.score_id === s.id);
      const itemsMap = {};
      it.forEach((x) => { itemsMap[x.code] = Number(x.score); });
      return {
        id: s.id,
        user_id: s.user_id,
        user_name: s.user_name || s.username || `#${s.user_id}`,
        dept: s.dept,
        user_status: s.user_status,
        total_score: s.total_score,
        max_score: s.max_score,
        score_rate: Number(s.score_rate),
        verdict: s.verdict,
        veto_flag: s.veto_flag,
        remark: s.remark,
        updated_at: s.updated_at,
        items: itemsMap,
      };
    });

    // 对象层汇总
    const avgRate = accounts.length ? Math.round((accounts.reduce((a, b) => a + b.score_rate, 0) / accounts.length) * 10) / 10 : 0;
    const vetoCount = accounts.filter((a) => a.veto_flag).length;
    const dist = {};
    accounts.forEach((a) => { dist[a.verdict] = (dist[a.verdict] || 0) + 1; });

    res.json({
      code: 0,
      data: {
        subject: { id: sub[0].id, name: sub[0].name, type, brand_name: type === 'product' && sub[0].brand_id ? null : null },
        avg_rate: avgRate,
        verdict: rateToVerdict(avgRate),
        verdict_dist: dist,
        veto_count: vetoCount,
        score_count: accounts.length,
        dims,
        accounts,
      },
    });
  } catch (e) { next(e); }
});

// ============ POST /api/scores —— 保存我的评分（事务，复用 saveScore） ============
router.post('/', requireRole(['admin', 'selection']), async (req, res, next) => {
  // 校验基础参数后委托 saveScore（统一事务逻辑）
  const { subject_type, subject_id } = req.body;
  if (!['product', 'brand'].includes(subject_type)) {
    return res.status(400).json({ code: 400, msg: 'subject_type 无效' });
  }
  const sid = Number(subject_id);
  if (!sid) return res.status(400).json({ code: 400, msg: 'subject_id 无效' });
  return saveScore(req, res, next, null);
});

// 内部保存函数（POST/PUT 共用；_score_id 存在时为更新指定 id）
async function saveScore(req, res, next, forceId) {
  const conn = await (require('../db').pool).getConnection();
  try {
    const { subject_type, subject_id, scores, remark } = req.body;
    if (!['product', 'brand'].includes(subject_type)) return res.status(400).json({ code: 400, msg: 'subject_type 无效' });
    const sid = Number(subject_id);
    if (!sid) return res.status(400).json({ code: 400, msg: 'subject_id 无效' });

    const subTable = subject_type === 'product' ? 'products' : 'brands';
    const sub = await query(`SELECT id FROM ${subTable} WHERE id = ?`, [sid]);
    if (!sub.length) return res.status(400).json({ code: 400, msg: '评分的商品/品牌不存在' });

    const { enabledIds, dims: dimRows } = await ensureAccountDims(req.user.id);
    const items = [];
    for (const d of dimRows) {
      if (!enabledIds.has(d.id)) continue;
      // 缺失的启用维度按 0 分处理（含新增自定义维度：历史评分不受影响）
      const raw = scores ? scores[d.code] : 0;
      const v = raw === undefined || raw === null ? 0 : raw;
      if (!isIntInRange(v, d.max_score)) {
        return res.status(400).json({ code: 400, msg: `${d.name} 分值需为 0~${d.max_score} 的整数` });
      }
      items.push({ code: d.code, dim_id: d.id, score: Number(v), max: d.max_score });
    }
    if (!items.length) return res.status(400).json({ code: 400, msg: '未启用任何评分维度' });

    const { total, maxTotal, rate, verdict, veto } = calcRate(items);
    const userId = req.user.id;

    await conn.beginTransaction();
    const before = forceId
      ? await conn.query('SELECT * FROM selection_scores WHERE id = ?', [forceId])
      : await conn.query('SELECT * FROM selection_scores WHERE subject_type = ? AND subject_id = ? AND user_id = ?', [subject_type, sid, userId]);

    let finalId;
    if (forceId) {
      await conn.query(
        `UPDATE selection_scores SET total_score=?, max_score=?, score_rate=?, verdict=?, veto_flag=?, remark=? WHERE id=?`,
        [total, maxTotal, rate, verdict, veto ? 1 : 0, remark || null, forceId]);
      finalId = forceId;
    } else {
      const [ins] = await conn.query(
        `INSERT INTO selection_scores
           (subject_type, subject_id, user_id, total_score, max_score, score_rate, verdict, veto_flag, remark)
         VALUES (?,?,?,?,?,?,?,?,?)
         ON DUPLICATE KEY UPDATE
           total_score = VALUES(total_score), max_score = VALUES(max_score),
           score_rate = VALUES(score_rate), verdict = VALUES(verdict),
           veto_flag = VALUES(veto_flag), remark = VALUES(remark)`,
        [subject_type, sid, userId, total, maxTotal, rate, verdict, veto ? 1 : 0, remark || null]);
      finalId = ins.insertId || (before.length ? before[0].id : null);
      if (!finalId) {
        const ex = await conn.query('SELECT id FROM selection_scores WHERE subject_type=? AND subject_id=? AND user_id=?', [subject_type, sid, userId]);
        finalId = ex[0][0].id;
      }
    }

    await conn.query('DELETE FROM selection_score_items WHERE score_id = ?', [finalId]);
    for (const it of items) {
      await conn.query('INSERT INTO selection_score_items (score_id, dim_id, score, max_score) VALUES (?,?,?,?)', [finalId, it.dim_id, it.score, it.max]);
    }
    await conn.query(
      'INSERT INTO score_histories (score_id, user_id, action, before_data, after_data) VALUES (?,?,?,?,?)',
      [finalId, userId, before.length ? 'update' : 'create',
        before.length ? JSON.stringify(before[0]) : null,
        JSON.stringify({ subject_type, subject_id: sid, user_id: userId, total_score: total, max_score: maxTotal, score_rate: rate, verdict, veto_flag: veto ? 1 : 0 })]
    );
    await conn.commit();
    res.json({ code: 0, data: { id: finalId, score_rate: rate, verdict, veto_flag: veto ? 1 : 0 }, msg: '评分已保存' });
  } catch (e) {
    await conn.rollback();
    next(e);
  } finally {
    conn.release();
  }
}

// ============ 维度池管理 ============
// GET /api/scores/dimensions —— 维度池列表（admin 全部 / 其他 active + 本人 pending）
router.get('/dimensions', async (req, res, next) => {
  try {
    const isAdmin = req.user.role === 'admin';
    const rows = isAdmin
      ? await query('SELECT * FROM score_dimensions ORDER BY is_builtin DESC, sort ASC, id ASC')
      : await query(
          "SELECT * FROM score_dimensions WHERE status='active' OR (status='pending' AND created_by = ?) ORDER BY is_builtin DESC, sort ASC, id ASC",
          [req.user.id]);
    // 附带启用账号数
    const dimIds = rows.map((r) => r.id);
    const cnts = dimIds.length
      ? await query(`SELECT dim_id, COUNT(*) AS c FROM score_account_dims WHERE dim_id IN (${dimIds.map(() => '?').join(',')}) GROUP BY dim_id`, dimIds)
      : [];
    const cntMap = {};
    cnts.forEach((r) => { cntMap[r.dim_id] = Number(r.c); });
    res.json({ code: 0, data: rows.map((r) => ({ ...r, enabled_accounts: cntMap[r.id] || 0 })) });
  } catch (e) { next(e); }
});

// POST /api/scores/dimensions —— 申请自定义维度（admin 直接通过）
router.post('/dimensions', requireRole(['admin', 'selection']), async (req, res, next) => {
  try {
    const { name, group_name, max_score } = req.body;
    if (!name || !String(name).trim()) return res.status(400).json({ code: 400, msg: '维度名必填' });
    const max = Number(max_score);
    if (!Number.isInteger(max) || max < 1 || max > 20) return res.status(400).json({ code: 400, msg: '满分需为 1~20 的整数' });
    const isAdmin = req.user.role === 'admin';
    // 生成唯一 code：custom_<时间戳后缀>
    const code = 'custom_' + Date.now().toString(36);
    const [r] = await (require('../db').pool).execute(
      `INSERT INTO score_dimensions (code, name, group_name, max_score, is_builtin, status, created_by)
       VALUES (?,?,?,?,0,?,?)`,
      [code, String(name).trim(), group_name || '其他', max, isAdmin ? 'active' : 'pending', req.user.id]
    );
    // admin 直接创建 → 自动加入所有启用账号？不：仅创建者启用（避免污染他人启用集）
    await (require('../db').pool).execute(
      'INSERT IGNORE INTO score_account_dims (user_id, dim_id, enabled, sort) VALUES (?,?,1,?)',
      [req.user.id, r.insertId, 999]);
    res.json({ code: 0, data: { id: r.insertId, status: isAdmin ? 'active' : 'pending' }, msg: isAdmin ? '维度已创建' : '维度已提交，等待管理员审核' });
  } catch (e) { next(e); }
});

// PUT /api/scores/dimensions/:id —— 审核/启停/改满分（admin）
router.put('/dimensions/:id', requireRole(['admin']), async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    if (!id) return res.status(400).json({ code: 400, msg: 'id 无效' });
    const { status, max_score, group_name } = req.body;
    const sets = [];
    const vals = [];
    if (status && ['active', 'disabled', 'pending'].includes(status)) { sets.push('status = ?'); vals.push(status); }
    if (max_score !== undefined) {
      const max = Number(max_score);
      if (!Number.isInteger(max) || max < 1 || max > 20) return res.status(400).json({ code: 400, msg: '满分需为 1~20 的整数' });
      sets.push('max_score = ?'); vals.push(max);
    }
    if (group_name !== undefined) { sets.push('group_name = ?'); vals.push(String(group_name).trim() || null); }
    if (!sets.length) return res.status(400).json({ code: 400, msg: '无可更新字段' });
    vals.push(id);
    await query(`UPDATE score_dimensions SET ${sets.join(',')} WHERE id = ?`, vals);
    res.json({ code: 0, data: { id }, msg: '已更新' });
  } catch (e) { next(e); }
});

// ============ 账号维度启用集 ============
// GET /api/scores/account-dims?user_id= —— 查看（admin 可指定任意账号，其他仅自己）
router.get('/account-dims', async (req, res, next) => {
  try {
    const targetId = req.user.role === 'admin' && req.query.user_id ? Number(req.query.user_id) : req.user.id;
    const rows = await query(
      `SELECT a.dim_id, a.enabled, d.code, d.name, d.group_name, d.max_score, d.is_builtin, d.status
       FROM score_account_dims a JOIN score_dimensions d ON d.id = a.dim_id
       WHERE a.user_id = ? ORDER BY d.sort ASC, d.id ASC`,
      [targetId]);
    res.json({ code: 0, data: rows });
  } catch (e) { next(e); }
});

// PUT /api/scores/account-dims —— 保存（自己 / admin 管理他人）
router.put('/account-dims', async (req, res, next) => {
  try {
    const targetId = req.user.role === 'admin' && req.body.user_id ? Number(req.body.user_id) : req.user.id;
    const { dims } = req.body; // [{dim_id, enabled}]
    if (!Array.isArray(dims)) return res.status(400).json({ code: 400, msg: 'dims 无效' });
    const conn = await (require('../db').pool).getConnection();
    try {
      await conn.beginTransaction();
      for (const d of dims) {
        const did = Number(d.dim_id);
        if (!did) continue;
        await conn.query(
          `INSERT INTO score_account_dims (user_id, dim_id, enabled, sort)
           VALUES (?,?,?,0)
           ON DUPLICATE KEY UPDATE enabled = VALUES(enabled)`,
          [targetId, did, d.enabled ? 1 : 0]);
      }
      await conn.commit();
    } catch (e) { await conn.rollback(); throw e; } finally { conn.release(); }
    res.json({ code: 0, data: { user_id: targetId }, msg: '启用集已保存' });
  } catch (e) { next(e); }
});

// ============ GET /api/scores/history?score_id= —— 修改历史 ============
router.get('/history', async (req, res, next) => {
  try {
    const scoreId = Number(req.query.score_id);
    if (!scoreId) return res.status(400).json({ code: 400, msg: 'score_id 无效' });
    // 权限：admin 或该评分本人
    const sc = await query('SELECT * FROM selection_scores WHERE id = ?', [scoreId]);
    if (!sc.length) return res.status(404).json({ code: 404, msg: '评分不存在' });
    if (req.user.role !== 'admin' && sc[0].user_id !== req.user.id) {
      return res.status(403).json({ code: 403, msg: '无权限查看' });
    }
    const rows = await query(
      `SELECT h.*, u.name AS user_name FROM score_histories h
       LEFT JOIN users u ON u.id = h.user_id
       WHERE h.score_id = ? ORDER BY h.created_at DESC, h.id DESC`,
      [scoreId]);
    res.json({ code: 0, data: rows });
  } catch (e) { next(e); }
});

// ============ 通用 /:id 路由（必须放在最后，确保具体路由优先匹配） ============

// ============ PUT /api/scores/:id —— 修改（本人/admin） ============
router.put('/:id', requireRole(['admin', 'selection']), async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    if (!id) return res.status(400).json({ code: 400, msg: 'id 无效' });
    const rows = await query('SELECT * FROM selection_scores WHERE id = ?', [id]);
    if (!rows.length) return res.status(404).json({ code: 404, msg: '评分不存在' });
    const sc = rows[0];
    if (req.user.role !== 'admin' && sc.user_id !== req.user.id) {
      return res.status(403).json({ code: 403, msg: '只能修改自己的评分' });
    }
    req.body = {
      subject_type: sc.subject_type,
      subject_id: sc.subject_id,
      scores: req.body.scores,
      remark: req.body.remark,
      _score_id: id,
    };
    return saveScore(req, res, next, id);
  } catch (e) { next(e); }
});

// ============ DELETE /api/scores/:id —— 删除（本人/admin） ============
router.delete('/:id', requireRole(['admin', 'selection']), async (req, res, next) => {
  const conn = await (require('../db').pool).getConnection();
  try {
    const id = Number(req.params.id);
    if (!id) return res.status(400).json({ code: 400, msg: 'id 无效' });
    const rows = await query('SELECT * FROM selection_scores WHERE id = ?', [id]);
    if (!rows.length) return res.status(404).json({ code: 404, msg: '评分不存在' });
    if (req.user.role !== 'admin' && rows[0].user_id !== req.user.id) {
      return res.status(403).json({ code: 403, msg: '只能删除自己的评分' });
    }
    await conn.beginTransaction();
    await conn.query('INSERT INTO score_histories (score_id, user_id, action, before_data) VALUES (?,?,?,?)', [id, req.user.id, 'delete', JSON.stringify(rows[0])]);
    await conn.query('DELETE FROM selection_score_items WHERE score_id = ?', [id]);
    await conn.query('DELETE FROM selection_scores WHERE id = ?', [id]);
    await conn.commit();
    res.json({ code: 0, data: { id }, msg: '已删除' });
  } catch (e) {
    await conn.rollback();
    next(e);
  } finally {
    conn.release();
  }
});

module.exports = router;

'use strict';
const express = require('express');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { query } = require('../db');
const { authRequired, requireRole } = require('../auth');
const { writeAudit, clientIp } = require('../audit');

const router = express.Router();
router.use(authRequired);
router.use(requireRole('admin')); // 账号管理仅管理员

const ROLES = ['admin', 'selection', 'daren_op', 'finance', 'logistics', 'viewer'];
const ROLE_NAMES = { admin: '管理员', selection: '选品专员', daren_op: '达人运营', finance: '财务', logistics: '物流售后', viewer: '只读' };

// 模块权限白名单（对应前端菜单 path）；管理员专属模块仅 admin 可用
const MODULES = ['dashboard', 'brands', 'products', 'darens', 'coop', 'samples', 'commission', 'scores', 'excel', 'users', 'audit'];
const ADMIN_ONLY_MODULES = ['users', 'audit'];

function parsePermissions(perms, role) {
  if (perms == null) return null; // NULL = 跟随角色
  if (!Array.isArray(perms)) return null;
  const clean = [...new Set(perms.filter((m) => MODULES.includes(m)))];
  if (role !== 'admin') {
    // 非管理员不允许自定义管理员专属模块
    ADMIN_ONLY_MODULES.forEach((m) => {
      const i = clean.indexOf(m);
      if (i >= 0) clean.splice(i, 1);
    });
  }
  return clean.length ? JSON.stringify(clean) : null;
}

function sanitize(u) {
  let permissions = u.permissions || null;
  try { permissions = permissions ? JSON.parse(permissions) : null; } catch (e) { permissions = null; }
  return { id: u.id, username: u.username, name: u.name, role: u.role, dept: u.dept, status: u.status, permissions, created_at: u.created_at };
}

// 是否最后一个启用的管理员
async function isLastActiveAdmin(id) {
  const rows = await query('SELECT COUNT(*) AS c FROM users WHERE role = ? AND status = 1 AND id <> ?', ['admin', id]);
  return Number(rows[0].c) === 0;
}

// GET /api/users —— 用户列表（不含密码）
router.get('/', async (req, res, next) => {
  try {
    const rows = await query('SELECT id, username, name, role, dept, status, permissions, created_at FROM users ORDER BY id ASC');
    res.json({ code: 0, data: rows.map(sanitize) });
  } catch (e) { next(e); }
});

// POST /api/users —— 创建账号
router.post('/', async (req, res, next) => {
  try {
    const { username, name, password, role, dept, permissions } = req.body || {};
    if (!username || !password) return res.status(400).json({ code: 400, msg: '账号和初始密码必填' });
    if (String(password).length < 6) return res.status(400).json({ code: 400, msg: '密码至少 6 位' });
    if (!ROLES.includes(role)) return res.status(400).json({ code: 400, msg: '角色无效' });

    const dup = await query('SELECT id FROM users WHERE username = ?', [username]);
    if (dup.length) return res.status(400).json({ code: 400, msg: '账号已存在' });

    const permsJson = parsePermissions(permissions, role);
    const hash = bcrypt.hashSync(String(password), 10);
    await query(
      'INSERT INTO users (username, password_hash, name, role, dept, status, permissions) VALUES (?, ?, ?, ?, ?, 1, ?)',
      [username, hash, name || username, role, dept || null, permsJson]
    );
    writeAudit({
      userId: req.user.id, userName: req.user.name, ip: clientIp(req), method: 'POST', path: '/api/users',
      table: 'users', action: 'create', after: { username, name: name || username, role, permissions: permsJson }, detail: '创建账号'
    });
    res.json({ code: 0, data: { username }, msg: '账号已创建' });
  } catch (e) { next(e); }
});

// PUT /api/users/:id —— 编辑（姓名/角色/部门）
router.put('/:id', async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    if (!id) return res.status(400).json({ code: 400, msg: 'id 无效' });
    const { name, role, dept, permissions } = req.body || {};
    if (!ROLES.includes(role)) return res.status(400).json({ code: 400, msg: '角色无效' });

    const rows = await query('SELECT * FROM users WHERE id = ?', [id]);
    if (!rows.length) return res.status(404).json({ code: 404, msg: '用户不存在' });
    const target = rows[0];

    // 防锁死：不能改自己角色；不能把最后一个启用 admin 降级
    if (id === req.user.id && role !== target.role) {
      return res.status(400).json({ code: 400, msg: '不能修改自己的角色' });
    }
    if (target.role === 'admin' && role !== 'admin' && target.status === 1 && await isLastActiveAdmin(id)) {
      return res.status(400).json({ code: 400, msg: '不能降级最后一个启用中的管理员' });
    }

    const permsJson = parsePermissions(permissions, role);
    await query('UPDATE users SET name = ?, role = ?, dept = ?, permissions = ? WHERE id = ?', [name || target.name, role, dept || null, permsJson, id]);
    writeAudit({
      userId: req.user.id, userName: req.user.name, ip: clientIp(req), method: 'PUT', path: `/api/users/${id}`,
      table: 'users', targetId: id, action: 'update',
      before: { name: target.name, role: target.role, dept: target.dept, permissions: target.permissions },
      after: { name: name || target.name, role, dept: dept || null, permissions: permsJson },
      detail: '编辑账号'
    });
    res.json({ code: 0, data: { id }, msg: '已更新' });
  } catch (e) { next(e); }
});

// PATCH /api/users/:id/status —— 禁用 / 启用
router.patch('/:id/status', async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const status = Number(req.body && req.body.status);
    if (!id || ![0, 1].includes(status)) return res.status(400).json({ code: 400, msg: '参数无效' });
    const rows = await query('SELECT * FROM users WHERE id = ?', [id]);
    if (!rows.length) return res.status(404).json({ code: 404, msg: '用户不存在' });
    const target = rows[0];

    if (id === req.user.id) return res.status(400).json({ code: 400, msg: '不能禁用自己' });
    if (status === 0 && target.role === 'admin' && await isLastActiveAdmin(id)) {
      return res.status(400).json({ code: 400, msg: '不能禁用最后一个启用中的管理员' });
    }

    await query('UPDATE users SET status = ? WHERE id = ?', [status, id]);
    writeAudit({
      userId: req.user.id, userName: req.user.name, ip: clientIp(req), method: 'PATCH', path: `/api/users/${id}/status`,
      table: 'users', targetId: id, action: status === 0 ? 'disable' : 'enable',
      before: { status: target.status }, after: { status }, detail: status === 0 ? '禁用账号' : '启用账号'
    });
    res.json({ code: 0, data: { id, status }, msg: status === 0 ? '已禁用' : '已启用' });
  } catch (e) { next(e); }
});

// POST /api/users/:id/reset-password —— 重置密码（缺省随机 8 位）
router.post('/:id/reset-password', async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const rows = await query('SELECT * FROM users WHERE id = ?', [id]);
    if (!rows.length) return res.status(404).json({ code: 404, msg: '用户不存在' });
    const target = rows[0];

    const pwd = (req.body && req.body.password) || crypto.randomBytes(4).toString('hex');
    if (String(pwd).length < 6) return res.status(400).json({ code: 400, msg: '密码至少 6 位' });
    const hash = bcrypt.hashSync(String(pwd), 10);
    await query('UPDATE users SET password_hash = ? WHERE id = ?', [hash, id]);
    writeAudit({
      userId: req.user.id, userName: req.user.name, ip: clientIp(req), method: 'POST', path: `/api/users/${id}/reset-password`,
      table: 'users', targetId: id, action: 'reset_password', detail: '重置密码'
    });
    res.json({ code: 0, data: { id, username: target.username, temp_password: pwd }, msg: '密码已重置' });
  } catch (e) { next(e); }
});

module.exports = { router, ROLE_NAMES };

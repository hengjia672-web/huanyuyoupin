'use strict';
// 初始化管理员账号：node scripts/seed.js
// 用法：ADMIN_PASSWORD=你的密码 node scripts/seed.js
require('dotenv').config();
const bcrypt = require('bcryptjs');
const { query } = require('../src/db');

(async () => {
  const username = process.env.ADMIN_USER || 'admin';
  const password = process.env.ADMIN_PASSWORD;
  if (!password) {
    console.error('错误：未设置 ADMIN_PASSWORD 环境变量。');
    console.error('用法：ADMIN_PASSWORD=你的密码 node scripts/seed.js');
    process.exit(1);
  }
  const name = process.env.ADMIN_NAME || '系统管理员';
  const hash = bcrypt.hashSync(password, 10);

  await query('DELETE FROM users WHERE username = ?', [username]);
  await query(
    'INSERT INTO users (username, password_hash, name, role) VALUES (?, ?, ?, ?)',
    [username, hash, name, 'admin']
  );
  console.log(`已创建管理员账号：${username}`);
  process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
